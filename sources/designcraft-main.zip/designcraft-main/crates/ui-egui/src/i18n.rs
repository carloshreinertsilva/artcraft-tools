//! Interface language (Preferences › General › Interface Language): translations of menu titles,
//! the most used menu items and panel names. Untranslated strings stay English. The translations
//! are our own.

use std::{collections::HashMap, sync::OnceLock};

mod ar;
mod cs;
mod de;
mod fr;
mod it;
mod ja;
mod ka;
mod pl;
mod pt_br;
mod ru;
mod uk;

/// Supported interface languages: (code, name in that language).
pub const LANGUAGES: &[(&str, &str)] = &[
    ("", "English"),
    ("de", "Deutsch"),
    ("fr", "Français"),
    ("es", "Español"),
    ("ja", "日本語"),
    ("zh", "简体中文"),
    ("ar", "العربية"),
    ("pt-br", "Português (Brasil)"),
    ("it", "Italiano"),
    ("uk", "Українська"),
    ("ru", "Русский"),
    ("cs", "Čeština"),
    ("pl", "Polski"),
    ("ka", "ქართული"),
];

/// English → [German, French, Spanish, Japanese, Simplified Chinese].
const TABLE: &[(&str, [&str; 5])] = &[
    // Menus.
    ("File", ["Datei", "Fichier", "Archivo", "ファイル", "文件"]),
    ("Edit", ["Bearbeiten", "Édition", "Edición", "編集", "编辑"]),
    ("Layout", ["Layout", "Page", "Maquetación", "レイアウト", "版面"]),
    ("Type", ["Schrift", "Texte", "Texto", "書式", "文字"]),
    ("Object", ["Objekt", "Objet", "Objeto", "オブジェクト", "对象"]),
    ("Table", ["Tabelle", "Tableau", "Tabla", "表", "表"]),
    ("View", ["Ansicht", "Affichage", "Ver", "表示", "视图"]),
    ("Window", ["Fenster", "Fenêtre", "Ventana", "ウィンドウ", "窗口"]),
    ("Help", ["Hilfe", "Aide", "Ayuda", "ヘルプ", "帮助"]),
    // File.
    ("New", ["Neu", "Nouveau", "Nuevo", "新規", "新建"]),
    ("New Document…", ["Neues Dokument …", "Nouveau document…", "Nuevo documento…", "新規ドキュメント…", "新建文档…"]),
    ("Open…", ["Öffnen …", "Ouvrir…", "Abrir…", "開く…", "打开…"]),
    (
        "Open Recent",
        ["Zuletzt verwendete Datei öffnen", "Ouvrir les fichiers récents", "Abrir recientes", "最近使用したファイルを開く", "打开最近的文件"],
    ),
    (
        "Open Recent File",
        ["Zuletzt verwendete Datei öffnen", "Ouvrir un fichier récent", "Abrir archivo reciente", "最近使用したファイルを開く", "打开最近的文件"],
    ),
    (
        "Clear Recent Files",
        ["Liste leeren", "Effacer les fichiers récents", "Borrar archivos recientes", "最近使用したファイルをクリア", "清除最近的文件"],
    ),
    ("Recent files", ["Zuletzt geöffnet", "Fichiers récents", "Archivos recientes", "最近使用したファイル", "最近的文件"]),
    (
        "Number of Recent Items to Display:",
        [
            "Anzahl zuletzt verwendeter Dateien:",
            "Nombre de fichiers récents à afficher :",
            "Número de elementos recientes:",
            "最近使用したファイルの表示数:",
            "最近项目显示数量：",
        ],
    ),
    ("Close", ["Schließen", "Fermer", "Cerrar", "閉じる", "关闭"]),
    ("Save", ["Speichern", "Enregistrer", "Guardar", "保存", "保存"]),
    ("Save As…", ["Speichern unter …", "Enregistrer sous…", "Guardar como…", "別名で保存…", "另存为…"]),
    ("Save a Copy…", ["Kopie speichern …", "Enregistrer une copie…", "Guardar una copia…", "コピーを保存…", "保存副本…"]),
    ("Revert", ["Zurück zur letzten Version", "Version précédente", "Volver a la versión guardada", "復帰", "恢复到上次保存"]),
    ("Place…", ["Platzieren …", "Importer…", "Colocar…", "配置…", "置入…"]),
    ("Export PDF…", ["PDF exportieren …", "Exporter en PDF…", "Exportar PDF…", "PDF を書き出し…", "导出PDF…"]),
    ("Print…", ["Drucken …", "Imprimer…", "Imprimir…", "プリント…", "打印…"]),
    ("Document Setup…", ["Dokument einrichten …", "Format de document…", "Ajustar documento…", "ドキュメント設定…", "文档设置…"]),
    ("Package…", ["Verpacken …", "Assemblage…", "Empaquetar…", "パッケージ…", "打包…"]),
    // Edit.
    ("Undo", ["Rückgängig", "Annuler", "Deshacer", "取り消し", "还原"]),
    ("Redo", ["Wiederholen", "Rétablir", "Rehacer", "やり直し", "重做"]),
    ("Cut", ["Ausschneiden", "Couper", "Cortar", "カット", "剪切"]),
    ("Copy", ["Kopieren", "Copier", "Copiar", "コピー", "复制"]),
    ("Paste", ["Einfügen", "Coller", "Pegar", "ペースト", "粘贴"]),
    ("Hide Rulers", ["Lineale ausblenden", "Masquer les règles", "Ocultar reglas", "定規を隠す", "隐藏标尺"]),
    ("Inches Decimal", ["Zoll dezimal", "Pouces décimaux", "Pulgadas decimales", "インチ（10 進）", "十进制英寸"]),
    (
        "Paste Vector Art",
        ["Vektorgrafik einfügen", "Coller l’illustration vectorielle", "Pegar ilustración vectorial", "ベクトルアートをペースト", "粘贴矢量图稿"],
    ),
    ("Back", ["Zurück", "Retour", "Atrás", "戻る", "返回"]),
    ("Margins and Columns", ["Ränder und Spalten", "Marges et colonnes", "Márgenes y columnas", "マージン・段組", "边距和分栏"]),
    ("Warning", ["Warnung", "Avertissement", "Advertencia", "警告", "警告"]),
    ("Don't show again", ["Nicht mehr anzeigen", "Ne plus afficher", "No volver a mostrar", "今後表示しない", "不再显示"]),
    (
        "The affected page contains objects. Delete the page anyway?",
        [
            "Die betroffene Seite enthält Objekte. Seite trotzdem löschen?",
            "La page concernée contient des objets. Supprimer quand même la page ?",
            "La página afectada contiene objetos. ¿Desea eliminarla de todos modos?",
            "対象のページにはオブジェクトが含まれています。ページを削除しますか？",
            "受影响的页面包含对象。仍要删除该页面吗？",
        ],
    ),
    (
        "The affected pages contain objects. Delete the pages anyway?",
        [
            "Die betroffenen Seiten enthalten Objekte. Seiten trotzdem löschen?",
            "Les pages concernées contiennent des objets. Supprimer quand même les pages ?",
            "Las páginas afectadas contienen objetos. ¿Desea eliminarlas de todos modos?",
            "対象のページにはオブジェクトが含まれています。ページを削除しますか？",
            "受影响的页面包含对象。仍要删除这些页面吗？",
        ],
    ),
    ("Capture", ["Erfassen", "Capturer", "Capturar", "取り込み", "捕捉"]),
    ("Panel Locations", ["Bedienfeldpositionen", "Emplacements des panneaux", "Ubicaciones de paneles", "パネルの位置", "面板位置"]),
    ("First Page", ["Erste Seite", "Première page", "Primera página", "最初のページ", "第一页"]),
    ("Previous Page", ["Vorherige Seite", "Page précédente", "Página anterior", "前のページ", "上一页"]),
    ("Next Page", ["Nächste Seite", "Page suivante", "Página siguiente", "次のページ", "下一页"]),
    ("Last Page", ["Letzte Seite", "Dernière page", "Última página", "最後のページ", "最后一页"]),
    (
        "Close Tab Group",
        ["Registerkartengruppe schließen", "Fermer le groupe d'onglets", "Cerrar grupo de fichas", "タブグループを閉じる", "关闭选项卡组"],
    ),
    ("Minimize", ["Minimieren", "Réduire", "Minimizar", "最小化", "最小化"]),
    ("Collapse to Icons", ["Auf Symbole minimieren", "Réduire en icônes", "Contraer a iconos", "アイコンパネルに折りたたむ", "折叠为图标"]),
    ("Panel Options", ["Bedienfeldoptionen", "Options du panneau", "Opciones de panel", "パネルオプション", "面板选项"]),
    ("Panel Options…", ["Bedienfeldoptionen…", "Options du panneau…", "Opciones de panel…", "パネルオプション…", "面板选项…"]),
    ("Show Thumbnails", ["Miniaturen anzeigen", "Afficher les vignettes", "Mostrar miniaturas", "サムネールを表示", "显示缩览图"]),
    ("Show Vertically", ["Vertikal anzeigen", "Afficher verticalement", "Mostrar verticalmente", "縦に表示", "垂直显示"]),
    ("Panel Layout", ["Bedienfeldlayout", "Disposition du panneau", "Diseño del panel", "パネルレイアウト", "面板版面"]),
    ("Pages on Top", ["Seiten oben", "Pages en haut", "Páginas en la parte superior", "ページを上に表示", "页面在上"]),
    (
        "Parents on Top",
        ["Übergeordnete Seiten oben", "Parents en haut", "Páginas principales en la parte superior", "親ページを上に表示", "父页面在上"],
    ),
    ("Resize:", ["Größe ändern:", "Redimensionner :", "Cambiar tamaño:", "サイズ変更:", "调整大小："]),
    ("Extra Small", ["Sehr klein", "Très petite", "Extra pequeño", "極小", "特小"]),
    ("Small", ["Klein", "Petite", "Pequeño", "小", "小"]),
    ("Medium", ["Mittel", "Moyenne", "Mediano", "中", "中"]),
    ("Large", ["Groß", "Grande", "Grande", "大", "大"]),
    ("Extra Large", ["Sehr groß", "Très grande", "Extra grande", "特大", "特大"]),
    ("Jumbo", ["Riesig", "Géante", "Gigante", "最大", "巨大"]),
    ("Proportional", ["Proportional", "Proportionnel", "Proporcional", "比例", "按比例"]),
    ("Pages Fixed", ["Seiten fixiert", "Pages fixes", "Páginas fijas", "ページを固定", "页面固定"]),
    ("Parents Fixed", ["Übergeordnete fixiert", "Parents fixes", "Páginas principales fijas", "親ページを固定", "父页面固定"]),
    ("Parents", ["Übergeordnete Seiten", "Parents", "Páginas principales", "親ページ", "父页面"]),
    (
        "Bulleted & Numbered Lists",
        [
            "Aufzählungszeichen und nummerierte Listen",
            "Listes à puces et numérotées",
            "Listas con viñetas y numeradas",
            "箇条書き",
            "项目符号列表和编号列表",
        ],
    ),
    ("Current Page Number", ["Aktuelle Seitenzahl", "Numéro de page actuelle", "Número de página actual", "現在のページ番号", "当前页码"]),
    ("Apply Color (,)", ["Farbe anwenden (,)", "Appliquer la couleur (,)", "Aplicar color (,)", "カラーを適用 (,)", "应用颜色 (,)"]),
    ("Apply Gradient (.)", ["Verlauf anwenden (.)", "Appliquer le dégradé (.)", "Aplicar degradado (.)", "グラデーションを適用 (.)", "应用渐变 (.)"]),
    ("View Options", ["Ansichtsoptionen", "Options d’affichage", "Opciones de visualización", "表示オプション", "视图选项"]),
    ("Frame Edges", ["Rahmenkanten", "Bords du bloc", "Bordes del marco", "フレーム枠", "框架边缘"]),
    ("Rulers", ["Lineale", "Règles", "Reglas", "定規", "标尺"]),
    ("Hidden Characters", ["Verborgene Zeichen", "Caractères masqués", "Caracteres ocultos", "制御文字", "隐藏字符"]),
    ("Flex Layout", ["Flex-Layout", "Mise en page flexible", "Diseño flexible", "フレックスレイアウト", "弹性布局"]),
    (
        "Create Flex Layout",
        ["Flex-Layout erstellen", "Créer une mise en page flexible", "Crear diseño flexible", "フレックスレイアウトを作成", "创建弹性布局"],
    ),
    (
        "Add to Flex Layout",
        [
            "Zu Flex-Layout hinzufügen",
            "Ajouter à la mise en page flexible",
            "Añadir a diseño flexible",
            "フレックスレイアウトに追加",
            "添加到弹性布局",
        ],
    ),
    (
        "Convert to Flex Layout",
        [
            "In Flex-Layout umwandeln",
            "Convertir en mise en page flexible",
            "Convertir en diseño flexible",
            "フレックスレイアウトに変換",
            "转换为弹性布局",
        ],
    ),
    (
        "Remove Flex Layout",
        ["Flex-Layout entfernen", "Supprimer la mise en page flexible", "Quitar diseño flexible", "フレックスレイアウトを削除", "移除弹性布局"],
    ),
    (
        "Show Flex Controls",
        [
            "Flex-Steuerelemente einblenden",
            "Afficher les commandes flexibles",
            "Mostrar controles flexibles",
            "フレックスコントロールを表示",
            "显示弹性控件",
        ],
    ),
    (
        "Flex Layout Options",
        ["Flex-Layout-Optionen", "Options de mise en page flexible", "Opciones de diseño flexible", "フレックスレイアウトオプション", "弹性布局选项"],
    ),
    (
        "Reorder in Flex Layout",
        [
            "Im Flex-Layout umordnen",
            "Réorganiser dans la mise en page flexible",
            "Reordenar en diseño flexible",
            "フレックスレイアウト内で並べ替え",
            "在弹性布局中重新排序",
        ],
    ),
    ("Flex Start", ["Flex-Anfang", "Début flexible", "Inicio flexible", "フレックス開始", "弹性起点"]),
    ("Flex End", ["Flex-Ende", "Fin flexible", "Fin flexible", "フレックス終了", "弹性终点"]),
    ("Space Between", ["Abstand dazwischen", "Espace entre", "Espacio entre", "間隔を均等", "两端对齐"]),
    ("Space Around", ["Abstand ringsum", "Espace autour", "Espacio alrededor", "周囲に間隔", "周围间距"]),
    ("Space Evenly", ["Gleichmäßig verteilen", "Espace uniforme", "Espacio uniforme", "均等に配置", "均匀分布"]),
    ("Row", ["Zeile", "Ligne", "Fila", "行", "行"]),
    ("Reverse Row", ["Zeile umgekehrt", "Ligne inversée", "Fila invertida", "行（逆方向）", "反向行"]),
    ("Reverse Column", ["Spalte umgekehrt", "Colonne inversée", "Columna invertida", "列（逆方向）", "反向列"]),
    ("Wrap Content", ["Inhalt umbrechen", "Renvoyer le contenu à la ligne", "Ajustar contenido", "コンテンツを折り返す", "内容换行"]),
    ("Spacing", ["Abstände", "Espacement", "Espaciado", "間隔", "间距"]),
    ("Horizontal Spacing", ["Horizontaler Abstand", "Espacement horizontal", "Espaciado horizontal", "水平方向の間隔", "水平间距"]),
    ("Vertical Spacing", ["Vertikaler Abstand", "Espacement vertical", "Espaciado vertical", "垂直方向の間隔", "垂直间距"]),
    ("Constrain proportions", ["Proportionen beibehalten", "Conserver les proportions", "Restringir proporciones", "縦横比を固定", "约束比例"]),
    ("Auto", ["Automatisch", "Automatique", "Automático", "自動", "自动"]),
    ("W:", ["B:", "L :", "An.:", "幅:", "宽:"]),
    ("H:", ["H:", "H :", "Al.:", "高さ:", "高:"]),
    ("Number:", ["Zahl:", "Numéro:", "Número:", "番号:", "编号："]),
    ("Gutter:", ["Steg:", "Gouttière :", "Medianil:", "間隔:", "栏间距："]),
    ("Fit Guides to:", ["Hilfslinien einpassen in:", "Ajuster les repères à :", "Ajustar guías a:", "ガイドの適用先:", "参考线适合："]),
    ("Top:", ["Oben:", "Haut :", "Superior:", "天:", "上："]),
    ("Bottom:", ["Unten:", "Bas :", "Inferior:", "地:", "下："]),
    ("Inside:", ["Innen:", "Intérieur :", "Interior:", "ノド:", "内："]),
    ("Outside:", ["Außen:", "Extérieur :", "Exterior:", "小口:", "外："]),
    ("Left:", ["Links:", "Gauche :", "Izquierda:", "左:", "左："]),
    ("Right:", ["Rechts:", "Droite :", "Derecha:", "右:", "右："]),
    ("Paths:", ["Pfade:", "Tracés :", "Trazados:", "パス:", "路径："]),
    ("Pathfinder:", ["Pathfinder:", "Pathfinder :", "Buscatrazos:", "パスファインダー:", "路径查找器："]),
    ("Convert Shape:", ["Form konvertieren:", "Convertir la forme :", "Convertir forma:", "シェイプを変換:", "转换形状："]),
    ("Convert Point:", ["Punkt konvertieren:", "Convertir le point :", "Convertir punto:", "ポイントを変換:", "转换点："]),
    ("Join Path", ["Pfad zusammenfügen", "Joindre le tracé", "Unir trazado", "パスを連結", "连接路径"]),
    ("Open Path", ["Pfad öffnen", "Ouvrir le tracé", "Abrir trazado", "パスをオープン", "开放路径"]),
    ("Plain", ["Einfach", "Simple", "Normal", "プレーン", "普通"]),
    ("Symmetrical", ["Symmetrisch", "Symétrique", "Simétrico", "対称", "对称"]),
    (
        "The stroke isn't a gradient.",
        [
            "Die Kontur ist kein Verlauf.",
            "Le contour n’est pas un dégradé.",
            "El trazo no es un degradado.",
            "線はグラデーションではありません。",
            "描边不是渐变。",
        ],
    ),
    ("Baseline Options", ["Grundlinienoptionen", "Options de ligne de base", "Opciones de línea de base", "ベースラインオプション", "基线选项"]),
    ("Fixed Number", ["Feste Anzahl", "Nombre fixe", "Número fijo", "固定数", "固定数字"]),
    ("Fixed Width", ["Feste Breite", "Largeur fixe", "Anchura fija", "固定幅", "固定宽度"]),
    ("Inset Spacing", ["Versatzabstand", "Marge intérieure", "Espaciado de margen interior", "フレーム内マージン", "内边距"]),
    ("Vertical Justification", ["Vertikale Ausrichtung", "Justification verticale", "Justificación vertical", "垂直比率", "垂直对齐"]),
    ("Align:", ["Ausrichten:", "Alignement :", "Alinear:", "整列:", "对齐："]),
    ("Ignore Text Wrap", ["Textumfluss ignorieren", "Ignorer l’habillage", "Ignorar ceñir texto", "テキストの回り込みを無視", "忽略文本绕排"]),
    ("Technique:", ["Technik:", "Technique :", "Técnica:", "テクニック:", "方法："]),
    ("Softer", ["Weicher", "Plus flou", "Más suave", "さらにソフトに", "柔和"]),
    ("Precise", ["Präzise", "Précis", "Precisa", "精細", "精确"]),
    ("Corners:", ["Ecken:", "Angles :", "Esquinas:", "角:", "角点："]),
    ("Sharp", ["Spitz", "Vifs", "Nítidas", "シャープ", "锐利"]),
    ("Diffused", ["Weich", "Diffus", "Difusas", "拡散", "扩散"]),
    ("Reverse Path", ["Pfadrichtung umkehren", "Inverser le tracé", "Invertir trazado", "パスの方向反転", "反转路径"]),
    ("Set Anchor", ["Ankerpunkt festlegen", "Définir le point d’ancrage", "Definir punto de ancla", "アンカーポイントを設定", "设置锚点"]),
    ("Effects…", ["Effekte…", "Effets…", "Efectos…", "効果…", "效果…"]),
    ("Settings for:", ["Einstellungen für:", "Paramètres pour :", "Ajustes para:", "設定対象：", "设置："]),
    ("Transparency", ["Transparenz", "Transparence", "Transparencia", "透明", "透明度"]),
    ("Transparency…", ["Transparenz…", "Transparence…", "Transparencia…", "透明…", "透明度…"]),
    ("Basic Blending", ["Grundlegendes Füllen", "Fusion de base", "Fusión básica", "基本的な描画モード", "基本混合"]),
    ("Opacity:", ["Deckkraft:", "Opacité :", "Opacidad:", "不透明度：", "不透明度："]),
    ("Blending", ["Füllmethode", "Fusion", "Fusión", "描画モード", "混合"]),
    ("Distance:", ["Abstand:", "Distance :", "Distancia:", "距離：", "距离："]),
    ("X Offset:", ["X-Versatz:", "Décalage X :", "Desplazamiento X:", "X オフセット：", "X 位移："]),
    ("Y Offset:", ["Y-Versatz:", "Décalage Y :", "Desplazamiento Y:", "Y オフセット：", "Y 位移："]),
    ("Spread:", ["Größe ändern:", "Étendue :", "Extensión:", "スプレッド：", "扩展："]),
    ("Choke:", ["Unterfüllen:", "Contraction :", "Contracción:", "チョーク：", "收缩："]),
    ("Source:", ["Quelle:", "Source :", "Origen:", "ソース：", "源："]),
    ("Edge", ["Kante", "Contour", "Borde", "エッジ", "边缘"]),
    ("Depth:", ["Tiefe:", "Profondeur :", "Profundidad:", "深さ：", "深度："]),
    ("Highlight:", ["Lichter:", "Lumière :", "Iluminación:", "ハイライト：", "高光："]),
    ("Shadow:", ["Tiefen:", "Ombre :", "Sombra:", "シャドウ：", "阴影："]),
    ("Feather Width:", ["Breite der weichen Kante:", "Largeur du contour progressif :", "Anchura de desvanecimiento:", "ぼかしの幅：", "羽化宽度："]),
    ("Feather Widths", ["Breiten der weichen Kante", "Largeurs du contour progressif", "Anchuras de desvanecimiento", "ぼかしの幅", "羽化宽度"]),
    ("Gradient Stops", ["Verlaufsregler", "Arrêts de dégradé", "Paradas de degradado", "グラデーション分岐点", "渐变色标"]),
    ("Start Opacity:", ["Anfangsdeckkraft:", "Opacité de début :", "Opacidad inicial:", "開始の不透明度：", "起始不透明度："]),
    ("End Opacity:", ["Enddeckkraft:", "Opacité de fin :", "Opacidad final:", "終了の不透明度：", "结束不透明度："]),
    ("(no effects)", ["(keine Effekte)", "(aucun effet)", "(sin efectos)", "(効果なし)", "(无效果)"]),
    ("OBJECT", ["OBJEKT", "OBJET", "OBJETO", "オブジェクト", "对象"]),
    (
        "Add an object effect to the selected target",
        [
            "Dem ausgewählten Ziel einen Objekteffekt hinzufügen",
            "Ajouter un effet d’objet à la cible sélectionnée",
            "Añadir un efecto de objeto al destino seleccionado",
            "選択した対象にオブジェクト効果を追加",
            "为所选目标添加对象效果",
        ],
    ),
    ("Clear", ["Löschen", "Effacer", "Borrar", "消去", "清除"]),
    ("Duplicate", ["Duplizieren", "Dupliquer", "Duplicar", "複製", "重复"]),
    ("Select All", ["Alles auswählen", "Tout sélectionner", "Seleccionar todo", "すべてを選択", "全选"]),
    ("Deselect All", ["Auswahl aufheben", "Tout désélectionner", "Deseleccionar todo", "すべての選択を解除", "取消全选"]),
    ("Find/Change…", ["Suchen/Ersetzen …", "Rechercher/Remplacer…", "Buscar/Cambiar…", "検索と置換…", "查找/更改…"]),
    ("Check Spelling…", ["Rechtschreibprüfung …", "Vérifier l'orthographe…", "Revisar ortografía…", "スペルチェック…", "拼写检查…"]),
    ("Preferences…", ["Voreinstellungen …", "Préférences…", "Preferencias…", "環境設定…", "首选项…"]),
    ("Settings…", ["Einstellungen …", "Réglages…", "Ajustes…", "設定…", "设置…"]),
    (
        "Keyboard Shortcuts…",
        ["Tastaturbefehle …", "Raccourcis clavier…", "Métodos abreviados de teclado…", "キーボードショートカット…", "键盘快捷键…"],
    ),
    ("Interface Language", ["Sprache der Oberfläche", "Langue de l'interface", "Idioma de la interfaz", "インターフェイスの言語", "界面语言"]),
    // Layout.
    ("Pages", ["Seiten", "Pages", "Páginas", "ページ", "页面"]),
    ("Margins and Columns…", ["Ränder und Spalten …", "Marges et colonnes…", "Márgenes y columnas…", "マージン・段組…", "边距和分栏…"]),
    ("Create Guides…", ["Hilfslinien erstellen …", "Créer des repères…", "Crear guías…", "ガイドを作成…", "创建参考线…"]),
    (
        "Numbering & Section Options…",
        [
            "Nummerierungs- und Abschnittsoptionen …",
            "Options de numérotation et de section…",
            "Opciones de numeración y sección…",
            "ノンブルとセクション設定…",
            "页码和章节选项…",
        ],
    ),
    // Type.
    ("Story Direction", ["Textrichtung", "Sens du texte", "Dirección del texto", "組み方向", "文章方向"]),
    ("Horizontal", ["Horizontal", "Horizontal", "Horizontal", "横書き", "水平"]),
    ("Vertical", ["Vertikal", "Vertical", "Vertical", "縦書き", "垂直"]),
    ("Tate-Chu-Yoko", ["Tate-Chu-Yoko", "Tate-Chu-Yoko", "Tate-Chu-Yoko", "縦中横", "纵中横"]),
    ("Ruby…", ["Ruby …", "Ruby…", "Ruby…", "ルビ…", "旁注…"]),
    ("Kenten", ["Kenten", "Kenten", "Kenten", "圏点", "圈点"]),
    ("Warichu", ["Warichu", "Warichu", "Warichu", "割り注", "割注"]),
    // Style Options: CJK sections.
    ("Tate-chu-yoko Settings", ["Tate-Chu-Yoko-Einstellungen", "Paramètres Tate-Chu-Yoko", "Ajustes de Tate-Chu-Yoko", "縦中横設定", "纵中横设置"]),
    ("Kenten Settings", ["Kenten-Einstellungen", "Paramètres Kenten", "Ajustes de Kenten", "圏点設定", "圈点设置"]),
    (
        "Japanese Composition Settings",
        ["Japanischer Satz", "Paramètres de composition japonaise", "Ajustes de composición japonesa", "日本語文字組版", "日文排版设置"],
    ),
    ("Grid Settings", ["Rastereinstellungen", "Paramètres de grille", "Ajustes de cuadrícula", "グリッド設定", "网格设置"]),
    ("Warichu Settings", ["Warichu-Einstellungen", "Paramètres Warichu", "Ajustes de Warichu", "割注設定", "割注设置"]),
    (
        "Auto Tate-chu-yoko Settings",
        [
            "Automatische Tate-Chu-Yoko-Einstellungen",
            "Paramètres Tate-Chu-Yoko automatiques",
            "Ajustes de Tate-Chu-Yoko automático",
            "自動縦中横設定",
            "自动纵中横设置",
        ],
    ),
    (
        "Ruby Placement and Spacing",
        ["Ruby-Position und -Abstand", "Position et espacement ruby", "Posición y espaciado de ruby", "ルビの位置と間隔", "注音位置和间距"],
    ),
    (
        "Ruby Font and Size",
        ["Ruby-Schrift und -Größe", "Police et taille ruby", "Fuente y tamaño de ruby", "ルビのフォントとサイズ", "注音字体和大小"],
    ),
    (
        "Adjustment When Ruby Is Longer Than Parent",
        [
            "Anpassung bei Ruby länger als Grundtext",
            "Ajustement si le ruby dépasse le texte parent",
            "Ajuste cuando el ruby es más largo que la base",
            "ルビが親文字より長い時の調整",
            "注音长于基础文字时的调整",
        ],
    ),
    ("Ruby Color", ["Ruby-Farbe", "Couleur ruby", "Color de ruby", "ルビカラー", "注音颜色"]),
    ("Kenten Color", ["Kenten-Farbe", "Couleur kenten", "Color de kenten", "圏点カラー", "圈点颜色"]),
    ("Shatai", ["Shatai", "Shatai", "Shatai", "斜体", "斜体"]),
    ("Tate-chu-yoko Digits:", ["Tate-Chu-Yoko-Ziffern:", "Chiffres Tate-Chu-Yoko:", "Dígitos Tate-Chu-Yoko:", "組数字（桁まで）:", "纵中横位数："]),
    (
        "Include Roman Characters",
        ["Lateinische Zeichen einbeziehen", "Inclure les caractères latins", "Incluir caracteres latinos", "欧文も含める", "包括罗马字符"],
    ),
    ("Ruby Type:", ["Ruby-Art:", "Type de ruby:", "Tipo de ruby:", "種類:", "注音类型："]),
    ("Per-Character Ruby", ["Einzelzeichen-Ruby", "Ruby par caractère", "Ruby por carácter", "モノルビ", "单字注音"]),
    ("Group Ruby", ["Gruppen-Ruby", "Ruby de groupe", "Ruby de grupo", "グループルビ", "组注音"]),
    ("Left/Top", ["Links/oben", "Gauche/haut", "Izquierda/arriba", "肩付き", "左/上"]),
    ("Centered", ["Zentriert", "Centré", "Centrado", "中付き", "居中"]),
    ("Right/Bottom", ["Rechts/unten", "Droite/bas", "Derecha/abajo", "右／下揃え", "右/下"]),
    ("Full Justify", ["Blocksatz", "Justifié", "Justificado", "両端揃え", "两端对齐"]),
    ("1-2-1 (JIS) Rule", ["1-2-1-Regel (JIS)", "Règle 1-2-1 (JIS)", "Regla 1-2-1 (JIS)", "1-2-1(JIS)ルール", "1-2-1 (JIS) 规则"]),
    ("Equal Aki", ["Gleicher Abstand", "Espacement égal", "Espaciado igual", "均等アキ", "均等间距"]),
    (
        "1 Ruby Character Aki",
        ["1 Ruby-Zeichen Abstand", "Espace de 1 caractère ruby", "Espacio de 1 carácter ruby", "1ルビ文字アキ", "1注音字符间距"],
    ),
    ("Above/Right", ["Oben/rechts", "Au-dessus/à droite", "Arriba/derecha", "上／右", "上/右"]),
    ("Below/Left", ["Unten/links", "En dessous/à gauche", "Abajo/izquierda", "下／左", "下/左"]),
    (
        "Offset from Parent",
        [
            "Versatz zum Grundtext",
            "Décalage par rapport au texte parent",
            "Desplazamiento respecto a la base",
            "親文字からのオフセット",
            "与基础文字的偏移",
        ],
    ),
    ("Across the Line:", ["Quer zur Zeile:", "Perpendiculaire à la ligne:", "Perpendicular a la línea:", "横組み上下／縦組み左右:", "垂直于行："]),
    ("Along the Line:", ["Entlang der Zeile:", "Le long de la ligne:", "A lo largo de la línea:", "横組み左右／縦組み上下:", "沿行方向："]),
    ("Parent's Font", ["Schrift des Grundtexts", "Police du texte parent", "Fuente de la base", "親文字と同じ", "基础文字的字体"]),
    (
        "Use OpenType Pro Ruby Glyphs",
        [
            "OpenType-Pro-Ruby-Glyphen verwenden",
            "Utiliser les glyphes ruby OpenType Pro",
            "Usar glifos ruby de OpenType Pro",
            "OpenType Pro のルビ字形を使用",
            "使用 OpenType Pro 注音字形",
        ],
    ),
    ("Fit to Width", ["An Breite anpassen", "Ajuster à la largeur", "Ajustar al ancho", "幅に合わせる", "适合宽度"]),
    ("Ruby Overhang:", ["Ruby-Überhang:", "Débordement ruby:", "Desbordamiento de ruby:", "文字かけ処理:", "注音悬挂："]),
    ("1 Ruby Character", ["1 Ruby-Zeichen", "1 caractère ruby", "1 carácter ruby", "ルビ1文字分", "1个注音字符"]),
    ("1/2 Ruby Character", ["1/2 Ruby-Zeichen", "1/2 caractère ruby", "1/2 carácter ruby", "ルビ半文字分", "1/2个注音字符"]),
    ("1 Parent Character", ["1 Grundzeichen", "1 caractère parent", "1 carácter base", "親1文字分", "1个基础字符"]),
    ("1/2 Parent Character", ["1/2 Grundzeichen", "1/2 caractère parent", "1/2 carácter base", "親半文字分", "1/2个基础字符"]),
    ("Unlimited", ["Unbegrenzt", "Illimité", "Ilimitado", "無制限", "无限制"]),
    (
        "Parent Character Spacing:",
        ["Abstand im Grundtext:", "Espacement du texte parent:", "Espaciado de la base:", "親文字間の調整:", "基础文字间距调整："],
    ),
    ("No Adjustment", ["Keine Anpassung", "Aucun ajustement", "Sin ajuste", "調整しない", "不调整"]),
    ("Both Sides", ["Beide Seiten", "Des deux côtés", "Ambos lados", "両サイド", "两侧"]),
    ("1-2-1 Aki", ["1-2-1-Abstand", "Espacement 1-2-1", "Espaciado 1-2-1", "1-2-1アキ", "1-2-1 间距"]),
    (
        "Shrink Ruby Width Automatically",
        [
            "Ruby-Breite automatisch verringern",
            "Réduire automatiquement la largeur ruby",
            "Reducir automáticamente el ancho de ruby",
            "ルビの文字幅を自動的に詰める",
            "自动压缩注音宽度",
        ],
    ),
    ("Minimum Scale:", ["Minimale Skalierung:", "Échelle minimale:", "Escala mínima:", "最小比率:", "最小比例："]),
    (
        "Auto Align at Line Start/End",
        [
            "Am Zeilenanfang/-ende automatisch ausrichten",
            "Alignement auto en début/fin de ligne",
            "Alinear automáticamente al inicio/fin de línea",
            "自動行頭／行末揃え",
            "行首/行尾自动对齐",
        ],
    ),
    ("Text Color", ["Textfarbe", "Couleur du texte", "Color del texto", "[自動]", "文字颜色"]),
    (
        "Distance from Parent:",
        ["Abstand zum Grundtext:", "Distance au texte parent:", "Distancia a la base:", "親文字からの間隔:", "与基础文字的距离："],
    ),
    ("Fisheye", ["Fischauge", "Œil de poisson", "Ojo de pez", "蛇の目", "蛇目"]),
    ("Magnification:", ["Verkleinerung:", "Réduction:", "Reducción:", "縮小率:", "缩小率："]),
    ("Adjust Rotation", ["Drehung anpassen", "Ajuster la rotation", "Ajustar rotación", "ライン揃え", "调整旋转"]),
    ("Adjust Tsume", ["Tsume anpassen", "Ajuster le tsume", "Ajustar tsume", "ツメの調整", "调整字距压缩"]),
    (
        "Rotate Roman Characters in Vertical Text",
        [
            "Lateinische Zeichen in vertikalem Text drehen",
            "Faire pivoter les caractères latins en texte vertical",
            "Girar caracteres latinos en texto vertical",
            "縦組み中の欧文回転",
            "直排中旋转罗马字符",
        ],
    ),
    (
        "Roman Word Break",
        ["Lateinische Wörter beliebig trennen", "Coupure libre des mots latins", "Corte libre de palabras latinas", "欧文泣き別れ", "西文单词断开"],
    ),
    ("ICF Top", ["ICF oben", "Haut ICF", "Parte superior ICF", "平均字面の上", "平均字面上"]),
    ("ICF Bottom", ["ICF unten", "Bas ICF", "Parte inferior ICF", "平均字面の下", "平均字面下"]),
    ("Gyoudori:", ["Gyoudori:", "Gyoudori:", "Gyoudori:", "行取り:", "行取："]),
    (
        "Use Paragraph Gyoudori",
        ["Absatz-Gyoudori verwenden", "Utiliser le gyoudori de paragraphe", "Usar gyoudori de párrafo", "段落行取りを使用", "使用段落行取"],
    ),
    ("Up/Down Position:", ["Position oben/unten:", "Position haut/bas:", "Posición arriba/abajo:", "上下位置:", "上下位置："]),
    ("Left/Right Position:", ["Position links/rechts:", "Position gauche/droite:", "Posición izquierda/derecha:", "左右位置:", "左右位置："]),
    ("Kenten Type:", ["Kenten-Art:", "Type de kenten:", "Tipo de kenten:", "圏点種類:", "圈点类型："]),
    ("Sesame Dot", ["Sesampunkt", "Point sésame", "Punto de sésamo", "ゴマ", "芝麻点"]),
    ("White Sesame Dot", ["Weißer Sesampunkt", "Point sésame blanc", "Punto de sésamo blanco", "白ゴマ", "空心芝麻点"]),
    ("Bullseye", ["Zielscheibe", "Cible", "Diana", "蛇の目", "靶心"]),
    ("Black Circle", ["Schwarzer Kreis", "Cercle noir", "Círculo negro", "黒丸", "实心圆"]),
    ("Small Black Circle", ["Kleiner schwarzer Kreis", "Petit cercle noir", "Círculo negro pequeño", "小さい黒丸", "小实心圆"]),
    ("Double Circle", ["Doppelkreis", "Double cercle", "Círculo doble", "二重丸", "双圆"]),
    ("Black Triangle", ["Schwarzes Dreieck", "Triangle noir", "Triángulo negro", "黒三角", "实心三角"]),
    ("White Triangle", ["Weißes Dreieck", "Triangle blanc", "Triángulo blanco", "白三角", "空心三角"]),
    ("White Circle", ["Weißer Kreis", "Cercle blanc", "Círculo blanco", "白丸", "空心圆"]),
    ("Small White Circle", ["Kleiner weißer Kreis", "Petit cercle blanc", "Círculo blanco pequeño", "小さい白丸", "小空心圆"]),
    ("Character:", ["Zeichen:", "Caractère:", "Carácter:", "文字:", "字符："]),
    ("Kinsoku Set:", ["Kinsoku-Satz:", "Jeu kinsoku:", "Conjunto kinsoku:", "禁則処理セット:", "避头尾集："]),
    ("Default Rules", ["Standardregeln", "Règles par défaut", "Reglas predeterminadas", "既定の規則", "默认规则"]),
    ("Hard Kinsoku", ["Hartes Kinsoku", "Kinsoku strict", "Kinsoku estricto", "強い禁則", "严格避头尾"]),
    ("Soft Kinsoku", ["Weiches Kinsoku", "Kinsoku souple", "Kinsoku flexible", "弱い禁則", "宽松避头尾"]),
    (
        "Simplified Chinese Kinsoku",
        ["Kinsoku für vereinfachtes Chinesisch", "Kinsoku chinois simplifié", "Kinsoku de chino simplificado", "簡体中国語禁則", "简体中文避头尾"],
    ),
    (
        "Traditional Chinese Kinsoku",
        ["Kinsoku für traditionelles Chinesisch", "Kinsoku chinois traditionnel", "Kinsoku de chino tradicional", "繁体中国語禁則", "繁体中文避头尾"],
    ),
    ("Korean Kinsoku", ["Koreanisches Kinsoku", "Kinsoku coréen", "Kinsoku coreano", "韓国語禁則", "韩文避头尾"]),
    ("Kinsoku Type:", ["Kinsoku-Methode:", "Type de kinsoku:", "Tipo de kinsoku:", "禁則調整方式:", "避头尾调整方式："]),
    ("Push In First", ["Zuerst einziehen", "Rentrer d'abord", "Primero hacia dentro", "追い込み優先", "先推入"]),
    ("Push Out First", ["Zuerst hinausschieben", "Repousser d'abord", "Primero hacia fuera", "追い出し優先", "先推出"]),
    ("Push Out Only", ["Nur hinausschieben", "Repousser uniquement", "Solo hacia fuera", "追い出しのみ", "仅推出"]),
    (
        "Prioritize Adjustment Amount",
        ["Anpassungsbetrag bevorzugen", "Priorité à la valeur d'ajustement", "Priorizar la cantidad de ajuste", "調整量を優先", "优先调整量"],
    ),
    ("Hanging Type:", ["Hängende Interpunktion:", "Ponctuation suspendue:", "Puntuación colgante:", "ぶら下がり方法:", "悬挂方式："]),
    ("Force", ["Erzwingen", "Forcer", "Forzar", "強制", "强制"]),
    ("Bunri-Kinshi", ["Bunri-Kinshi", "Bunri-Kinshi", "Bunri-Kinshi", "分離禁止処理", "分离禁止"]),
    ("Mojikumi Set:", ["Mojikumi-Satz:", "Jeu mojikumi:", "Conjunto mojikumi:", "文字組み:", "标点挤压集："]),
    ("Leading Model:", ["Zeilenabstandsmodell:", "Modèle d'interlignage:", "Modelo de interlineado:", "行送りの基準位置:", "行距基准位置："]),
    (
        "Em Box Top/Right",
        ["Geviert oben/rechts", "Haut/droite du cadratin", "Parte superior/derecha del cuadratín", "仮想ボディの上／右", "全角字框上/右"],
    ),
    ("Em Box Center", ["Geviert Mitte", "Centre du cadratin", "Centro del cuadratín", "仮想ボディの中央", "全角字框居中"]),
    (
        "Em Box Bottom/Left",
        ["Geviert unten/links", "Bas/gauche du cadratin", "Parte inferior/izquierda del cuadratín", "仮想ボディの下／左", "全角字框下/左"],
    ),
    (
        "Em Box Center (Down)",
        ["Geviert Mitte (unten)", "Centre du cadratin (bas)", "Centro del cuadratín (abajo)", "仮想ボディの中央（下）", "全角字框居中（下）"],
    ),
    ("Roman Baseline", ["Lateinische Grundlinie", "Ligne de base romaine", "Línea de base romana", "欧文ベースライン", "罗马字基线"]),
    ("Rensuuji", ["Rensuuji", "Rensuuji", "Rensuuji", "連数字処理", "连数字处理"]),
    (
        "Absorb Ideographic Space at Line End",
        [
            "Ideografisches Leerzeichen am Zeilenende absorbieren",
            "Absorber l'espace idéographique en fin de ligne",
            "Absorber el espacio ideográfico al final de línea",
            "全角スペースを行末吸収",
            "行尾吸收全角空格",
        ],
    ),
    ("Grid Alignment:", ["Am Raster ausrichten:", "Alignement sur la grille:", "Alineación con cuadrícula:", "グリッド揃え:", "网格对齐："]),
    (
        "Align Only First Line to Grid",
        [
            "Nur erste Zeile am Raster ausrichten",
            "Aligner uniquement la première ligne sur la grille",
            "Alinear solo la primera línea con la cuadrícula",
            "1 行目のみグリッドに揃える",
            "仅首行对齐网格",
        ],
    ),
    ("Warichu Size:", ["Warichu-Größe:", "Taille warichu:", "Tamaño de warichu:", "割注サイズ:", "割注大小："]),
    ("Line Spacing:", ["Zeilenabstand:", "Interligne:", "Interlineado:", "行の間隔:", "行间距："]),
    ("Line Break Options", ["Umbruchoptionen", "Options de saut de ligne", "Opciones de salto de línea", "改行オプション", "换行选项"]),
    (
        "Characters Before Break:",
        ["Zeichen vor dem Umbruch:", "Caractères avant le saut:", "Caracteres antes del salto:", "1 行目の最小文字数:", "换行前最少字符数："],
    ),
    (
        "Characters After Break:",
        ["Zeichen nach dem Umbruch:", "Caractères après le saut:", "Caracteres después del salto:", "最終行の最小文字数:", "换行后最少字符数："],
    ),
    ("Font", ["Schriftart", "Police", "Fuente", "フォント", "字体"]),
    ("Size", ["Schriftgrad", "Corps", "Tamaño", "サイズ", "大小"]),
    ("Character", ["Zeichen", "Caractère", "Carácter", "文字", "字符"]),
    ("Paragraph", ["Absatz", "Paragraphe", "Párrafo", "段落", "段落"]),
    ("Tabs", ["Tabulatoren", "Tabulations", "Tabulaciones", "タブ", "制表符"]),
    (
        "Left-aligned tab",
        ["Linksbündiger Tabulator", "Tabulation alignée à gauche", "Tabulación alineada a la izquierda", "左揃えタブ", "左对齐制表符"],
    ),
    ("Centered tab", ["Zentrierter Tabulator", "Tabulation centrée", "Tabulación centrada", "中央揃えタブ", "居中对齐制表符"]),
    (
        "Right-aligned tab",
        ["Rechtsbündiger Tabulator", "Tabulation alignée à droite", "Tabulación alineada a la derecha", "右揃えタブ", "右对齐制表符"],
    ),
    (
        "Tab aligned on a character",
        [
            "Am Zeichen ausgerichteter Tabulator",
            "Tabulation alignée sur un caractère",
            "Tabulación alineada en un carácter",
            "文字揃えタブ",
            "按字符对齐制表符",
        ],
    ),
    ("X:", ["X:", "X :", "X:", "X:", "X:"]),
    ("Leader:", ["Füllzeichen:", "Points de suite :", "Carácter de relleno:", "リーダー:", "前导符:"]),
    ("Align On:", ["Ausrichten an:", "Aligner sur :", "Alinear en:", "揃える文字:", "对齐位置:"]),
    (
        "Position panel above text frame",
        [
            "Bedienfeld über dem Textrahmen platzieren",
            "Placer le panneau au-dessus du bloc de texte",
            "Colocar el panel sobre el marco de texto",
            "パネルをテキストフレームの上に配置",
            "将面板置于文本框上方",
        ],
    ),
    ("Clear All", ["Alle löschen", "Tout effacer", "Borrar todo", "すべてを消去", "全部清除"]),
    ("Delete Tab", ["Tabulator löschen", "Supprimer la tabulation", "Eliminar tabulación", "タブを削除", "删除制表符"]),
    ("Repeat Tab", ["Tabulator wiederholen", "Répéter la tabulation", "Repetir tabulación", "タブを繰り返し", "重复制表符"]),
    ("Reset Indents", ["Einzüge zurücksetzen", "Réinitialiser les retraits", "Restablecer sangrías", "インデントをリセット", "重置缩进"]),
    ("Glyphs", ["Glyphen", "Glyphes", "Glifos", "字形", "字形"]),
    ("Story", ["Textabschnitt", "Article", "Artículo", "ストーリー", "文章"]),
    ("Character Styles", ["Zeichenformate", "Styles de caractère", "Estilos de carácter", "文字スタイル", "字符样式"]),
    ("Paragraph Styles", ["Absatzformate", "Styles de paragraphe", "Estilos de párrafo", "段落スタイル", "段落样式"]),
    ("Create Outlines", ["In Pfade umwandeln", "Vectoriser", "Crear contornos", "アウトラインを作成", "创建轮廓"]),
    (
        "Show Hidden Characters",
        ["Verborgene Zeichen einblenden", "Afficher les caractères masqués", "Mostrar caracteres ocultos", "制御文字を表示", "显示隐藏字符"],
    ),
    // Object.
    ("Transform", ["Transformieren", "Transformation", "Transformar", "変形", "变换"]),
    ("Arrange", ["Anordnen", "Disposition", "Organizar", "重ね順", "排列"]),
    ("Group", ["Gruppieren", "Associer", "Agrupar", "グループ", "编组"]),
    ("Ungroup", ["Gruppierung aufheben", "Dissocier", "Desagrupar", "グループ解除", "取消编组"]),
    ("Lock", ["Sperren", "Verrouiller", "Bloquear", "ロック", "锁定"]),
    ("Hide", ["Ausblenden", "Masquer", "Ocultar", "隠す", "隐藏"]),
    ("Effects", ["Effekte", "Effets", "Efectos", "効果", "效果"]),
    ("Fitting", ["Anpassen", "Ajustement", "Encaje", "オブジェクトサイズの調整", "适合"]),
    (
        "Text Frame Options…",
        ["Textrahmenoptionen …", "Options de bloc de texte…", "Opciones de marco de texto…", "テキストフレーム設定…", "文本框架选项…"],
    ),
    // Table.
    ("Insert Table…", ["Tabelle einfügen …", "Insérer un tableau…", "Insertar tabla…", "表を挿入…", "插入表…"]),
    ("Merge Cells", ["Zellen verbinden", "Fusionner les cellules", "Combinar celdas", "セルを結合", "合并单元格"]),
    ("Unmerge Cells", ["Zellverbindung aufheben", "Annuler la fusion des cellules", "Separar celdas", "セルの結合解除", "取消合并单元格"]),
    ("Insert", ["Einfügen", "Insérer", "Insertar", "挿入", "插入"]),
    ("Delete", ["Löschen", "Supprimer", "Eliminar", "削除", "删除"]),
    // View.
    ("Zoom In", ["Einzoomen", "Zoom avant", "Acercar", "ズームイン", "放大"]),
    ("Zoom Out", ["Auszoomen", "Zoom arrière", "Alejar", "ズームアウト", "缩小"]),
    (
        "Fit Page in Window",
        ["Seite in Fenster einpassen", "Ajuster la page à la fenêtre", "Encajar página en ventana", "ページ全体", "使页面适合窗口"],
    ),
    (
        "Fit Spread in Window",
        ["Druckbogen in Fenster einpassen", "Ajuster la planche à la fenêtre", "Encajar pliego en ventana", "スプレッド全体", "使跨页适合窗口"],
    ),
    ("Actual Size", ["Originalgröße", "Taille réelle", "Tamaño real", "100%", "实际大小"]),
    ("Screen Mode", ["Bildschirmmodus", "Mode de l'écran", "Modo de pantalla", "スクリーンモード", "屏幕模式"]),
    ("Grids & Guides", ["Raster und Hilfslinien", "Grilles et repères", "Cuadrículas y guías", "グリッドとガイド", "网格和参考线"]),
    ("Show Rulers", ["Lineale einblenden", "Afficher les règles", "Mostrar reglas", "定規を表示", "显示标尺"]),
    ("Snap to Guides", ["An Hilfslinien ausrichten", "Magnétisme des repères", "Ajustar a las guías", "ガイドにスナップ", "靠齐参考线"]),
    (
        "Snap to Document Grid",
        [
            "Am Dokumentraster ausrichten",
            "Magnétisme de la grille du document",
            "Ajustar a la cuadrícula del documento",
            "ドキュメントグリッドにスナップ",
            "靠齐文档网格",
        ],
    ),
    ("Smart Guides", ["Smarte Hilfslinien", "Repères commentés", "Guías inteligentes", "スマートガイド", "智能参考线"]),
    (
        "Align to Object Edges",
        [
            "An Objektkanten ausrichten",
            "Aligner sur les bords des objets",
            "Alinear a los bordes del objeto",
            "オブジェクトの端に揃える",
            "对齐对象边缘",
        ],
    ),
    (
        "Align to Object Centers",
        [
            "An Objektmitten ausrichten",
            "Aligner sur les centres des objets",
            "Alinear a los centros del objeto",
            "オブジェクトの中心に揃える",
            "对齐对象中心",
        ],
    ),
    ("Smart Dimensions", ["Smarte Maße", "Dimensions commentées", "Dimensiones inteligentes", "スマートサイズ", "智能尺寸"]),
    ("Smart Spacing", ["Smarte Abstände", "Espacement commenté", "Espaciado inteligente", "スマート間隔", "智能间距"]),
    ("Snap to Zone", ["Fangzone", "Zone de magnétisme", "Zona de ajuste", "スナップゾーン", "靠齐区域"]),
    // Window and panels.
    ("Properties", ["Eigenschaften", "Propriétés", "Propiedades", "プロパティ", "属性"]),
    ("Layers", ["Ebenen", "Calques", "Capas", "レイヤー", "图层"]),
    ("Links", ["Verknüpfungen", "Liens", "Vínculos", "リンク", "链接"]),
    ("Swatches", ["Farbfelder", "Nuancier", "Muestras", "スウォッチ", "色板"]),
    ("Color", ["Farbe", "Couleur", "Color", "カラー", "颜色"]),
    ("Stroke", ["Kontur", "Contour", "Trazo", "線", "描边"]),
    ("Gradient", ["Verlauf", "Dégradé", "Degradado", "グラデーション", "渐变"]),
    ("Align", ["Ausrichten", "Alignement", "Alinear", "整列", "对齐"]),
    ("Pathfinder", ["Pathfinder", "Pathfinder", "Buscatrazos", "パスファインダー", "路径查找器"]),
    ("Info", ["Info", "Informations", "Información", "情報", "信息"]),
    ("Library", ["Bibliothek", "Bibliothèque", "Biblioteca", "ライブラリ", "库"]),
    ("Book", ["Buch", "Livre", "Libro", "ブック", "书籍"]),
    ("Index", ["Index", "Index", "Índice", "索引", "索引"]),
    ("Hyperlinks", ["Hyperlinks", "Hyperliens", "Hipervínculos", "ハイパーリンク", "超链接"]),
    ("Bookmarks", ["Lesezeichen", "Signets", "Marcadores", "ブックマーク", "书签"]),
    ("Articles", ["Artikel", "Articles", "Artículos", "アーティクル", "文章"]),
    ("Tags", ["Tags", "Balises", "Etiquetas", "タグ", "标签"]),
    ("Media", ["Medien", "Multimédia", "Medios", "メディア", "媒体"]),
    ("Object States", ["Objektstatus", "États d'objet", "Estados de objeto", "オブジェクトステート", "对象状态"]),
    ("Buttons and Forms", ["Schaltflächen und Formulare", "Boutons et formulaires", "Botones y formularios", "ボタンとフォーム", "按钮和表单"]),
    ("Liquid Layout", ["Flüssiges Layout", "Mise en page liquide", "Maquetación líquida", "リキッドレイアウト", "自适应版面"]),
    ("Workspace", ["Arbeitsbereich", "Espace de travail", "Espacio de trabajo", "ワークスペース", "工作区"]),
    ("Editorial", ["Redaktion", "Éditorial", "Editorial", "エディトリアル", "编辑"]),
    ("Object & Layout", ["Objekt und Layout", "Objet et mise en page", "Objeto y diseño", "オブジェクト＆レイアウト", "对象和版面"]),
    ("Styles", ["Formate", "Styles", "Estilos", "スタイル", "样式"]),
    ("Essentials Classic", ["Essentials Classic", "Essentials Classic", "Essentials Classic", "Essentials Classic", "基本功能（经典）"]),
    ("Split Window", ["Fenster teilen", "Fractionner la fenêtre", "Dividir ventana", "ウィンドウを分割", "拆分窗口"]),
    ("New Window", ["Neues Fenster", "Nouvelle fenêtre", "Nueva ventana", "新規ウィンドウ", "新建窗口"]),
    (
        "Show All Menu Items",
        [
            "Alle Menüelemente anzeigen",
            "Afficher toutes les commandes",
            "Mostrar todos los elementos de menú",
            "すべてのメニュー項目を表示",
            "显示所有菜单项",
        ],
    ),
    ("Accept All", ["Accept All", "Tout accepter", "Accept All", "Accept All", "全部接受"]),
    ("Add", ["Add", "Ajouter", "Add", "Add", "添加"]),
    ("Add Document…", ["Add Document…", "Ajouter un document…", "Add Document…", "Add Document…", "添加文档…"]),
    (
        "Add to Previous Spread",
        ["Add to Previous Spread", "Ajouter à la planche précédente", "Add to Previous Spread", "Add to Previous Spread", "添加到上一个跨页"],
    ),
    ("Align From:", ["Align From:", "Aligner depuis :", "Align From:", "Align From:", "对齐自："]),
    (
        "Align to baseline grid",
        ["Align to baseline grid", "Aligner sur la grille de ligne de base", "Align to baseline grid", "Align to baseline grid", "对齐基线网格"],
    ),
    ("Alignment:", ["Alignment:", "Alignement :", "Alignment:", "Alignment:", "对齐："]),
    (
        "All Spots to Process",
        ["All Spots to Process", "Tous les tons directs en quadrichromie", "All Spots to Process", "All Spots to Process", "所有专色转四色"],
    ),
    (
        "Allow Spread to Shuffle",
        [
            "Allow Spread to Shuffle",
            "Autoriser la réorganisation des pages de la planche",
            "Allow Spread to Shuffle",
            "Allow Spread to Shuffle",
            "允许跨页无序",
        ],
    ),
    (
        "Alternating Row Fills",
        ["Alternating Row Fills", "Fonds de ligne en alternance", "Alternating Row Fills", "Alternating Row Fills", "交替行填色"],
    ),
    ("Appearance", ["Appearance", "Apparence", "Appearance", "Appearance", "外观"]),
    ("Apply Gradient", ["Apply Gradient", "Appliquer le dégradé", "Apply Gradient", "Apply Gradient", "应用渐变"]),
    ("Apply Parent", ["Apply Parent", "Appliquer le gabarit", "Apply Parent", "Apply Parent", "应用主页"]),
    ("Apply Style:", ["Apply Style:", "Appliquer le style :", "Apply Style:", "Apply Style:", "应用样式："]),
    (
        "Apply to All Spreads",
        ["Apply to All Spreads", "Appliquer à toutes les planches", "Apply to All Spreads", "Apply to All Spreads", "应用到所有跨页"],
    ),
    ("Apply to Stroke", ["Apply to Stroke", "Appliquer au contour", "Apply to Stroke", "Apply to Stroke", "应用到描边"]),
    ("Art", ["Art", "Illustration", "Art", "Art", "画板"]),
    ("Based On:", ["Based On:", "Basé sur :", "Based On:", "Based On:", "基于："]),
    ("Bleed", ["Bleed", "Fond perdu", "Bleed", "Bleed", "出血"]),
    ("Bleed Marks", ["Beschnittmarken", "Repères de fond perdu", "Marcas de sangrado", "塗り足しマーク", "出血标记"]),
    ("Body Rows", ["Body Rows", "Lignes de corps", "Body Rows", "Body Rows", "表体行"]),
    ("Bottom", ["Bottom", "Bas", "Bottom", "Bottom", "底部"]),
    (
        "Break Link to Style",
        ["Break Link to Style", "Rompre le lien avec le style", "Break Link to Style", "Break Link to Style", "断开与样式的链接"],
    ),
    ("Redefine Style", ["Format neu definieren", "Redéfinir le style", "Redefinir estilo", "スタイルを再定義", "重新定义样式"]),
    ("Bullets and Numbering", ["Bullets and Numbering", "Puces et numérotation", "Bullets and Numbering", "Bullets and Numbering", "项目符号和编号"]),
    ("Business Card", ["Business Card", "Carte de visite", "Business Card", "Business Card", "名片"]),
    ("CMYK", ["CMYK", "CMJN", "CMYK", "CMYK", "CMYK"]),
    ("Cancel", ["Cancel", "Annuler", "Cancel", "Cancel", "取消"]),
    (
        "Can't Open the File",
        [
            "Datei kann nicht geöffnet werden",
            "Impossible d'ouvrir le fichier",
            "No se puede abrir el archivo",
            "ファイルを開けません",
            "无法打开文件",
        ],
    ),
    (
        "Can't Place the File",
        [
            "Datei kann nicht platziert werden",
            "Impossible d'importer le fichier",
            "No se puede colocar el archivo",
            "ファイルを配置できません",
            "无法置入文件",
        ],
    ),
    ("Center Content", ["Center Content", "Centrer le contenu", "Center Content", "Center Content", "内容居中"]),
    ("Change All", ["Change All", "Tout remplacer", "Change All", "Change All", "全部更改"]),
    ("Change to:", ["Change to:", "Remplacer par :", "Change to:", "Change to:", "更改为："]),
    ("Character Style:", ["Character Style:", "Style de caractère :", "Character Style:", "Character Style:", "字符样式："]),
    ("Checked by default", ["Checked by default", "Cochée par défaut", "Checked by default", "Checked by default", "默认选中"]),
    ("Choices", ["Choices", "Choix", "Choices", "Choices", "选项"]),
    ("Choose Image…", ["Choose Image…", "Choisir une image…", "Choose Image…", "Choose Image…", "选择图像…"]),
    ("Class:", ["Class:", "Classe :", "Class:", "Class:", "类别："]),
    ("Color Picker", ["Color Picker", "Sélecteur de couleurs", "Color Picker", "Color Picker", "拾色器"]),
    ("Color Settings", ["Color Settings", "Réglages des couleurs", "Color Settings", "Color Settings", "颜色设置"]),
    ("Color:", ["Color:", "Couleur :", "Color:", "Color:", "颜色："]),
    ("Columns", ["Columns", "Colonnes", "Columns", "Columns", "栏"]),
    ("Composer:", ["Composer:", "Compositeur :", "Composer:", "Composer:", "排版器："]),
    ("Copies:", ["Copies:", "Copies :", "Copies:", "Copies:", "份数："]),
    ("Count", ["Count", "Compter", "Count", "Count", "数量"]),
    ("Create", ["Create", "Créer", "Create", "Create", "创建"]),
    ("Create Table", ["Create Table", "Créer un tableau", "Create Table", "Create Table", "创建表"]),
    ("Create Table…", ["Create Table…", "Créer un tableau…", "Create Table…", "Create Table…", "创建表…"]),
    ("Crop", ["Crop", "Recadrage", "Crop", "Crop", "裁剪"]),
    ("Crop Marks", ["Schnittmarken", "Traits de coupe", "Marcas de recorte", "トンボ", "裁切标记"]),
    ("Crop to:", ["Crop to:", "Recadrer selon :", "Crop to:", "Crop to:", "裁剪到："]),
    ("Cursor Key:", ["Cursor Key:", "Touche fléchée :", "Cursor Key:", "Cursor Key:", "光标键："]),
    ("Default", ["Default", "Par défaut", "Default", "Default", "默认"]),
    ("Default View:", ["Default View:", "Affichage par défaut :", "Default View:", "Default View:", "默认视图："]),
    ("Delete Column", ["Delete Column", "Supprimer la colonne", "Delete Column", "Delete Column", "删除列"]),
    ("Delete Condition", ["Delete Condition", "Supprimer la condition", "Delete Condition", "Delete Condition", "删除条件"]),
    ("Delete Layer", ["Delete Layer", "Supprimer le calque", "Delete Layer", "Delete Layer", "删除图层"]),
    ("Delete Page", ["Delete Page", "Supprimer la page", "Delete Page", "Delete Page", "删除页面"]),
    ("Delete Row", ["Delete Row", "Supprimer la ligne", "Delete Row", "Delete Row", "删除行"]),
    ("Delete Swatch", ["Delete Swatch", "Supprimer la nuance", "Delete Swatch", "Delete Swatch", "删除色板"]),
    (
        "Delete Unused Layers",
        ["Delete Unused Layers", "Supprimer les calques inutilisés", "Delete Unused Layers", "Delete Unused Layers", "删除未使用的图层"],
    ),
    ("Desired", ["Desired", "Optimal", "Desired", "Desired", "最佳"]),
    ("Dialog", ["Dialog", "Boîte de dialogue", "Dialog", "Dialog", "对话框"]),
    ("Document", ["Document", "Document", "Document", "Document", "文档"]),
    ("Document Setup", ["Document Setup", "Format de document", "Document Setup", "Document Setup", "文档设置"]),
    ("Drop Shadow", ["Drop Shadow", "Ombre portée", "Drop Shadow", "Drop Shadow", "投影"]),
    ("Duplicate Spread", ["Duplicate Spread", "Dupliquer la planche", "Duplicate Spread", "Duplicate Spread", "复制跨页"]),
    (
        "Duplicate Spread at End of Document",
        [
            "Druckbogen am Dokumentende duplizieren",
            "Dupliquer la planche à la fin du document",
            "Duplicar pliego al final del documento",
            "ドキュメントの最後にスプレッドを複製",
            "在文档末尾复制跨页",
        ],
    ),
    ("Delete Spread", ["Druckbogen löschen", "Supprimer la planche", "Eliminar pliego", "スプレッドを削除", "删除跨页"]),
    ("Parent Pages", ["Übergeordnete Seiten", "Pages parents", "Páginas principales", "親ページ", "父页面"]),
    (
        "Apply Parent to Pages",
        [
            "Übergeordnete Seite auf Seiten anwenden",
            "Appliquer le gabarit aux pages",
            "Aplicar principal a páginas",
            "親ページを適用",
            "将父页面应用于页面",
        ],
    ),
    ("Email", ["Email", "E-mail", "Email", "Email", "电子邮件"]),
    ("Embed", ["Embed", "Incorporer", "Embed", "Embed", "嵌入"]),
    ("Export PDF", ["PDF exportieren", "Exporter en PDF", "Exportar PDF", "PDF を書き出し", "导出PDF"]),
    ("Export XML…", ["Export XML…", "Exporter en XML…", "Export XML…", "Export XML…", "导出XML…"]),
    ("Fast", ["Fast", "Rapide", "Fast", "Fast", "快速"]),
    (
        "Fill Frame Proportionally",
        [
            "Fill Frame Proportionally",
            "Remplir le bloc proportionnellement",
            "Fill Frame Proportionally",
            "Fill Frame Proportionally",
            "按比例填充框架",
        ],
    ),
    ("Find All", ["Find All", "Tout rechercher", "Find All", "Find All", "查找全部"]),
    ("Find Next", ["Find Next", "Rechercher suivant", "Find Next", "Find Next", "查找下一个"]),
    ("Find what:", ["Find what:", "Rechercher :", "Find what:", "Find what:", "查找内容："]),
    ("Find/Change", ["Find/Change", "Rechercher/Remplacer", "Find/Change", "Find/Change", "查找/更改"]),
    ("Find/Replace Font", ["Find/Replace Font", "Rechercher/Remplacer une police", "Find/Replace Font", "Find/Replace Font", "查找/替换字体"]),
    (
        "Fit Content Proportionally",
        [
            "Fit Content Proportionally",
            "Ajuster le contenu proportionnellement",
            "Fit Content Proportionally",
            "Fit Content Proportionally",
            "按比例适合内容",
        ],
    ),
    ("Fit Content to Frame", ["Fit Content to Frame", "Ajuster le contenu au bloc", "Fit Content to Frame", "Fit Content to Frame", "内容适合框架"]),
    ("Fitting:", ["Fitting:", "Ajustement :", "Fitting:", "Fitting:", "适合："]),
    (
        "Flattener preset",
        ["Voreinstellung für Transparenzreduzierung", "Préréglage d'aplatissement", "Preajuste de acoplado", "透明分割プリセット", "拼合器预设"],
    ),
    ("Font Family:", ["Font Family:", "Famille de polices :", "Font Family:", "Font Family:", "字体系列："]),
    ("Font Size:", ["Font Size:", "Corps :", "Font Size:", "Font Size:", "字体大小："]),
    ("Font Style:", ["Font Style:", "Style de police :", "Font Style:", "Font Style:", "字体样式："]),
    ("Footer Rows", ["Footer Rows", "Lignes de pied de tableau", "Footer Rows", "Footer Rows", "表尾行"]),
    ("Footnote Options", ["Footnote Options", "Options des notes de bas de page", "Footnote Options", "Footnote Options", "脚注选项"]),
    ("Form Field", ["Form Field", "Champ de formulaire", "Form Field", "Form Field", "表单字段"]),
    ("Format:", ["Format:", "Format :", "Format:", "Format:", "格式："]),
    ("Frame Fitting", ["Frame Fitting", "Ajustement au bloc", "Frame Fitting", "Frame Fitting", "框架适合"]),
    (
        "Frame Fitting Options",
        ["Frame Fitting Options", "Options d'ajustement au bloc", "Frame Fitting Options", "Frame Fitting Options", "框架适合选项"],
    ),
    ("Generate QR Code", ["Generate QR Code", "Générer un code QR", "Generate QR Code", "Generate QR Code", "生成二维码"]),
    ("Go To", ["Go To", "Atteindre", "Go To", "Go To", "转到"]),
    ("Go to Page", ["Go to Page", "Atteindre la page", "Go to Page", "Go to Page", "转到页面"]),
    ("Gutter", ["Gutter", "Gouttière", "Gutter", "Gutter", "栏间距"]),
    ("Header Rows", ["Header Rows", "Lignes d'en-tête", "Header Rows", "Header Rows", "表头行"]),
    ("Height", ["Height", "Hauteur", "Height", "Height", "高度"]),
    ("Height:", ["Height:", "Hauteur :", "Height:", "Height:", "高度："]),
    ("High Quality", ["High Quality", "Qualité supérieure", "High Quality", "High Quality", "高品质"]),
    ("Desktop Printing", ["Bürodruck", "Impression bureautique", "Impresión de oficina", "オフィス印刷", "办公打印"]),
    (
        "Horizontal Gridline Every:",
        [
            "Horizontal Gridline Every:",
            "Ligne de grille horizontale tous les :",
            "Horizontal Gridline Every:",
            "Horizontal Gridline Every:",
            "水平网格线间隔：",
        ],
    ),
    ("Horizontal Margins:", ["Horizontal Margins:", "Marges horizontales :", "Horizontal Margins:", "Horizontal Margins:", "水平边距："]),
    ("Hyphenate", ["Hyphenate", "Césure", "Hyphenate", "Hyphenate", "连字符"]),
    ("Import Options", ["Import Options", "Options d'importation", "Import Options", "Import Options", "导入选项"]),
    ("Import XML…", ["Import XML…", "Importer XML…", "Import XML…", "Import XML…", "导入XML…"]),
    (
        "Include document bleed",
        [
            "Dokumentbeschnitt einschließen",
            "Inclure le fond perdu du document",
            "Incluir sangrado del documento",
            "ドキュメントの塗り足しを含める",
            "包含文档出血",
        ],
    ),
    ("Increment Every:", ["Increment Every:", "Ligne de grille tous les :", "Increment Every:", "Increment Every:", "递增步长："]),
    ("Ink Manager", ["Ink Manager", "Gestionnaire d'encres", "Ink Manager", "Ink Manager", "油墨管理器"]),
    ("Insert Column", ["Insert Column", "Insérer une colonne", "Insert Column", "Insert Column", "插入列"]),
    ("Insert Page After", ["Insert Page After", "Insérer une page après", "Insert Page After", "Insert Page After", "在后面插入页面"]),
    ("Insert Row", ["Insert Row", "Insérer une ligne", "Insert Row", "Insert Row", "插入行"]),
    ("Inset spacing", ["Inset spacing", "Espacement de retrait", "Inset spacing", "Inset spacing", "内边距"]),
    ("Inside", ["Inside", "Intérieur", "Inside", "Inside", "内侧"]),
    ("Intent:", ["Intent:", "Mode :", "Intent:", "Intent:", "意图："]),
    ("Keyboard Shortcuts", ["Keyboard Shortcuts", "Raccourcis clavier", "Keyboard Shortcuts", "Keyboard Shortcuts", "键盘快捷键"]),
    ("Kind:", ["Kind:", "Type :", "Kind:", "Kind:", "类型："]),
    ("Lab", ["Lab", "Lab", "Lab", "Lab", "Lab"]),
    ("Leading:", ["Leading:", "Interligne :", "Leading:", "Leading:", "行距："]),
    ("Left Indent:", ["Left Indent:", "Retrait à gauche :", "Left Indent:", "Left Indent:", "左缩进："]),
    ("Link To:", ["Link To:", "Lien vers :", "Link To:", "Link To:", "链接到："]),
    ("Load Profile…", ["Load Profile…", "Charger un profil…", "Load Profile…", "Load Profile…", "加载配置文件…"]),
    ("Load Swatches…", ["Load Swatches…", "Charger des nuances…", "Load Swatches…", "Load Swatches…", "加载色板…"]),
    (
        "Load Paragraph Styles…",
        ["Absatzformate laden…", "Charger les styles de paragraphe…", "Cargar estilos de párrafo…", "段落スタイルを読み込み…", "加载段落样式…"],
    ),
    (
        "Load Character Styles…",
        ["Zeichenformate laden…", "Charger les styles de caractère…", "Cargar estilos de carácter…", "文字スタイルを読み込み…", "加载字符样式…"],
    ),
    (
        "Load All Text Styles…",
        [
            "Alle Textformate laden…",
            "Charger tous les styles de texte…",
            "Cargar todos los estilos de texto…",
            "すべてのテキストスタイルを読み込み…",
            "加载所有文本样式…",
        ],
    ),
    ("Load Styles", ["Formate laden", "Charger les styles", "Cargar estilos", "スタイルを読み込み", "加载样式"]),
    (
        "Differs from this document",
        ["Weicht von diesem Dokument ab", "Diffère de ce document", "Difiere de este documento", "このドキュメントと異なります", "与此文档不同"],
    ),
    (
        "Redefine Document Style",
        [
            "Dokumentformat neu definieren",
            "Redéfinir le style du document",
            "Redefinir el estilo del documento",
            "ドキュメントのスタイルを再定義",
            "重新定义文档样式",
        ],
    ),
    (
        "Use Document Style Definition",
        [
            "Formatdefinition des Dokuments verwenden",
            "Utiliser la définition de style du document",
            "Usar la definición de estilo del documento",
            "ドキュメントのスタイル定義を使用",
            "使用文档样式定义",
        ],
    ),
    ("Auto Rename", ["Automatisch umbenennen", "Renommer automatiquement", "Cambiar nombre automáticamente", "自動的に名前を変更", "自动重命名"]),
    ("Load…", ["Load…", "Charger…", "Load…", "Load…", "加载…"]),
    ("Make Compound", ["Make Compound", "Créer un tracé transparent", "Make Compound", "Make Compound", "建立复合路径"]),
    ("Margins", ["Margins", "Marges", "Margins", "Margins", "边距"]),
    ("Marks and Bleeds", ["Marken und Beschnitt", "Repères et fonds perdus", "Marcas y sangrado", "トンボと塗り足し", "标记和出血"]),
    ("Maximum", ["Maximum", "Maximum", "Maximum", "Maximum", "最大"]),
    ("Menu Customization", ["Menu Customization", "Personnalisation des menus", "Menu Customization", "Menu Customization", "菜单自定"]),
    (
        "Merge into Active Layer",
        ["Merge into Active Layer", "Fusionner dans le calque actif", "Merge into Active Layer", "Merge into Active Layer", "合并到活动图层"],
    ),
    ("Min:", ["Min:", "Min. :", "Min:", "Min:", "最小："]),
    ("Minimum", ["Minimum", "Minimum", "Minimum", "Minimum", "最小"]),
    (
        "Minimum Space Before First Footnote:",
        [
            "Minimum Space Before First Footnote:",
            "Espace minimal avant la première note de bas de page :",
            "Minimum Space Before First Footnote:",
            "Minimum Space Before First Footnote:",
            "第一个脚注前最小间距：",
        ],
    ),
    (
        "Misspelled word → Correction (one per line):",
        [
            "Misspelled word → Correction (one per line):",
            "Mot mal orthographié → correction (un par ligne) :",
            "Misspelled word → Correction (one per line):",
            "Misspelled word → Correction (one per line):",
            "拼写错误的单词 → 更正（每行一个）：",
        ],
    ),
    ("Mobile", ["Mobile", "Mobile", "Mobile", "Mobile", "移动设备"]),
    ("Move Selection Here", ["Move Selection Here", "Déplacer la sélection ici", "Move Selection Here", "Move Selection Here", "将所选内容移至此处"]),
    (
        "Select; drag to move the selection to another layer",
        [
            "Auswählen; ziehen, um die Auswahl auf eine andere Ebene zu verschieben",
            "Sélectionner ; faire glisser pour déplacer la sélection vers un autre calque",
            "Seleccionar; arrastre para mover la selección a otra capa",
            "選択（ドラッグで選択範囲を別のレイヤーへ移動）",
            "选择；拖动可将所选内容移至其他图层",
        ],
    ),
    (
        "Move to Color Group",
        ["Move to Color Group", "Déplacer vers le groupe de couleurs", "Move to Color Group", "Move to Color Group", "移动到颜色组"],
    ),
    ("Move to Group", ["Move to Group", "Déplacer vers le groupe", "Move to Group", "Move to Group", "移动到组"]),
    ("Multiline", ["Multiline", "Multiligne", "Multiline", "Multiline", "多行"]),
    ("Name", ["Name", "Nom", "Name", "Name", "名称"]),
    ("Name:", ["Name:", "Nom :", "Name:", "Name:", "名称："]),
    (
        "New Bookmark for This Page",
        [
            "New Bookmark for This Page",
            "Nouveau signet pour cette page",
            "New Bookmark for This Page",
            "New Bookmark for This Page",
            "为此页面新建书签",
        ],
    ),
    ("New Book…", ["New Book…", "Nouveau livre…", "New Book…", "New Book…", "新建书籍…"]),
    ("New Color Group", ["New Color Group", "Nouveau groupe de couleurs", "New Color Group", "New Color Group", "新建颜色组"]),
    (
        "New Color Group with Swatch",
        [
            "New Color Group with Swatch",
            "Nouveau groupe de couleurs avec la nuance",
            "New Color Group with Swatch",
            "New Color Group with Swatch",
            "使用色板新建颜色组",
        ],
    ),
    ("New Cross-Reference", ["New Cross-Reference", "Nouvelle référence croisée", "New Cross-Reference", "New Cross-Reference", "新建交叉引用"]),
    ("New Document", ["New Document", "Nouveau document", "New Document", "New Document", "新建文档"]),
    ("New GREP Style", ["New GREP Style", "Nouveau style GREP", "New GREP Style", "New GREP Style", "新建 GREP 样式"]),
    ("New Library…", ["New Library…", "Nouvelle bibliothèque…", "New Library…", "New Library…", "新建库…"]),
    ("New Line Style", ["New Line Style", "Nouveau style de ligne", "New Line Style", "New Line Style", "新建线型"]),
    ("New Nested Style", ["New Nested Style", "Nouveau style imbriqué", "New Nested Style", "New Nested Style", "新建嵌套样式"]),
    ("New Workspace", ["New Workspace", "Nouvel espace de travail", "New Workspace", "New Workspace", "新建工作区"]),
    ("No spot inks", ["No spot inks", "Aucun ton direct", "No spot inks", "No spot inks", "无专色"]),
    ("None", ["None", "Aucun", "None", "None", "无"]),
    ("Number of Pages:", ["Number of Pages:", "Nombre de pages :", "Number of Pages:", "Number of Pages:", "页数："]),
    ("Number of Sides:", ["Number of Sides:", "Nombre de côtés :", "Number of Sides:", "Number of Sides:", "边数："]),
    ("Number of columns", ["Number of columns", "Nombre de colonnes", "Number of columns", "Number of columns", "栏数"]),
    ("Object Layer Options", ["Object Layer Options", "Options de calque d'objet", "Object Layer Options", "Object Layer Options", "对象图层选项"]),
    ("Offset:", ["Offset:", "Décalage :", "Offset:", "Offset:", "偏移："]),
    ("On Release", ["On Release", "Au relâchement", "On Release", "On Release", "释放时"]),
    ("On Screen:", ["On Screen:", "À l'écran :", "On Screen:", "On Screen:", "屏幕显示："]),
    ("OpenType", ["OpenType", "OpenType", "OpenType", "OpenType", "OpenType"]),
    ("Orientation:", ["Orientation:", "Orientation :", "Orientation:", "Orientation:", "方向："]),
    ("Outside", ["Outside", "Extérieur", "Outside", "Outside", "外侧"]),
    ("Page Information", ["Seiteninformationen", "Informations sur la page", "Información de página", "ページ情報", "页面信息"]),
    ("Page Range", ["Seitenbereich", "Plage de pages", "Intervalo de páginas", "ページ範囲", "页面范围"]),
    ("Page Range:", ["Seitenbereich:", "Plage de pages :", "Intervalo de páginas:", "ページ範囲:", "页面范围："]),
    ("Pages:", ["Pages:", "Pages :", "Pages:", "Pages:", "页面："]),
    ("Paragraph Composer", ["Paragraph Composer", "Compositeur de paragraphe", "Paragraph Composer", "Paragraph Composer", "段落排版器"]),
    (
        "Paragraph Style Options",
        ["Paragraph Style Options", "Options de style de paragraphe", "Paragraph Style Options", "Paragraph Style Options", "段落样式选项"],
    ),
    ("Paragraph Style:", ["Paragraph Style:", "Style de paragraphe :", "Paragraph Style:", "Paragraph Style:", "段落样式："]),
    ("PDF/A-2b", ["PDF/A-2b", "PDF/A-2b", "PDF/A-2b", "PDF/A-2b", "PDF/A-2b"]),
    ("PDF/X-4", ["PDF/X-4", "PDF/X-4", "PDF/X-4", "PDF/X-4", "PDF/X-4"]),
    ("Place PDF", ["Place PDF", "Importer un PDF", "Place PDF", "Place PDF", "置入PDF"]),
    ("Plain Text", ["Plain Text", "Texte brut", "Plain Text", "Plain Text", "纯文本"]),
    ("Polygon Settings", ["Polygon Settings", "Paramètres du polygone", "Polygon Settings", "Polygon Settings", "多边形设置"]),
    ("Position", ["Position", "Position", "Position", "Position", "位置"]),
    ("Position:", ["Position:", "Position :", "Position:", "Position:", "位置："]),
    ("Poster", ["Poster", "Affiche", "Poster", "Poster", "海报"]),
    ("Preferences", ["Preferences", "Préférences", "Preferences", "Preferences", "首选项"]),
    ("Prefix:", ["Prefix:", "Préfixe :", "Prefix:", "Prefix:", "前缀："]),
    ("Preset", ["Preset", "Paramètre prédéfini", "Preset", "Preset", "预设"]),
    ("Preset:", ["Voreinstellung:", "Paramètre prédéfini :", "Preajuste:", "プリセット:", "预设："]),
    ("Commercial Printing", ["Druckerei", "Impression commerciale", "Impresión comercial", "商業印刷", "商业印刷"]),
    ("Print", ["Print", "Imprimer", "Print", "Print", "打印"]),
    ("Printer:", ["Printer:", "Imprimante :", "Printer:", "Printer:", "打印机："]),
    (
        "Printing / Exporting:",
        ["Printing / Exporting:", "Impression / Exportation :", "Printing / Exporting:", "Printing / Exporting:", "打印/导出："],
    ),
    ("Quick Actions", ["Quick Actions", "Actions rapides", "Quick Actions", "Quick Actions", "快速操作"]),
    ("RGB", ["RGB", "RVB", "RGB", "RGB", "RGB"]),
    ("Rectangle", ["Rectangle", "Rectangle", "Rectangle", "Rectangle", "矩形"]),
    ("Reject All", ["Reject All", "Tout refuser", "Reject All", "Reject All", "全部拒绝"]),
    ("Relative To:", ["Relative To:", "Relatif à :", "Relative To:", "Relative To:", "相对于："]),
    ("Release", ["Release", "Libérer", "Release", "Release", "释放"]),
    ("Relink to Folder…", ["Relink to Folder…", "Rééditer le lien au dossier…", "Relink to Folder…", "Relink to Folder…", "重新链接到文件夹…"]),
    ("Relink…", ["Relink…", "Rééditer le lien…", "Relink…", "Relink…", "重新链接…"]),
    (
        "Remove Conditions from Selection",
        [
            "Remove Conditions from Selection",
            "Supprimer les conditions de la sélection",
            "Remove Conditions from Selection",
            "Remove Conditions from Selection",
            "从选择中移除条件",
        ],
    ),
    ("Repeat Header Rows", ["Repeat Header Rows", "Répéter les lignes d'en-tête", "Repeat Header Rows", "Repeat Header Rows", "重复表头行"]),
    ("Required", ["Required", "Obligatoire", "Required", "Required", "必填"]),
    (
        "Reset All to Defaults",
        ["Reset All to Defaults", "Rétablir toutes les valeurs par défaut", "Reset All to Defaults", "Reset All to Defaults", "全部恢复为默认值"],
    ),
    (
        "Restart Numbering Every:",
        [
            "Restart Numbering Every:",
            "Recommencer la numérotation à chaque :",
            "Restart Numbering Every:",
            "Restart Numbering Every:",
            "重新编号起点：",
        ],
    ),
    ("Reverse", ["Reverse", "Inverser", "Reverse", "Reverse", "反转"]),
    (
        "Save Swatches for Exchange…",
        [
            "Save Swatches for Exchange…",
            "Enregistrer les nuances pour échange…",
            "Save Swatches for Exchange…",
            "Save Swatches for Exchange…",
            "保存交换用色板…",
        ],
    ),
    (
        "Save recovery data every:",
        [
            "Save recovery data every:",
            "Enregistrer les données de récupération toutes les :",
            "Save recovery data every:",
            "Save recovery data every:",
            "保存恢复数据间隔：",
        ],
    ),
    ("Search:", ["Search:", "Rechercher :", "Search:", "Search:", "搜索："]),
    ("Select an object.", ["Select an object.", "Sélectionnez un objet.", "Select an object.", "Select an object.", "选择一个对象。"]),
    (
        "Select text or a text frame.",
        [
            "Select text or a text frame.",
            "Sélectionnez du texte ou un bloc de texte.",
            "Select text or a text frame.",
            "Select text or a text frame.",
            "选择文本或文本框架。",
        ],
    ),
    ("Separator:", ["Separator:", "Séparateur :", "Separator:", "Separator:", "分隔符："]),
    (
        "Show Prefix/Suffix in:",
        ["Show Prefix/Suffix in:", "Afficher le préfixe/suffixe dans :", "Show Prefix/Suffix in:", "Show Prefix/Suffix in:", "显示前缀/后缀位置："],
    ),
    ("Show Tag Markers", ["Show Tag Markers", "Afficher les marqueurs de balise", "Show Tag Markers", "Show Tag Markers", "显示标签标志符"]),
    ("Single-line", ["Single-line", "Ligne simple", "Single-line", "Single-line", "单行"]),
    ("Single-line Composer", ["Single-line Composer", "Compositeur ligne simple", "Single-line Composer", "Single-line Composer", "单行排版器"]),
    ("Size:", ["Size:", "Taille :", "Size:", "Size:", "大小："]),
    ("Screen and Email", ["Bildschirm und E-Mail", "Écran et e-mail", "Pantalla y correo", "画面とメール", "屏幕和电子邮件"]),
    (
        "Space Between Footnotes:",
        ["Space Between Footnotes:", "Espace entre les notes de bas de page :", "Space Between Footnotes:", "Space Between Footnotes:", "脚注间距："],
    ),
    ("Speed", ["Speed", "Vitesse", "Speed", "Speed", "速度"]),
    ("Standard", ["Standard", "Norme", "Estándar", "標準", "标准"]),
    ("Standard:", ["Standard:", "Norme :", "Estándar:", "標準:", "标准："]),
    ("Star Inset:", ["Star Inset:", "Renfoncement des branches :", "Star Inset:", "Star Inset:", "星形内边距："]),
    ("Start Page #:", ["Start Page #:", "N° de la première page :", "Start Page #:", "Start Page #:", "起始页码："]),
    ("Start at:", ["Start at:", "Commencer à :", "Start at:", "Start at:", "起始编号："]),
    ("Start:", ["Start:", "Début :", "Start:", "Start:", "开始："]),
    ("Style Name:", ["Style Name:", "Nom du style :", "Style Name:", "Style Name:", "样式名称："]),
    ("Style:", ["Style:", "Style :", "Style:", "Style:", "样式："]),
    ("Stylistic Sets", ["Stylistic Sets", "Jeux stylistiques", "Stylistic Sets", "Stylistic Sets", "样式集"]),
    ("Subdivisions:", ["Subdivisions:", "Subdivisions :", "Subdivisions:", "Subdivisions:", "细分："]),
    ("Suffix:", ["Suffix:", "Suffixe :", "Suffix:", "Suffix:", "后缀："]),
    ("Synchronize", ["Synchronize", "Synchroniser", "Synchronize", "Synchronize", "同步"]),
    ("Tag:", ["Tag:", "Balise :", "Tag:", "Tag:", "标签："]),
    ("Tagged PDF", ["Markiertes PDF", "PDF balisé", "PDF etiquetado", "タグ付き PDF", "带标签的 PDF"]),
    ("Text Frame", ["Text Frame", "Bloc de texte", "Text Frame", "Text Frame", "文本框架"]),
    ("Text Frame Options", ["Text Frame Options", "Options de bloc de texte", "Text Frame Options", "Text Frame Options", "文本框架选项"]),
    ("Text Message", ["Text Message", "SMS", "Text Message", "Text Message", "短信"]),
    ("Text Style", ["Text Style", "Style de texte", "Text Style", "Text Style", "文字样式"]),
    ("Text Wrap", ["Text Wrap", "Habillage", "Text Wrap", "Text Wrap", "文本绕排"]),
    (
        "This PDF has no layers.",
        ["This PDF has no layers.", "Ce PDF ne contient aucun calque.", "This PDF has no layers.", "This PDF has no layers.", "此 PDF 没有图层。"],
    ),
    ("To Text:", ["To Text:", "Au texte :", "To Text:", "To Text:", "文本转为："]),
    ("Top", ["Top", "Haut", "Top", "Top", "顶部"]),
    (
        "Track Changes in All Stories",
        [
            "Track Changes in All Stories",
            "Suivre les modifications dans tous les articles",
            "Track Changes in All Stories",
            "Track Changes in All Stories",
            "跟踪所有文章中的更改",
        ],
    ),
    ("Trim", ["Trim", "Rognage", "Trim", "Trim", "裁切"]),
    (
        "Bounding Box (Visible Layers Only)",
        [
            "Begrenzungsrahmen (nur sichtbare Ebenen)",
            "Cadre de sélection (calques visibles uniquement)",
            "Cuadro delimitador (solo capas visibles)",
            "バウンディングボックス（表示レイヤーのみ）",
            "边界框（仅可见图层）",
        ],
    ),
    (
        "Bounding Box (All Layers)",
        [
            "Begrenzungsrahmen (alle Ebenen)",
            "Cadre de sélection (tous les calques)",
            "Cuadro delimitador (todas las capas)",
            "バウンディングボックス（すべてのレイヤー）",
            "边界框（所有图层）",
        ],
    ),
    ("Type:", ["Type:", "Type :", "Type:", "Type:", "类型："]),
    ("Typical", ["Typical", "Standard", "Typical", "Typical", "典型"]),
    ("UI Size:", ["UI Size:", "Taille de l'interface :", "UI Size:", "UI Size:", "UI 大小："]),
    ("Ungroup Color Group", ["Ungroup Color Group", "Dissocier le groupe de couleurs", "Ungroup Color Group", "Ungroup Color Group", "取消颜色组"]),
    ("Unmerge", ["Unmerge", "Annuler la fusion", "Unmerge", "Unmerge", "取消合并"]),
    ("Update", ["Update", "Mettre à jour", "Update", "Update", "更新"]),
    ("Update Numbering", ["Update Numbering", "Mettre à jour la numérotation", "Update Numbering", "Update Numbering", "更新编号"]),
    ("Use Global Light", ["Use Global Light", "Utiliser la lumière globale", "Use Global Light", "Use Global Light", "使用全局光"]),
    ("User Dictionary", ["User Dictionary", "Dictionnaire utilisateur", "User Dictionary", "User Dictionary", "用户词典"]),
    (
        "Vertical Gridline Every:",
        [
            "Vertical Gridline Every:",
            "Ligne de grille verticale tous les :",
            "Vertical Gridline Every:",
            "Vertical Gridline Every:",
            "垂直网格线间隔：",
        ],
    ),
    ("Vertical Margins:", ["Vertical Margins:", "Marges verticales :", "Vertical Margins:", "Vertical Margins:", "垂直边距："]),
    ("Vertical justification", ["Vertical justification", "Justification verticale", "Vertical justification", "Vertical justification", "垂直对齐"]),
    ("View Threshold:", ["View Threshold:", "Seuil d'affichage :", "View Threshold:", "View Threshold:", "视图阈值："]),
    ("Web", ["Web", "Web", "Web", "Web", "Web"]),
    ("Web Hyperlink", ["Web Hyperlink", "Hyperlien Web", "Web Hyperlink", "Web Hyperlink", "Web 超链接"]),
    ("Weight:", ["Weight:", "Épaisseur :", "Weight:", "Weight:", "粗细："]),
    ("Width", ["Width", "Largeur", "Width", "Width", "宽度"]),
    ("Width:", ["Width:", "Largeur :", "Width:", "Width:", "宽度："]),
    ("Words, one per line:", ["Words, one per line:", "Mots, un par ligne :", "Words, one per line:", "Words, one per line:", "单词，每行一个："]),
    ("Multiple Objects", ["Multiple Objects", "Plusieurs objets", "Multiple Objects", "Multiple Objects", "多个对象"]),
    ("Ellipse", ["Ellipse", "Ellipse", "Ellipse", "Ellipse", "椭圆"]),
    ("Polygon", ["Polygon", "Polygone", "Polygon", "Polygon", "多边形"]),
    ("Characters", ["Characters", "Caractères", "Characters", "Characters", "字符"]),
    ("Image", ["Image", "Image", "Image", "Image", "图像"]),
    ("Line", ["Line", "Trait", "Line", "Line", "直线"]),
    ("Path", ["Path", "Tracé", "Path", "Path", "路径"]),
    ("No Selection", ["No Selection", "Aucune sélection", "No Selection", "No Selection", "未选择"]),
    ("Adjust Layout", ["Adjust Layout", "Ajuster la mise en page", "Adjust Layout", "Adjust Layout", "调整版面"]),
    ("Edit Page", ["Edit Page", "Modifier la page", "Edit Page", "Edit Page", "编辑页面"]),
    ("Import File", ["Import File", "Importer un fichier", "Import File", "Import File", "导入文件"]),
    ("Insert Page", ["Insert Page", "Insérer une page", "Insert Page", "Insert Page", "插入页面"]),
    (
        "Delete selected pages",
        ["Ausgewählte Seiten löschen", "Supprimer les pages sélectionnées", "Eliminar páginas seleccionadas", "選択したページを削除", "删除选定页面"],
    ),
    ("Create new page", ["Neue Seite erstellen", "Créer une page", "Crear página nueva", "新規ページを作成", "新建页面"]),
    ("Edit page size", ["Seitenformat bearbeiten", "Modifier le format de page", "Editar tamaño de página", "ページサイズを編集", "编辑页面大小"]),
    (
        "Custom Page Size…",
        [
            "Benutzerdefiniertes Seitenformat …",
            "Format de page personnalisé…",
            "Tamaño de página personalizado…",
            "カスタムページサイズ…",
            "自定页面大小…",
        ],
    ),
    ("Hide Bar", ["Hide Bar", "Masquer la barre", "Hide Bar", "Hide Bar", "隐藏栏"]),
    ("Properties Panel", ["Properties Panel", "Panneau Propriétés", "Properties Panel", "Properties Panel", "属性面板"]),
    ("New Workspace…", ["New Workspace…", "Nouvel espace de travail…", "New Workspace…", "New Workspace…", "新建工作区…"]),
    ("Float panel", ["Float panel", "Détacher le panneau", "Float panel", "Float panel", "浮动面板"]),
    ("Dock panel", ["Dock panel", "Ancrer le panneau", "Dock panel", "Dock panel", "停靠面板"]),
    (
        "Fit frame height to text",
        [
            "Fit frame height to text",
            "Ajuster la hauteur du bloc au texte",
            "Fit frame height to text",
            "Fit frame height to text",
            "适合框架高度到文本",
        ],
    ),
    ("More Options", ["More Options", "Plus d'options", "More Options", "More Options", "更多选项"]),
    ("Flip Horizontal", ["Flip Horizontal", "Retourner horizontalement", "Flip Horizontal", "Flip Horizontal", "水平翻转"]),
    (
        "Rotate 90° Clockwise",
        ["Rotate 90° Clockwise", "Rotation de 90° dans le sens horaire", "Rotate 90° Clockwise", "Rotate 90° Clockwise", "顺时针旋转90°"],
    ),
    ("Flip Vertical", ["Flip Vertical", "Retourner verticalement", "Flip Vertical", "Flip Vertical", "垂直翻转"]),
    (
        "Default Fill and Stroke (D)",
        [
            "Default Fill and Stroke (D)",
            "Fond et contour par défaut (D)",
            "Default Fill and Stroke (D)",
            "Default Fill and Stroke (D)",
            "默认填色和描边 (D)",
        ],
    ),
    (
        "Swap Fill and Stroke (Shift+X)",
        [
            "Swap Fill and Stroke (Shift+X)",
            "Permuter fond et contour (Shift+X)",
            "Swap Fill and Stroke (Shift+X)",
            "Swap Fill and Stroke (Shift+X)",
            "交换填色和描边 (Shift+X)",
        ],
    ),
    ("Fill (X)", ["Fill (X)", "Fond (X)", "Fill (X)", "Fill (X)", "填色 (X)"]),
    ("Stroke (X)", ["Stroke (X)", "Contour (X)", "Stroke (X)", "Stroke (X)", "描边 (X)"]),
    ("Apply None (/)", ["Apply None (/)", "Appliquer Aucun (/)", "Apply None (/)", "Apply None (/)", "应用无 (/)"]),
    (
        "Default Fill and Stroke",
        ["Default Fill and Stroke", "Default Fill and Stroke", "Default Fill and Stroke", "Default Fill and Stroke", "默认填色和描边"],
    ),
    ("Swap Fill and Stroke", ["Swap Fill and Stroke", "Swap Fill and Stroke", "Swap Fill and Stroke", "Swap Fill and Stroke", "交换填色和描边"]),
    (
        "Toggle Fill and Stroke",
        ["Toggle Fill and Stroke", "Toggle Fill and Stroke", "Toggle Fill and Stroke", "Toggle Fill and Stroke", "切换填色和描边"],
    ),
    ("Reverse the gradient", ["Reverse the gradient", "Inverser le dégradé", "Reverse the gradient", "Reverse the gradient", "反转渐变"]),
    ("Style source", ["Style source", "Source du style", "Style source", "Style source", "样式源"]),
    ("Open", ["Open", "Ouvrir", "Open", "Open", "打开"]),
    ("All Caps", ["All Caps", "Tout en capitales", "All Caps", "All Caps", "全部大写"]),
    ("Underline", ["Underline", "Souligné", "Underline", "Underline", "下划线"]),
    ("Strikethrough", ["Strikethrough", "Barré", "Strikethrough", "Strikethrough", "删除线"]),
    ("Superscript", ["Superscript", "Exposant", "Superscript", "Superscript", "上标"]),
    (
        "Pick a file in the folder holding the moved graphics",
        [
            "Pick a file in the folder holding the moved graphics",
            "Choisissez un fichier dans le dossier qui contient les graphiques déplacés",
            "Pick a file in the folder holding the moved graphics",
            "Pick a file in the folder holding the moved graphics",
            "在包含移动图形的文件夹中选择一个文件",
        ],
    ),
    ("Show Favorites Only", ["Show Favorites Only", "Afficher uniquement les favoris", "Show Favorites Only", "Show Favorites Only", "仅显示收藏夹"]),
    ("Select", ["Select", "Sélectionner", "Select", "Select", "选择"]),
    (
        "Hyperlink from the selected text or frames",
        [
            "Hyperlink from the selected text or frames",
            "Hyperlien à partir du texte ou des blocs sélectionnés",
            "Hyperlink from the selected text or frames",
            "Hyperlink from the selected text or frames",
            "从所选文本或框架建立超链接",
        ],
    ),
    (
        "Include when exporting",
        ["Include when exporting", "Inclure à l'exportation", "Include when exporting", "Include when exporting", "导出时包含"],
    ),
    ("Add the selection", ["Add the selection", "Ajouter la sélection", "Add the selection", "Add the selection", "添加选择"]),
    ("Tag the selection", ["Tag the selection", "Baliser la sélection", "Tag the selection", "Tag the selection", "标记选择"]),
    ("Separated by commas", ["Separated by commas", "Séparés par des virgules", "Separated by commas", "Separated by commas", "用逗号分隔"]),
    ("Show in the text", ["Show in the text", "Afficher dans le texte", "Show in the text", "Show in the text", "在文本中显示"]),
    (
        "Show / hide text with this condition",
        [
            "Show / hide text with this condition",
            "Afficher / masquer le texte avec cette condition",
            "Show / hide text with this condition",
            "Show / hide text with this condition",
            "使用此条件显示/隐藏文本",
        ],
    ),
    (
        "Spreads of up to 10 pages",
        ["Spreads of up to 10 pages", "Planches de 10 pages maximum", "Spreads of up to 10 pages", "Spreads of up to 10 pages", "最多10页的跨页"],
    ),
    ("for", ["for", "pour", "por", "に対して", "行"]),
    ("About DesignCraft", ["About DesignCraft", "À propos de DesignCraft", "About DesignCraft", "About DesignCraft", "关于 DesignCraft"]),
    ("Quit DesignCraft", ["DesignCraft beenden", "Quitter DesignCraft", "Salir de DesignCraft", "DesignCraft を終了", "退出 DesignCraft"]),
    ("Accept All Changes", ["Accept All Changes", "Accepter toutes les modifications", "Accept All Changes", "Accept All Changes", "接受所有更改"]),
    ("Activate Document", ["Activate Document", "Activer le document", "Activate Document", "Activate Document", "激活文档"]),
    ("Add Anchor Point", ["Add Anchor Point", "Ajouter un point d'ancrage", "Add Anchor Point", "Add Anchor Point", "添加锚点"]),
    ("Add Document", ["Add Document", "Ajouter un document", "Add Document", "Add Document", "添加文档"]),
    (
        "Add Hyphenation Exception",
        ["Add Hyphenation Exception", "Ajouter une exception de césure", "Add Hyphenation Exception", "Add Hyphenation Exception", "添加断字例外"],
    ),
    ("Add Item", ["Add Item", "Ajouter un élément", "Add Item", "Add Item", "添加项目"]),
    ("Add Page to Spread", ["Add Page to Spread", "Ajouter une page à la planche", "Add Page to Spread", "Add Page to Spread", "添加页面至跨页"]),
    ("Add to Swatches", ["Add to Swatches", "Ajouter au nuancier", "Add to Swatches", "Add to Swatches", "添加到色板"]),
    (
        "Allow Selected Spread to Shuffle",
        [
            "Allow Selected Spread to Shuffle",
            "Autoriser la réorganisation des pages de la planche sélectionnée",
            "Allow Selected Spread to Shuffle",
            "Allow Selected Spread to Shuffle",
            "允许所选跨页随机排布",
        ],
    ),
    (
        "Anchored Object Options…",
        ["Anchored Object Options…", "Options d'objet ancré…", "Anchored Object Options…", "Anchored Object Options…", "锚定对象选项…"],
    ),
    ("Anchored Objects", ["Anchored Objects", "Objets ancrés", "Anchored Objects", "Anchored Objects", "锚定对象"]),
    ("Appearance of Black", ["Appearance of Black", "Aspect du noir", "Appearance of Black", "Appearance of Black", "黑色的外观"]),
    (
        "Apply Attributes (Eyedropper)",
        [
            "Apply Attributes (Eyedropper)",
            "Appliquer les attributs (Pipette)",
            "Apply Attributes (Eyedropper)",
            "Apply Attributes (Eyedropper)",
            "应用属性 (吸管)",
        ],
    ),
    ("Apply Cell Style", ["Apply Cell Style", "Appliquer le style de cellule", "Apply Cell Style", "Apply Cell Style", "应用单元格样式"]),
    ("Apply Color", ["Apply Color", "Appliquer la couleur", "Apply Color", "Apply Color", "应用颜色"]),
    ("Repeat", ["Wiederholen", "Répéter", "Repetir", "繰り返し", "重复"]),
    ("Count:", ["Anzahl:", "Nombre :", "Recuento:", "繰り返し数:", "计数:"]),
    ("Create as a grid", ["Als Raster erstellen", "Créer en tant que grille", "Crear como cuadrícula", "グリッドとして作成", "创建为网格"]),
    ("Rows:", ["Zeilen:", "Rangées :", "Filas:", "行:", "行:"]),
    ("Vertical:", ["Vertikal:", "Vertical :", "Vertical:", "垂直方向:", "垂直:"]),
    ("Horizontal:", ["Horizontal:", "Horizontal :", "Horizontal:", "水平方向:", "水平:"]),
    ("Invalid value", ["Ungültiger Wert", "Valeur non valide", "Valor no válido", "無効な値", "无效值"]),
    ("Isolate Blending", ["Füllmethode isolieren", "Isoler le mode de fusion", "Aislar fusión", "描画モードを分離", "分离混合"]),
    ("Knockout Group", ["Aussparungsgruppe", "Groupe de masquage", "Grupo de exclusión", "グループの抜き", "挖空组"]),
    ("Object:", ["Objekt:", "Objet :", "Objeto:", "オブジェクト:", "对象:"]),
    ("Group:", ["Gruppe:", "Groupe :", "Grupo:", "グループ:", "编组:"]),
    (
        "Sample Color (Eyedropper)",
        ["Farbe aufnehmen (Pipette)", "Prélever la couleur (Pipette)", "Tomar color (Cuentagotas)", "カラーを抽出 (スポイト)", "取样颜色 (吸管)"],
    ),
    ("Apply Condition", ["Apply Condition", "Appliquer la condition", "Apply Condition", "Apply Condition", "应用条件"]),
    (
        "Apply Parent to Pages…",
        ["Apply Parent to Pages…", "Appliquer le gabarit aux pages…", "Apply Parent to Pages…", "Apply Parent to Pages…", "将主页应用于页面…"],
    ),
    (
        "ArtCraft App Page…",
        ["ArtCraft App Page…", "Page de l'application ArtCraft…", "ArtCraft App Page…", "ArtCraft App Page…", "ArtCraft 应用页面…"],
    ),
    ("ArtCraft Website…", ["ArtCraft Website…", "Site web d'ArtCraft…", "ArtCraft Website…", "ArtCraft Website…", "ArtCraft 网站…"]),
    ("Attributes", ["Attributes", "Attributs", "Attributes", "Attributes", "属性"]),
    ("Bevel and Emboss", ["Bevel and Emboss", "Biseautage et estampage", "Bevel and Emboss", "Bevel and Emboss", "斜面和浮雕"]),
    ("Buttons", ["Buttons", "Boutons", "Buttons", "Buttons", "按钮"]),
    ("Cell Options", ["Cell Options", "Options de cellule", "Cell Options", "Cell Options", "单元格选项"]),
    ("Cell Style Options…", ["Cell Style Options…", "Options de style de cellule…", "Cell Style Options…", "Cell Style Options…", "单元格样式选项…"]),
    ("Change All (Object)", ["Change All (Object)", "Tout remplacer (objet)", "Change All (Object)", "Change All (Object)", "全部更改 (对象)"]),
    ("Change Case", ["Change Case", "Modifier la casse", "Change Case", "Change Case", "更改大小写"]),
    ("Changes", ["Changes", "Modifications", "Changes", "Changes", "更改"]),
    ("Character Formatting", ["Character Formatting", "Mise en forme des caractères", "Character Formatting", "Character Formatting", "字符格式"]),
    ("Clear Conveyor", ["Clear Conveyor", "Vider le convoyeur", "Clear Conveyor", "Clear Conveyor", "清除传送带"]),
    ("Clear Transformations", ["Clear Transformations", "Effacer les transformations", "Clear Transformations", "Clear Transformations", "清除变换"]),
    ("Clipping Path…", ["Clipping Path…", "Masque…", "Clipping Path…", "Clipping Path…", "剪切路径…"]),
    ("Close Book", ["Close Book", "Fermer le livre", "Close Book", "Close Book", "关闭书籍"]),
    ("Close Library", ["Close Library", "Fermer la bibliothèque", "Close Library", "Close Library", "关闭库"]),
    ("Collect", ["Collect", "Collecter", "Collect", "Collect", "收集"]),
    ("Color Settings…", ["Color Settings…", "Réglages des couleurs…", "Color Settings…", "Color Settings…", "颜色设置…"]),
    (
        "Community & Project Links",
        ["Community & Project Links", "Communauté et liens du projet", "Community & Project Links", "Community & Project Links", "社区与项目链接"],
    ),
    ("Compress images", ["Bilder komprimieren", "Compresser les images", "Comprimir imágenes", "画像を圧縮", "压缩图像"]),
    ("Compression", ["Komprimierung", "Compression", "Compresión", "圧縮", "压缩"]),
    ("Conditions", ["Conditions", "Conditions", "Conditions", "Conditions", "条件"]),
    ("Container", ["Container", "Conteneur", "Container", "Container", "容器"]),
    ("Content", ["Content", "Contenu", "Content", "Content", "内容"]),
    ("Contextual Task Bar", ["Contextual Task Bar", "Barre des tâches contextuelle", "Contextual Task Bar", "Contextual Task Bar", "上下文任务栏"]),
    ("Control", ["Control", "Contrôle", "Control", "Control", "控制"]),
    (
        "Convert Cell to Graphic Cell",
        [
            "Convert Cell to Graphic Cell",
            "Convertir la cellule en cellule graphique",
            "Convert Cell to Graphic Cell",
            "Convert Cell to Graphic Cell",
            "将单元格转换为图形单元格",
        ],
    ),
    (
        "Convert Cell to Graphic Cell…",
        [
            "Convert Cell to Graphic Cell…",
            "Convertir la cellule en cellule graphique…",
            "Convert Cell to Graphic Cell…",
            "Convert Cell to Graphic Cell…",
            "将单元格转换为图形单元格…",
        ],
    ),
    (
        "Convert Cell to Text Cell",
        [
            "Convert Cell to Text Cell",
            "Convertir la cellule en cellule de texte",
            "Convert Cell to Text Cell",
            "Convert Cell to Text Cell",
            "将单元格转换为文本单元格",
        ],
    ),
    ("Convert Color", ["Convert Color", "Convertir la couleur", "Convert Color", "Convert Color", "转换颜色"]),
    (
        "Convert Direction Point",
        ["Convert Direction Point", "Convertir le point directeur", "Convert Direction Point", "Convert Direction Point", "转换方向点"],
    ),
    (
        "Convert Note to Text",
        ["Convert Note to Text", "Convertir la note en texte", "Convert Note to Text", "Convert Note to Text", "将注释转换为文本"],
    ),
    (
        "Convert Selection to Multi-State Object",
        [
            "Convert Selection to Multi-State Object",
            "Convertir la sélection en objet à états multiples",
            "Convert Selection to Multi-State Object",
            "Convert Selection to Multi-State Object",
            "将选区转换为多状态对象",
        ],
    ),
    ("Convert Shape", ["Convert Shape", "Convertir la forme", "Convert Shape", "Convert Shape", "转换形状"]),
    (
        "Convert Table to Text",
        ["Convert Table to Text", "Convertir le tableau en texte", "Convert Table to Text", "Convert Table to Text", "将表格转换为文本"],
    ),
    (
        "Convert Text to Table",
        ["Convert Text to Table", "Convertir le texte en tableau", "Convert Text to Table", "Convert Text to Table", "将文本转换为表格"],
    ),
    ("Convert to Button", ["Convert to Button", "Convertir en bouton", "Convert to Button", "Convert to Button", "转换为按钮"]),
    (
        "Convert to Form Field",
        ["Convert to Form Field", "Convertir en champ de formulaire", "Convert to Form Field", "Convert to Form Field", "转换为表单域"],
    ),
    ("Conveyor", ["Conveyor", "Convoyeur", "Conveyor", "Conveyor", "传送带"]),
    ("Copy Link(s) To…", ["Copy Link(s) To…", "Copier les liens vers…", "Copy Link(s) To…", "Copy Link(s) To…", "复制链接至…"]),
    ("Corner Options…", ["Corner Options…", "Options d'arrondi…", "Corner Options…", "Corner Options…", "角选项…"]),
    (
        "Create Alternate Layout…",
        ["Create Alternate Layout…", "Créer une variante de mise en page…", "Create Alternate Layout…", "Create Alternate Layout…", "创建替代版面…"],
    ),
    ("Create Frame", ["Create Frame", "Créer un bloc", "Create Frame", "Create Frame", "创建框架"]),
    (
        "Create Merged Document…",
        [
            "Zusammengeführtes Dokument erstellen …",
            "Créer un document fusionné…",
            "Crear documento combinado…",
            "結合ドキュメントを作成…",
            "创建合并文档…",
        ],
    ),
    (
        "Cross-Reference Formats",
        ["Cross-Reference Formats", "Formats de référence croisée", "Cross-Reference Formats", "Cross-Reference Formats", "交叉引用格式"],
    ),
    ("Cross-References", ["Cross-References", "Références croisées", "Cross-References", "Cross-References", "交叉引用"]),
    ("Data Merge Fields", ["Data Merge Fields", "Champs de fusion des données", "Data Merge Fields", "Data Merge Fields", "数据合并字段"]),
    (
        "Define Cross-Reference Format…",
        [
            "Define Cross-Reference Format…",
            "Définir un format de référence croisée…",
            "Define Cross-Reference Format…",
            "Define Cross-Reference Format…",
            "定义交叉引用格式…",
        ],
    ),
    ("Define Lists…", ["Define Lists…", "Définir des listes…", "Define Lists…", "Define Lists…", "定义列表…"]),
    (
        "Define Text Variable…",
        ["Define Text Variable…", "Définir une variable de texte…", "Define Text Variable…", "Define Text Variable…", "定义文本变量…"],
    ),
    (
        "Delete All Guides on Spread",
        [
            "Delete All Guides on Spread",
            "Supprimer tous les repères de la planche",
            "Delete All Guides on Spread",
            "Delete All Guides on Spread",
            "删除跨页上的所有参考线",
        ],
    ),
    ("Delete Anchor Point", ["Delete Anchor Point", "Supprimer le point d'ancrage", "Delete Anchor Point", "Delete Anchor Point", "删除锚点"]),
    ("Delete Item", ["Delete Item", "Supprimer l'élément", "Delete Item", "Delete Item", "删除项目"]),
    (
        "Delete Text Variable",
        ["Delete Text Variable", "Supprimer la variable de texte", "Delete Text Variable", "Delete Text Variable", "删除文本变量"],
    ),
    ("Delete Workspace…", ["Delete Workspace…", "Supprimer l'espace de travail…", "Delete Workspace…", "Delete Workspace…", "删除工作区…"]),
    (
        "DesignCraft Website…",
        ["DesignCraft Website…", "Site web de DesignCraft…", "DesignCraft Website…", "DesignCraft Website…", "DesignCraft 网站…"],
    ),
    (
        "DesignCraft on GitHub…",
        ["DesignCraft on GitHub…", "DesignCraft sur GitHub…", "DesignCraft on GitHub…", "DesignCraft on GitHub…", "DesignCraft 在 GitHub 上…"],
    ),
    (
        "Detach All Objects from Parent",
        [
            "Detach All Objects from Parent",
            "Détacher tous les objets du gabarit",
            "Detach All Objects from Parent",
            "Detach All Objects from Parent",
            "从主页分离所有对象",
        ],
    ),
    ("Directional Feather", ["Directional Feather", "Contour progressif directionnel", "Directional Feather", "Directional Feather", "定向羽化"]),
    ("Distribute", ["Distribute", "Répartir", "Distribute", "Distribute", "分布"]),
    ("Dock Panel", ["Dock Panel", "Ancrer le panneau", "Dock Panel", "Dock Panel", "停靠面板"]),
    (
        "Document Endnote Options…",
        [
            "Document Endnote Options…",
            "Options de notes de fin de document…",
            "Document Endnote Options…",
            "Document Endnote Options…",
            "文档尾注选项…",
        ],
    ),
    (
        "Document Footnote Options…",
        [
            "Document Footnote Options…",
            "Options de notes de bas de page du document…",
            "Document Footnote Options…",
            "Document Footnote Options…",
            "文档脚注选项…",
        ],
    ),
    ("Document Preferences", ["Document Preferences", "Préférences du document", "Document Preferences", "Document Preferences", "文档首选项"]),
    ("Document Presets", ["Document Presets", "Paramètres prédéfinis de document", "Document Presets", "Document Presets", "文档预设"]),
    ("Document…", ["Document…", "Document…", "Document…", "Document…", "文档…"]),
    ("Dynamic Spelling", ["Dynamic Spelling", "Orthographe dynamique", "Dynamic Spelling", "Dynamic Spelling", "动态拼写"]),
    ("Edit Parents", ["Edit Parents", "Modifier les gabarits", "Edit Parents", "Edit Parents", "编辑主页"]),
    ("Edit Story", ["Edit Story", "Modifier l'article", "Edit Story", "Edit Story", "编辑文章"]),
    (
        "Edit in Story Editor",
        ["Edit in Story Editor", "Modifier en mode éditeur", "Edit in Story Editor", "Edit in Story Editor", "在文章编辑器中编辑"],
    ),
    ("Endnotes", ["Endnotes", "Notes de fin", "Endnotes", "Endnotes", "尾注"]),
    ("Entire Pasteboard", ["Entire Pasteboard", "Table de montage entière", "Entire Pasteboard", "Entire Pasteboard", "完整粘贴板"]),
    ("Erase", ["Erase", "Effacer", "Erase", "Erase", "擦除"]),
    ("Export Book to PDF…", ["Export Book to PDF…", "Exporter le livre en PDF…", "Export Book to PDF…", "Export Book to PDF…", "将书籍导出为 PDF…"]),
    (
        "Export EPUB (Fixed Layout)…",
        [
            "Export EPUB (Fixed Layout)…",
            "Exporter en EPUB (mise en page fixe)…",
            "Export EPUB (Fixed Layout)…",
            "Export EPUB (Fixed Layout)…",
            "导出 EPUB (固定版面)…",
        ],
    ),
    (
        "Export EPUB (Reflowable)…",
        [
            "Export EPUB (Reflowable)…",
            "Exporter en EPUB (redistribuable)…",
            "Export EPUB (Reflowable)…",
            "Export EPUB (Reflowable)…",
            "导出 EPUB (可回流)…",
        ],
    ),
    ("Export EPUB…", ["Export EPUB…", "Exporter en EPUB…", "Export EPUB…", "Export EPUB…", "导出 EPUB…"]),
    ("Export HTML…", ["Export HTML…", "Exporter en HTML…", "Export HTML…", "Export HTML…", "导出 HTML…"]),
    ("Export IDML…", ["Export IDML…", "Exporter en IDML…", "Export IDML…", "Export IDML…", "导出 IDML…"]),
    (
        "Export PDF (Interactive)…",
        [
            "Export PDF (Interactive)…",
            "Exporter en PDF (interactif)…",
            "Export PDF (Interactive)…",
            "Export PDF (Interactive)…",
            "导出 PDF (交互式)…",
        ],
    ),
    ("Export Page as PNG…", ["Export Page as PNG…", "Exporter la page en PNG…", "Export Page as PNG…", "Export Page as PNG…", "将页面导出为 PNG…"]),
    (
        "Export Selection as Snippet",
        [
            "Export Selection as Snippet",
            "Exporter la sélection en tant qu'extrait",
            "Export Selection as Snippet",
            "Export Selection as Snippet",
            "将所选内容导出为片段",
        ],
    ),
    ("Export Tagging", ["Export Tagging", "Balisage d'exportation", "Export Tagging", "Export Tagging", "导出标记"]),
    ("Export Text…", ["Export Text…", "Exporter le texte…", "Export Text…", "Export Text…", "导出文本…"]),
    (
        "Extend Text Selection",
        ["Extend Text Selection", "Étendre la sélection de texte", "Extend Text Selection", "Extend Text Selection", "扩展文本选区"],
    ),
    ("Fast Display", ["Fast Display", "Affichage rapide", "Fast Display", "Fast Display", "快速显示"]),
    ("Find", ["Find", "Rechercher", "Find", "Find", "查找"]),
    ("Find Object", ["Find Object", "Rechercher un objet", "Find Object", "Find Object", "查找对象"]),
    (
        "Find by Script Label",
        ["Find by Script Label", "Rechercher par étiquette de script", "Find by Script Label", "Find by Script Label", "按脚本标签查找"],
    ),
    ("Find/Replace Font…", ["Find/Replace Font…", "Rechercher/Remplacer une police…", "Find/Replace Font…", "Find/Replace Font…", "查找/替换字体…"]),
    ("First Object Above", ["First Object Above", "Premier objet au-dessus", "First Object Above", "First Object Above", "上方第一个对象"]),
    (
        "Fit Selection in Window",
        [
            "Fit Selection in Window",
            "Ajuster la sélection à la fenêtre",
            "Fit Selection in Window",
            "Fit Selection in Window",
            "窗口大小适应所选内容",
        ],
    ),
    ("Flattener Preview", ["Flattener Preview", "Aperçu de l'aplatissement", "Flattener Preview", "Flattener Preview", "拼合器预览"]),
    ("Float Panel", ["Float Panel", "Détacher le panneau", "Float Panel", "Float Panel", "浮动面板"]),
    ("Fonts in Document", ["Fonts in Document", "Polices du document", "Fonts in Document", "Fonts in Document", "文档中的字体"]),
    ("Footnotes", ["Footnotes", "Notes de bas de page", "Footnotes", "Footnotes", "脚注"]),
    ("Form Fields", ["Form Fields", "Champs de formulaire", "Form Fields", "Form Fields", "表单域"]),
    (
        "Frame Fitting Options…",
        ["Frame Fitting Options…", "Options d'ajustement au bloc…", "Frame Fitting Options…", "Frame Fitting Options…", "框架适合选项…"],
    ),
    ("Generate Index…", ["Generate Index…", "Générer l'index…", "Generate Index…", "Generate Index…", "生成索引…"]),
    ("Generate QR Code…", ["Generate QR Code…", "Générer un code QR…", "Generate QR Code…", "Generate QR Code…", "生成二维码…"]),
    (
        "Generate Static Caption",
        ["Generate Static Caption", "Générer une légende statique", "Generate Static Caption", "Generate Static Caption", "生成静态题注"],
    ),
    ("Get Story", ["Get Story", "Obtenir l'article", "Get Story", "Get Story", "获取文章"]),
    ("Get Table", ["Get Table", "Obtenir le tableau", "Get Table", "Get Table", "获取表格"]),
    ("Global Light…", ["Global Light…", "Lumière globale…", "Global Light…", "Global Light…", "全局光…"]),
    ("Go To Link", ["Go To Link", "Atteindre le lien", "Go To Link", "Go To Link", "转到链接"]),
    ("Go To Source", ["Go To Source", "Atteindre la source", "Go To Source", "Go To Source", "转到源"]),
    (
        "Go to Footnote Reference",
        [
            "Go to Footnote Reference",
            "Atteindre la référence de note de bas de page",
            "Go to Footnote Reference",
            "Go to Footnote Reference",
            "转到脚注引用",
        ],
    ),
    ("Go to Page…", ["Go to Page…", "Atteindre la page…", "Go to Page…", "Go to Page…", "转到页面…"]),
    ("Gradient Feather", ["Gradient Feather", "Contour progressif dégradé", "Gradient Feather", "Gradient Feather", "渐变羽化"]),
    ("Gridify", ["Gridify", "Mettre en grille", "Gridify", "Gridify", "网格化"]),
    ("Group Transparency", ["Group Transparency", "Transparence du groupe", "Group Transparency", "Group Transparency", "编组透明度"]),
    ("Guides", ["Guides", "Repères", "Guides", "Guides", "参考线"]),
    ("Hide Menu Item", ["Hide Menu Item", "Masquer la commande de menu", "Hide Menu Item", "Hide Menu Item", "隐藏菜单项"]),
    ("Hide/Lock Others", ["Hide/Lock Others", "Masquer/verrouiller les autres", "Hide/Lock Others", "Hide/Lock Others", "隐藏/锁定其他"]),
    (
        "High Quality Display",
        ["High Quality Display", "Affichage de qualité supérieure", "High Quality Display", "High Quality Display", "高品质显示"],
    ),
    ("History", ["History", "Historique", "History", "History", "历史记录"]),
    ("Hyphenation Exceptions", ["Hyphenation Exceptions", "Exceptions de césure", "Hyphenation Exceptions", "Hyphenation Exceptions", "断字例外"]),
    (
        "Import Options: Styles",
        ["Import Options: Styles", "Options d'importation : styles", "Import Options: Styles", "Import Options: Styles", "导入选项: 样式"],
    ),
    (
        "Index Page References",
        ["Index Page References", "Références de page de l'index", "Index Page References", "Index Page References", "索引页引用"],
    ),
    ("Inner Glow", ["Inner Glow", "Lueur interne", "Inner Glow", "Inner Glow", "内发光"]),
    ("Inner Shadow", ["Inner Shadow", "Ombre interne", "Inner Shadow", "Inner Shadow", "内阴影"]),
    (
        "Insert Anchored Object…",
        ["Insert Anchored Object…", "Insérer un objet ancré…", "Insert Anchored Object…", "Insert Anchored Object…", "插入锚定对象…"],
    ),
    (
        "Insert Cross-Reference…",
        ["Insert Cross-Reference…", "Insérer une référence croisée…", "Insert Cross-Reference…", "Insert Cross-Reference…", "插入交叉引用…"],
    ),
    ("Insert Endnote", ["Insert Endnote", "Insérer une note de fin", "Insert Endnote", "Insert Endnote", "插入尾注"]),
    ("Insert Footnote", ["Insert Footnote", "Insérer une note de bas de page", "Insert Footnote", "Insert Footnote", "插入脚注"]),
    (
        "Insert Math Expression…",
        ["Insert Math Expression…", "Insérer une expression mathématique…", "Insert Math Expression…", "Insert Math Expression…", "插入数学公式…"],
    ),
    ("Insert Pages…", ["Insert Pages…", "Insérer des pages…", "Insert Pages…", "Insert Pages…", "插入页面…"]),
    ("Insert Variable", ["Insert Variable", "Insérer une variable", "Insert Variable", "Insert Variable", "插入变量"]),
    ("Inspect Document", ["Inspect Document", "Inspecter le document", "Inspect Document", "Inspect Document", "检查文档"]),
    (
        "Interface Color Theme",
        ["Interface Color Theme", "Thème de couleur de l'interface", "Interface Color Theme", "Interface Color Theme", "界面颜色主题"],
    ),
    (
        "Join the ArtCraft Discord…",
        [
            "Join the ArtCraft Discord…",
            "Rejoindre le Discord d'ArtCraft…",
            "Join the ArtCraft Discord…",
            "Join the ArtCraft Discord…",
            "加入 ArtCraft Discord…",
        ],
    ),
    ("Last Object Below", ["Last Object Below", "Dernier objet en dessous", "Last Object Below", "Last Object Below", "下方最后一个对象"]),
    ("Library Contents", ["Library Contents", "Contenu de la bibliothèque", "Library Contents", "Library Contents", "库内容"]),
    ("Library Items", ["Library Items", "Éléments de la bibliothèque", "Library Items", "Library Items", "库项目"]),
    ("Linked Stories", ["Linked Stories", "Articles liés", "Linked Stories", "Linked Stories", "链接的文章"]),
    ("Liquid Page Rule", ["Liquid Page Rule", "Règle de page liquide", "Liquid Page Rule", "Liquid Page Rule", "自适应页面规则"]),
    ("List Documents", ["List Documents", "Lister les documents", "List Documents", "List Documents", "列出文档"]),
    ("List Styles", ["List Styles", "Lister les styles", "List Styles", "List Styles", "列表样式"]),
    ("List Tools", ["List Tools", "Lister les outils", "List Tools", "List Tools", "列出工具"]),
    ("Load Place Cursor", ["Load Place Cursor", "Charger le curseur d'importation", "Load Place Cursor", "Load Place Cursor", "加载放置光标"]),
    ("Make Compound Path", ["Make Compound Path", "Créer un tracé transparent", "Make Compound Path", "Make Compound Path", "建立复合路径"]),
    ("Map Styles to Tags", ["Map Styles to Tags", "Associer les styles aux balises", "Map Styles to Tags", "Map Styles to Tags", "将样式映射到标签"]),
    ("Math Expression SVG", ["Math Expression SVG", "SVG d'expression mathématique", "Math Expression SVG", "Math Expression SVG", "数学公式 SVG"]),
    ("Media Options", ["Media Options", "Options multimédia", "Media Options", "Media Options", "媒体选项"]),
    ("Menus…", ["Menus…", "Menus…", "Menus…", "Menus…", "菜单…"]),
    ("Merge Layers", ["Merge Layers", "Fusionner les calques", "Merge Layers", "Merge Layers", "合并图层"]),
    ("Move Caret", ["Move Caret", "Déplacer le curseur", "Move Caret", "Move Caret", "移动插入点"]),
    ("Move Gap", ["Move Gap", "Déplacer l'espace", "Move Gap", "Move Gap", "移动间隙"]),
    ("Move Row", ["Move Row", "Déplacer la ligne", "Move Row", "Move Row", "移动行"]),
    ("New Book", ["New Book", "Nouveau livre", "New Book", "New Book", "新建书籍"]),
    ("New Cell Style…", ["New Cell Style…", "Nouveau style de cellule…", "New Cell Style…", "New Cell Style…", "新建单元格样式…"]),
    ("New Color Swatch…", ["New Color Swatch…", "Nouvelle nuance de couleur…", "New Color Swatch…", "New Color Swatch…", "新建颜色色板…"]),
    ("New Condition…", ["New Condition…", "Nouvelle condition…", "New Condition…", "New Condition…", "新建条件…"]),
    ("New Guide", ["New Guide", "Nouveau repère", "New Guide", "New Guide", "新建参考线"]),
    (
        "New Hyperlink Destination…",
        [
            "New Hyperlink Destination…",
            "Nouvelle destination d'hyperlien…",
            "New Hyperlink Destination…",
            "New Hyperlink Destination…",
            "新建超链接目标…",
        ],
    ),
    ("New Hyperlink…", ["New Hyperlink…", "Nouvel hyperlien…", "New Hyperlink…", "New Hyperlink…", "新建超链接…"]),
    ("New Library", ["New Library", "Nouvelle bibliothèque", "New Library", "New Library", "新建库"]),
    ("New Page Reference…", ["New Page Reference…", "Nouvelle référence de page…", "New Page Reference…", "New Page Reference…", "新建页面引用…"]),
    (
        "New Paragraph Style…",
        ["New Paragraph Style…", "Nouveau style de paragraphe…", "New Paragraph Style…", "New Paragraph Style…", "新建段落样式…"],
    ),
    ("New Stroke Style…", ["New Stroke Style…", "Nouveau style de contour…", "New Stroke Style…", "New Stroke Style…", "新建描边样式…"]),
    ("New Table Style…", ["New Table Style…", "Nouveau style de tableau…", "New Table Style…", "New Table Style…", "新建表样式…"]),
    ("Next Cell", ["Next Cell", "Cellule suivante", "Next Cell", "Next Cell", "下一个单元格"]),
    ("Next Document", ["Next Document", "Document suivant", "Next Document", "Next Document", "下一个文档"]),
    ("Next Object Above", ["Next Object Above", "Objet suivant au-dessus", "Next Object Above", "Next Object Above", "上方下一个对象"]),
    ("Next Object Below", ["Next Object Below", "Objet suivant en dessous", "Next Object Below", "Next Object Below", "下方下一个对象"]),
    (
        "Next Object in Group",
        ["Next Object in Group", "Objet suivant dans le groupe", "Next Object in Group", "Next Object in Group", "组中的下一个对象"],
    ),
    ("Notes", ["Notes", "Notes", "Notes", "Notes", "注释"]),
    (
        "Object Export Options",
        ["Object Export Options", "Options d'exportation de l'objet", "Object Export Options", "Object Export Options", "对象导出选项"],
    ),
    (
        "Object Export Options…",
        ["Object Export Options…", "Options d'exportation de l'objet…", "Object Export Options…", "Object Export Options…", "对象导出选项…"],
    ),
    (
        "Object Layer Options…",
        ["Object Layer Options…", "Options de calque d'objet…", "Object Layer Options…", "Object Layer Options…", "对象图层选项…"],
    ),
    ("Object Layers", ["Object Layers", "Calques d'objet", "Object Layers", "Object Layers", "对象图层"]),
    (
        "Object Liquid Settings",
        [
            "Object Liquid Settings",
            "Réglages de mise en page liquide de l'objet",
            "Object Liquid Settings",
            "Object Liquid Settings",
            "对象自适应设置",
        ],
    ),
    ("Open Book", ["Open Book", "Ouvrir le livre", "Open Book", "Open Book", "打开书籍"]),
    ("Open Bytes", ["Open Bytes", "Ouvrir les octets", "Open Bytes", "Open Bytes", "打开字节"]),
    ("Open IDML", ["Open IDML", "Ouvrir un fichier IDML", "Open IDML", "Open IDML", "打开 IDML"]),
    ("Open Library", ["Open Library", "Ouvrir la bibliothèque", "Open Library", "Open Library", "打开库"]),
    ("Outer Glow", ["Outer Glow", "Lueur externe", "Outer Glow", "Outer Glow", "外发光"]),
    ("Overprint Preview", ["Overprint Preview", "Aperçu de la surimpression", "Overprint Preview", "Overprint Preview", "叠印预览"]),
    (
        "Override All Parent Page Items",
        [
            "Override All Parent Page Items",
            "Remplacer tous les éléments du gabarit",
            "Override All Parent Page Items",
            "Override All Parent Page Items",
            "覆盖所有主页项目",
        ],
    ),
    ("Page Size", ["Page Size", "Format de page", "Page Size", "Page Size", "页面大小"]),
    ("Page Transition", ["Page Transition", "Transition de page", "Page Transition", "Page Transition", "页面过渡"]),
    ("Page Transitions", ["Page Transitions", "Transitions de page", "Page Transitions", "Page Transitions", "页面过渡"]),
    ("Paragraph Formatting", ["Paragraph Formatting", "Mise en forme des paragraphes", "Paragraph Formatting", "Paragraph Formatting", "段落格式"]),
    (
        "Paragraph Style Options…",
        ["Paragraph Style Options…", "Options de style de paragraphe…", "Paragraph Style Options…", "Paragraph Style Options…", "段落样式选项…"],
    ),
    ("Paste Into", ["Paste Into", "Coller dedans", "Paste Into", "Paste Into", "贴入内部"]),
    (
        "Paste without Formatting",
        ["Paste without Formatting", "Coller sans mise en forme", "Paste without Formatting", "Paste without Formatting", "粘贴时不包含格式"],
    ),
    ("Place", ["Place", "Importer", "Place", "Place", "置入"]),
    ("Place Caret", ["Place Caret", "Placer le curseur", "Place Caret", "Place Caret", "放置光标"]),
    ("Place Item", ["Place Item", "Importer l'élément", "Place Item", "Place Item", "置入项目"]),
    ("Place Snippet", ["Place Snippet", "Importer un extrait", "Place Snippet", "Place Snippet", "置入片段"]),
    ("Place and Link", ["Place and Link", "Importer et lier", "Place and Link", "Place and Link", "置入并链接"]),
    (
        "Place with Import Options…",
        [
            "Place with Import Options…",
            "Importer avec les options d'importation…",
            "Place with Import Options…",
            "Place with Import Options…",
            "连同导入选项置入…",
        ],
    ),
    ("Polygon Settings…", ["Polygon Settings…", "Paramètres du polygone…", "Polygon Settings…", "Polygon Settings…", "多边形设置…"]),
    ("Preflight Document", ["Preflight Document", "Contrôle en amont du document", "Preflight Document", "Preflight Document", "预检文档"]),
    ("Previous Cell", ["Previous Cell", "Cellule précédente", "Previous Cell", "Previous Cell", "上一个单元格"]),
    ("Previous Document", ["Previous Document", "Document précédent", "Previous Document", "Previous Document", "上一个文档"]),
    (
        "Previous Object in Group",
        ["Previous Object in Group", "Objet précédent du groupe", "Previous Object in Group", "Previous Object in Group", "组中的上一个对象"],
    ),
    ("Primary Text Frame", ["Primary Text Frame", "Bloc de texte principal", "Primary Text Frame", "Primary Text Frame", "主文本框架"]),
    ("Print Booklet…", ["Print Booklet…", "Imprimer le cahier…", "Print Booklet…", "Print Booklet…", "打印小册子…"]),
    ("Printers", ["Printers", "Imprimantes", "Printers", "Printers", "打印机"]),
    ("Proof Colors", ["Proof Colors", "Couleurs d'épreuve", "Proof Colors", "Proof Colors", "校样颜色"]),
    ("Proof Setup", ["Proof Setup", "Format d'épreuve", "Proof Setup", "Proof Setup", "校样设置"]),
    ("Quick Apply…", ["Quick Apply…", "Application rapide…", "Quick Apply…", "Quick Apply…", "快速应用…"]),
    ("Recover Documents", ["Recover Documents", "Récupérer des documents", "Recover Documents", "Recover Documents", "恢复文档"]),
    ("Recovery Data", ["Recovery Data", "Données de récupération", "Recovery Data", "Recovery Data", "恢复数据"]),
    ("Reject All Changes", ["Reject All Changes", "Refuser toutes les modifications", "Reject All Changes", "Reject All Changes", "拒绝所有更改"]),
    (
        "Release Compound Path",
        ["Release Compound Path", "Libérer le tracé transparent", "Release Compound Path", "Release Compound Path", "释放复合路径"],
    ),
    (
        "Remove All Local Overrides",
        [
            "Remove All Local Overrides",
            "Supprimer tous les remplacements locaux",
            "Remove All Local Overrides",
            "Remove All Local Overrides",
            "移除所有本地覆盖",
        ],
    ),
    ("Remove Document", ["Remove Document", "Retirer le document", "Remove Document", "Remove Document", "移除文档"]),
    ("Report an Issue…", ["Report an Issue…", "Signaler un problème…", "Report an Issue…", "Report an Issue…", "报告问题…"]),
    ("Reset Shortcuts", ["Reset Shortcuts", "Réinitialiser les raccourcis", "Reset Shortcuts", "Reset Shortcuts", "重置快捷键"]),
    ("Reset Workspace", ["Reset Workspace", "Réinitialiser l'espace de travail", "Reset Workspace", "Reset Workspace", "重置工作区"]),
    ("Resize", ["Resize", "Redimensionner", "Resize", "Resize", "调整大小"]),
    ("Rotate Spread", ["Rotate Spread", "Faire pivoter la planche", "Rotate Spread", "Rotate Spread", "旋转跨页"]),
    ("Run Script", ["Run Script", "Exécuter le script", "Run Script", "Run Script", "运行脚本"]),
    ("Sample Document", ["Sample Document", "Document d'exemple", "Sample Document", "Sample Document", "示例文档"]),
    ("Satin", ["Satin", "Satin", "Satin", "Satin", "光泽"]),
    (
        "Save Recovery Data",
        ["Save Recovery Data", "Enregistrer les données de récupération", "Save Recovery Data", "Save Recovery Data", "保存恢复数据"],
    ),
    ("Script Label", ["Script Label", "Étiquette de script", "Script Label", "Script Label", "脚本标签"]),
    ("Select All on Layer", ["Select All on Layer", "Tout sélectionner sur le calque", "Select All on Layer", "Select All on Layer", "全选当前图层"]),
    ("Select Cells", ["Select Cells", "Sélectionner les cellules", "Select Cells", "Select Cells", "选择单元格"]),
    ("Select Column", ["Select Column", "Sélectionner la colonne", "Select Column", "Select Column", "选择列"]),
    ("Select Frame", ["Select Frame", "Sélectionner le bloc", "Select Frame", "Select Frame", "选择框架"]),
    ("Select Row", ["Select Row", "Sélectionner la ligne", "Select Row", "Select Row", "选择行"]),
    ("Select Table", ["Select Table", "Sélectionner le tableau", "Select Table", "Select Table", "选择表格"]),
    ("Select Text", ["Select Text", "Sélectionner le texte", "Select Text", "Select Text", "选择文本"]),
    ("Select Tool", ["Select Tool", "Sélectionner un outil", "Select Tool", "Select Tool", "选择工具"]),
    ("Select Word", ["Select Word", "Sélectionner le mot", "Select Word", "Select Word", "选择单词"]),
    ("Selection Attributes", ["Selection Attributes", "Attributs de la sélection", "Selection Attributes", "Selection Attributes", "选择属性"]),
    ("Separations Preview", ["Separations Preview", "Aperçu des séparations", "Separations Preview", "Separations Preview", "分色预览"]),
    ("Serialize", ["Serialize", "Sérialiser", "Serialize", "Serialize", "序列化"]),
    ("Set Active Layer", ["Set Active Layer", "Définir le calque actif", "Set Active Layer", "Set Active Layer", "设置活动图层"]),
    ("Set Shortcut", ["Set Shortcut", "Définir le raccourci", "Set Shortcut", "Set Shortcut", "设置快捷键"]),
    (
        "Set Visibility / Lock",
        ["Set Visibility / Lock", "Définir visibilité / verrouillage", "Set Visibility / Lock", "Set Visibility / Lock", "设置可见性/锁定"],
    ),
    ("Show Panel", ["Show Panel", "Afficher le panneau", "Show Panel", "Show Panel", "显示面板"]),
    (
        "Show/Hide Baseline Grid",
        [
            "Show/Hide Baseline Grid",
            "Afficher/Masquer la grille de ligne de base",
            "Show/Hide Baseline Grid",
            "Show/Hide Baseline Grid",
            "显示/隐藏基线网格",
        ],
    ),
    (
        "Show/Hide Document Grid",
        ["Show/Hide Document Grid", "Show/Hide Document Grid", "Show/Hide Document Grid", "Show/Hide Document Grid", "显示/隐藏文档网格"],
    ),
    (
        "Show/Hide Frame Edges",
        ["Show/Hide Frame Edges", "Afficher/Masquer les contours de bloc", "Show/Hide Frame Edges", "Show/Hide Frame Edges", "显示/隐藏框架边缘"],
    ),
    ("Show/Hide Guides", ["Show/Hide Guides", "Afficher/Masquer les repères", "Show/Hide Guides", "Show/Hide Guides", "显示/隐藏参考线"]),
    (
        "Show/Hide Hidden Characters",
        [
            "Show/Hide Hidden Characters",
            "Afficher/Masquer les caractères masqués",
            "Show/Hide Hidden Characters",
            "Show/Hide Hidden Characters",
            "显示/隐藏隐藏字符",
        ],
    ),
    ("Show/Hide Panels", ["Show/Hide Panels", "Afficher/Masquer les panneaux", "Show/Hide Panels", "Show/Hide Panels", "显示/隐藏面板"]),
    (
        "Show/Hide Panels Except Tools",
        [
            "Show/Hide Panels Except Tools",
            "Afficher/Masquer les panneaux sauf Outils",
            "Show/Hide Panels Except Tools",
            "Show/Hide Panels Except Tools",
            "显示/隐藏面板(工具除外)",
        ],
    ),
    ("Show/Hide Rulers", ["Show/Hide Rulers", "Afficher/Masquer les règles", "Show/Hide Rulers", "Show/Hide Rulers", "显示/隐藏标尺"]),
    (
        "Show/Hide Tagged Frames",
        [
            "Show/Hide Tagged Frames",
            "Afficher/Masquer les blocs balisés",
            "Show/Hide Tagged Frames",
            "Show/Hide Tagged Frames",
            "显示/隐藏标记的框架",
        ],
    ),
    (
        "Show/Hide Text Threads",
        ["Show/Hide Text Threads", "Afficher/Masquer le chaînage du texte", "Show/Hide Text Threads", "Show/Hide Text Threads", "显示/隐藏文本串接"],
    ),
    ("Smooth", ["Smooth", "Lisse", "Smooth", "Smooth", "平滑"]),
    ("Sort", ["Sort", "Trier", "Sort", "Sort", "排序"]),
    (
        "Split Cell Horizontally",
        ["Split Cell Horizontally", "Scinder la cellule horizontalement", "Split Cell Horizontally", "Split Cell Horizontally", "水平拆分单元格"],
    ),
    (
        "Split Cell Vertically",
        ["Split Cell Vertically", "Scinder la cellule verticalement", "Split Cell Vertically", "Split Cell Vertically", "垂直拆分单元格"],
    ),
    ("Split Path", ["Split Path", "Fractionner le tracé", "Split Path", "Split Path", "拆分路径"]),
    ("Step and Repeat…", ["Step and Repeat…", "Exécuter et répéter…", "Step and Repeat…", "Step and Repeat…", "步进和重复…"]),
    ("Stroke Styles", ["Stroke Styles", "Styles de contour", "Stroke Styles", "Stroke Styles", "描边样式"]),
    ("Structure", ["Structure", "Structure", "Structure", "Structure", "结构"]),
    ("Style Source", ["Style Source", "Source du style", "Style Source", "Style Source", "样式源"]),
    ("Synchronize Book", ["Synchronize Book", "Synchroniser le livre", "Synchronize Book", "Synchronize Book", "同步书籍"]),
    ("Table Options", ["Table Options", "Options de tableau", "Table Options", "Table Options", "表选项"]),
    ("Table Panel", ["Table Panel", "Panneau Tableau", "Table Panel", "Table Panel", "表格面板"]),
    ("Table Style Options…", ["Table Style Options…", "Options de style de tableau…", "Table Style Options…", "Table Style Options…", "表样式选项…"]),
    (
        "Table of Contents Entries",
        ["Table of Contents Entries", "Entrées de la table des matières", "Table of Contents Entries", "Table of Contents Entries", "目录条目"],
    ),
    ("Table of Contents…", ["Table of Contents…", "Table des matières…", "Table of Contents…", "Table of Contents…", "目录…"]),
    ("Text Anchors", ["Text Anchors", "Ancres de texte", "Text Anchors", "Text Anchors", "文本锚点"]),
    ("Text Variables", ["Text Variables", "Variables de texte", "Text Variables", "Text Variables", "文本变量"]),
    ("Toggle Normal/Preview", ["Toggle Normal/Preview", "Basculer Normal/Aperçu", "Toggle Normal/Preview", "Toggle Normal/Preview", "切换正常/预览"]),
    (
        "Toggle Presentation",
        [
            "Präsentation ein/aus",
            "Activer/désactiver la présentation",
            "Activar/desactivar presentación",
            "プレゼンテーションを切り替え",
            "切换演示模式",
        ],
    ),
    ("Toggle Selection", ["Toggle Selection", "Basculer la sélection", "Toggle Selection", "Toggle Selection", "切换选择"]),
    ("Tools: Double Column", ["Tools: Double Column", "Outils : double colonne", "Tools: Double Column", "Tools: Double Column", "工具: 双列"]),
    ("Transform Again", ["Transform Again", "Répéter la transformation", "Transform Again", "Transform Again", "再次变换"]),
    ("Transform Panel", ["Transform Panel", "Panneau Transformation", "Transform Panel", "Transform Panel", "变换面板"]),
    ("Transform Values", ["Transform Values", "Valeurs de transformation", "Transform Values", "Transform Values", "变换值"]),
    (
        "Transparency Blend Space",
        ["Transparency Blend Space", "Espace de fusion de la transparence", "Transparency Blend Space", "Transparency Blend Space", "透明度混合空间"],
    ),
    (
        "Transparency Flattener Presets",
        [
            "Transparency Flattener Presets",
            "Préréglages d'aplatissement de la transparence",
            "Transparency Flattener Presets",
            "Transparency Flattener Presets",
            "透明度拼合器预设",
        ],
    ),
    ("Type on a Path", ["Type on a Path", "Texte curviligne", "Type on a Path", "Type on a Path", "路径文字"]),
    (
        "Type on a Path Options…",
        ["Type on a Path Options…", "Options de texte curviligne…", "Type on a Path Options…", "Type on a Path Options…", "路径文字选项…"],
    ),
    ("Typical Display", ["Typical Display", "Affichage standard", "Typical Display", "Typical Display", "典型显示"]),
    ("UI Scaling", ["UI Scaling", "Mise à l'échelle de l'interface", "UI Scaling", "UI Scaling", "UI 缩放"]),
    ("Update Link", ["Update Link", "Mettre à jour le lien", "Update Link", "Update Link", "更新链接"]),
    (
        "User Dictionary Words",
        ["User Dictionary Words", "Mots du dictionnaire utilisateur", "User Dictionary Words", "User Dictionary Words", "用户词典单词"],
    ),
    ("User Dictionary…", ["User Dictionary…", "Dictionnaire utilisateur…", "User Dictionary…", "User Dictionary…", "用户词典…"]),
    ("Zoom To", ["Zoom To", "Zoom sur", "Zoom To", "Zoom To", "缩放至"]),
    ("⇧", ["⇧", "⇧", "⇧", "⇧", "⇧"]),
    ("⌃", ["⌃", "⌃", "⌃", "⌃", "⌃"]),
    ("⌘", ["⌘", "⌘", "⌘", "⌘", "⌘"]),
    ("⌥", ["⌥", "⌥", "⌥", "⌥", "⌥"]),
    ("Accept Change", ["Accept Change", "Accepter la modification", "Accept Change", "Accept Change", "接受更改"]),
    ("Add Anchor", ["Add Anchor", "Ajouter un point d'ancrage", "Add Anchor", "Add Anchor", "添加锚点"]),
    (
        "Add Selection to Article",
        ["Add Selection to Article", "Ajouter la sélection à l'article", "Add Selection to Article", "Add Selection to Article", "将选择添加到文章"],
    ),
    ("Add Unnamed Colors", ["Add Unnamed Colors", "Ajouter les couleurs sans nom", "Add Unnamed Colors", "Add Unnamed Colors", "添加未命名颜色"]),
    ("Add to Dictionary", ["Add to Dictionary", "Ajouter au dictionnaire", "Add to Dictionary", "Add to Dictionary", "添加到字典"]),
    ("Align Center", ["Align Center", "Aligner au centre", "Align Center", "Align Center", "居中对齐"]),
    ("Align Left", ["Align Left", "Aligner à gauche", "Align Left", "Align Left", "左对齐"]),
    ("Align Right", ["Align Right", "Aligner à droite", "Align Right", "Align Right", "右对齐"]),
    (
        "Apply Character Style",
        ["Apply Character Style", "Appliquer le style de caractère", "Apply Character Style", "Apply Character Style", "应用字符样式"],
    ),
    ("Apply Object Style", ["Apply Object Style", "Appliquer le style d'objet", "Apply Object Style", "Apply Object Style", "应用对象样式"]),
    (
        "Apply Paragraph Style",
        ["Apply Paragraph Style", "Appliquer le style de paragraphe", "Apply Paragraph Style", "Apply Paragraph Style", "应用段落样式"],
    ),
    ("Apply Table Style", ["Apply Table Style", "Appliquer le style de tableau", "Apply Table Style", "Apply Table Style", "应用表样式"]),
    ("Article Options", ["Article Options", "Options d'article", "Article Options", "Article Options", "文章选项"]),
    ("Basic Feather", ["Basic Feather", "Contour progressif simple", "Basic Feather", "Basic Feather", "基本羽化"]),
    ("Bold", ["Bold", "Gras", "Bold", "Bold", "加粗"]),
    ("Bring Forward", ["Bring Forward", "En avant", "Bring Forward", "Bring Forward", "向前移动"]),
    ("Bring to Front", ["Bring to Front", "Premier plan", "Bring to Front", "Bring to Front", "置于顶层"]),
    ("Change", ["Change", "Remplacer", "Change", "Change", "更改"]),
    (
        "Character Style Options…",
        ["Character Style Options…", "Options de style de caractère…", "Character Style Options…", "Character Style Options…", "字符样式选项…"],
    ),
    ("Close Path", ["Close Path", "Fermer le tracé", "Close Path", "Close Path", "闭合路径"]),
    ("Color Group Options", ["Color Group Options", "Options du groupe de couleurs", "Color Group Options", "Color Group Options", "颜色组选项"]),
    ("Column Width", ["Column Width", "Largeur de colonne", "Column Width", "Column Width", "列宽"]),
    ("Balance Columns", ["Spalten ausgleichen", "Équilibrer les colonnes", "Equilibrar columnas", "段の高さを揃える", "平衡栏高"]),
    ("Column Rules", ["Spaltenlinien", "Filets de colonne", "Filetes de columna", "段間罫線", "栏间线"]),
    ("Insert Column Rule", ["Spaltenlinie einfügen", "Insérer un filet de colonne", "Insertar filete de columna", "段間罫線を挿入", "插入栏间线"]),
    ("Tint %", ["Farbton %", "Teinte %", "Matiz %", "濃淡 %", "色调 %"]),
    ("Top Inset", ["Oberer Einzug", "Retrait supérieur", "Sangría superior", "上インセット", "顶部内边距"]),
    ("Bottom Inset", ["Unterer Einzug", "Retrait inférieur", "Sangría inferior", "下インセット", "底部内边距"]),
    ("Horizontal Offset", ["Horizontaler Versatz", "Décalage horizontal", "Desplazamiento horizontal", "水平オフセット", "水平偏移"]),
    ("Condition Options…", ["Condition Options…", "Options de condition…", "Condition Options…", "Condition Options…", "条件选项…"]),
    (
        "Convert to Liquid Guide",
        ["Convert to Liquid Guide", "Convertir en repère liquide", "Convert to Liquid Guide", "Convert to Liquid Guide", "转换为自适应参考线"],
    ),
    ("Convert to Object", ["Convert to Object", "Convertir en objet", "Convert to Object", "Convert to Object", "转换为对象"]),
    ("Create Line", ["Create Line", "Créer un trait", "Create Line", "Create Line", "创建线条"]),
    ("Create Path", ["Create Path", "Créer un tracé", "Create Path", "Create Path", "创建路径"]),
    ("Decrease Point Size", ["Decrease Point Size", "Diminuer le corps", "Decrease Point Size", "Decrease Point Size", "减小字号"]),
    ("Delete Article", ["Delete Article", "Supprimer l'article", "Delete Article", "Delete Article", "删除文章"]),
    ("Delete Bookmark", ["Delete Bookmark", "Supprimer le signet", "Delete Bookmark", "Delete Bookmark", "删除书签"]),
    ("Delete Endnote", ["Delete Endnote", "Supprimer la note de fin", "Delete Endnote", "Delete Endnote", "删除尾注"]),
    ("Delete Footnote", ["Delete Footnote", "Supprimer la note de bas de page", "Delete Footnote", "Delete Footnote", "删除脚注"]),
    ("Delete Guide", ["Delete Guide", "Supprimer le repère", "Delete Guide", "Delete Guide", "删除参考线"]),
    ("Delete Hyperlink", ["Delete Hyperlink", "Supprimer l'hyperlien", "Delete Hyperlink", "Delete Hyperlink", "删除超链接"]),
    ("Delete List", ["Delete List", "Supprimer la liste", "Delete List", "Delete List", "删除列表"]),
    ("Delete Note", ["Delete Note", "Supprimer la note", "Delete Note", "Delete Note", "删除注释"]),
    ("Delete Pages", ["Delete Pages", "Supprimer les pages", "Delete Pages", "Delete Pages", "删除页面"]),
    (
        "Delete Paragraph Style",
        ["Delete Paragraph Style", "Supprimer le style de paragraphe", "Delete Paragraph Style", "Delete Paragraph Style", "删除段落样式"],
    ),
    ("Delete Stroke Style", ["Delete Stroke Style", "Supprimer le style de contour", "Delete Stroke Style", "Delete Stroke Style", "删除描边样式"]),
    ("Delete Table", ["Delete Table", "Supprimer le tableau", "Delete Table", "Delete Table", "删除表格"]),
    ("Delete Tag", ["Delete Tag", "Supprimer la balise", "Delete Tag", "Delete Tag", "删除标记"]),
    ("Delete Text", ["Delete Text", "Supprimer le texte", "Delete Text", "Delete Text", "删除文本"]),
    (
        "Distribute Columns Evenly",
        ["Distribute Columns Evenly", "Répartir les colonnes uniformément", "Distribute Columns Evenly", "Distribute Columns Evenly", "均匀分布列"],
    ),
    ("Edit Endnote", ["Edit Endnote", "Modifier la note de fin", "Edit Endnote", "Edit Endnote", "编辑尾注"]),
    ("Edit Note", ["Edit Note", "Modifier la note", "Edit Note", "Edit Note", "编辑注释"]),
    ("Embed Link", ["Embed Link", "Incorporer le lien", "Embed Link", "Embed Link", "嵌入链接"]),
    ("Fill", ["Fill", "Fond", "Fill", "Fill", "填色"]),
    (
        "Fill with Placeholder Text",
        [
            "Fill with Placeholder Text",
            "Remplir avec le texte de substitution",
            "Fill with Placeholder Text",
            "Fill with Placeholder Text",
            "用占位符文本填充",
        ],
    ),
    ("Flip", ["Flip", "Retourner", "Flip", "Flip", "翻转"]),
    ("Hyperlink Options…", ["Hyperlink Options…", "Options d'hyperlien…", "Hyperlink Options…", "Hyperlink Options…", "超链接选项…"]),
    ("Increase Point Size", ["Increase Point Size", "Augmenter le corps", "Increase Point Size", "Increase Point Size", "增大字号"]),
    ("Insert Column Left", ["Insert Column Left", "Insérer une colonne à gauche", "Insert Column Left", "Insert Column Left", "在左侧插入列"]),
    ("Insert Column Right", ["Insert Column Right", "Insérer une colonne à droite", "Insert Column Right", "Insert Column Right", "在右侧插入列"]),
    ("Insert Row Above", ["Insert Row Above", "Insérer une ligne au-dessus", "Insert Row Above", "Insert Row Above", "在上方插入行"]),
    ("Insert Row Below", ["Insert Row Below", "Insérer une ligne en dessous", "Insert Row Below", "Insert Row Below", "在下方插入行"]),
    ("Italic", ["Italic", "Italique", "Italic", "Italic", "斜体"]),
    ("Justify Left", ["Justify Left", "Justifier à gauche", "Justify Left", "Justify Left", "左对齐齐行"]),
    ("Layer Options…", ["Layer Options…", "Options de calque…", "Layer Options…", "Layer Options…", "图层选项…"]),
    ("Move", ["Move", "Déplacer", "Move", "Move", "移动"]),
    ("Move Anchors", ["Move Anchors", "Déplacer les points d'ancrage", "Move Anchors", "Move Anchors", "移动锚点"]),
    ("Move Column", ["Move Column", "Déplacer la colonne", "Move Column", "Move Column", "移动列"]),
    ("Move Guide", ["Move Guide", "Déplacer le repère", "Move Guide", "Move Guide", "移动参考线"]),
    ("Move Layer", ["Move Layer", "Déplacer le calque", "Move Layer", "Move Layer", "移动图层"]),
    ("Move Pages…", ["Move Pages…", "Déplacer des pages…", "Move Pages…", "Move Pages…", "移动页面…"]),
    ("Move to Layer", ["Move to Layer", "Déplacer vers le calque", "Move to Layer", "Move to Layer", "移动到图层"]),
    ("New Article", ["New Article", "Nouvel article", "New Article", "New Article", "新建文章"]),
    ("New Bookmark", ["New Bookmark", "Nouveau signet", "New Bookmark", "New Bookmark", "新建书签"]),
    (
        "New Character Style…",
        ["New Character Style…", "Nouveau style de caractère…", "New Character Style…", "New Character Style…", "新建字符样式…"],
    ),
    ("New Layer…", ["New Layer…", "Nouveau calque…", "New Layer…", "New Layer…", "新建图层…"]),
    ("New Note", ["New Note", "Nouvelle note", "New Note", "New Note", "新建注释"]),
    ("New Object Style…", ["New Object Style…", "Nouveau style d'objet…", "New Object Style…", "New Object Style…", "新建对象样式…"]),
    ("New Parent…", ["New Parent…", "Nouveau gabarit…", "New Parent…", "New Parent…", "新建主页…"]),
    ("New Tag", ["New Tag", "Nouvelle balise", "New Tag", "New Tag", "新建标记"]),
    ("Opacity", ["Opacity", "Opacité", "Opacity", "Opacity", "不透明度"]),
    ("Paste in Place", ["Paste in Place", "Coller sur place", "Paste in Place", "Paste in Place", "原位粘贴"]),
    (
        "Place Loaded Graphic",
        ["Place Loaded Graphic", "Importer le graphique chargé", "Place Loaded Graphic", "Place Loaded Graphic", "置入已加载的图形"],
    ),
    ("Reject Change", ["Reject Change", "Refuser la modification", "Reject Change", "Reject Change", "拒绝更改"]),
    (
        "Release State to Objects",
        ["Release State to Objects", "Libérer l'état en objets", "Release State to Objects", "Release State to Objects", "将状态释放为对象"],
    ),
    (
        "Remove Hyphenation Exception",
        [
            "Remove Hyphenation Exception",
            "Supprimer l'exception de césure",
            "Remove Hyphenation Exception",
            "Remove Hyphenation Exception",
            "移除断字例外",
        ],
    ),
    ("Remove from Article", ["Remove from Article", "Retirer de l'article", "Remove from Article", "Remove from Article", "从文章中移除"]),
    ("Rename", ["Rename", "Renommer", "Rename", "Rename", "重命名"]),
    ("Rename Bookmark", ["Rename Bookmark", "Renommer le signet", "Rename Bookmark", "Rename Bookmark", "重命名书签"]),
    ("Rotate", ["Rotate", "Rotation", "Rotate", "Rotate", "旋转"]),
    ("Row Height", ["Row Height", "Hauteur de ligne", "Row Height", "Row Height", "行高"]),
    ("Scale", ["Scale", "Échelle", "Scale", "Scale", "缩放"]),
    ("Send Backward", ["Send Backward", "En arrière", "Send Backward", "Send Backward", "向后移动"]),
    ("Send to Back", ["Send to Back", "Arrière-plan", "Send to Back", "Send to Back", "置于底层"]),
    (
        "Set Cross-Reference Format",
        [
            "Set Cross-Reference Format",
            "Définir le format de référence croisée",
            "Set Cross-Reference Format",
            "Set Cross-Reference Format",
            "设置交叉引用格式",
        ],
    ),
    (
        "Set Footnote Text",
        ["Set Footnote Text", "Définir le texte de la note de bas de page", "Set Footnote Text", "Set Footnote Text", "设置脚注文本"],
    ),
    ("Set Story Text", ["Set Story Text", "Définir le texte de l'article", "Set Story Text", "Set Story Text", "设置文章文本"]),
    ("Shear", ["Shear", "Déformation", "Shear", "Shear", "切变"]),
    ("Show All on Spread", ["Show All on Spread", "Tout afficher sur la planche", "Show All on Spread", "Show All on Spread", "在跨页上全部显示"]),
    ("Show State", ["Show State", "Afficher l'état", "Show State", "Show State", "显示状态"]),
    ("State Options", ["State Options", "Options d'état", "State Options", "State Options", "状态选项"]),
    ("Tag Frame", ["Tag Frame", "Baliser le bloc", "Tag Frame", "Tag Frame", "标记框架"]),
    ("Tag Text", ["Tag Text", "Baliser le texte", "Tag Text", "Tag Text", "标记文本"]),
    ("Track Changes", ["Track Changes", "Suivi des modifications", "Track Changes", "Track Changes", "修订"]),
    ("Unlink", ["Unlink", "Délier", "Unlink", "Unlink", "取消链接"]),
    (
        "Unlock All on Spread",
        ["Unlock All on Spread", "Tout déverrouiller sur la planche", "Unlock All on Spread", "Unlock All on Spread", "解锁跨页上的所有内容"],
    ),
    ("Update Index", ["Update Index", "Mettre à jour l'index", "Update Index", "Update Index", "更新索引"]),
    (
        "Update Table of Contents",
        ["Update Table of Contents", "Mettre à jour la table des matières", "Update Table of Contents", "Update Table of Contents", "更新目录"],
    ),
    (
        "Bulleted and Numbered Lists",
        [
            "Bulleted and Numbered Lists",
            "Listes à puces et numérotées",
            "Bulleted and Numbered Lists",
            "Bulleted and Numbered Lists",
            "项目符号和编号列表",
        ],
    ),
    (
        "Insert Special Character",
        ["Insert Special Character", "Insérer un caractère spécial", "Insert Special Character", "Insert Special Character", "插入特殊字符"],
    ),
    ("Insert White Space", ["Insert White Space", "Insérer un espace", "Insert White Space", "Insert White Space", "插入空格"]),
    (
        "Insert Break Character",
        ["Insert Break Character", "Insérer un caractère de saut", "Insert Break Character", "Insert Break Character", "插入分隔符"],
    ),
    (
        "Hyperlinks Cross-References",
        [
            "Hyperlinks Cross-References",
            "Hyperliens et références croisées",
            "Hyperlinks Cross-References",
            "Hyperlinks Cross-References",
            "超链接交叉引用",
        ],
    ),
    (
        "Document Footnote Options...",
        [
            "Document Footnote Options...",
            "Options de notes de bas de page du document...",
            "Document Footnote Options...",
            "Document Footnote Options...",
            "文档脚注选项…",
        ],
    ),
    ("  Close  ", ["  Close  ", "  Fermer  ", "  Close  ", "  Close  ", "  关闭  "]),
    ("  New file  ", ["  New file  ", "  Nouveau fichier  ", "  New file  ", "  New file  ", "  新建文件  "]),
    ("  OK  ", ["  OK  ", "  OK  ", "  OK  ", "  OK  ", "  确定  "]),
    ("  Open  ", ["  Open  ", "  Ouvrir  ", "  Open  ", "  Open  ", "  打开  "]),
    (
        "  Open sample magazine  ",
        ["  Open sample magazine  ", "  Ouvrir un magazine d'exemple  ", "  Open sample magazine  ", "  Open sample magazine  ", "  打开示例杂志  "],
    ),
    ("(Top Level)", ["(Top Level)", "(Niveau supérieur)", "(Top Level)", "(Top Level)", "(顶层)"]),
    ("(import)", ["(import)", "(importation)", "(import)", "(import)", "(导入)"]),
    ("Anchored Object", ["Anchored Object", "Objet ancré", "Anchored Object", "Anchored Object", "锚定对象"]),
    (
        "Apply Attributes (Eyedropper",
        [
            "Apply Attributes (Eyedropper",
            "Appliquer les attributs (Pipette",
            "Apply Attributes (Eyedropper",
            "Apply Attributes (Eyedropper",
            "应用属性 (吸管",
        ],
    ),
    ("Baseline Grid", ["Baseline Grid", "Grille de ligne de base", "Baseline Grid", "Baseline Grid", "基线网格"]),
    ("Bleed and Slug", ["Bleed and Slug", "Fond perdu et ligne-bloc", "Bleed and Slug", "Bleed and Slug", "出血和辅助信息区"]),
    (
        "Buttons act in interactive PDF export.",
        [
            "Buttons act in interactive PDF export.",
            "Les boutons sont actifs dans l'export PDF interactif.",
            "Buttons act in interactive PDF export.",
            "Buttons act in interactive PDF export.",
            "按钮在交互式 PDF 导出中起作用。",
        ],
    ),
    ("Captions", ["Captions", "Légendes", "Captions", "Captions", "题注"]),
    ("Change All (Object", ["Change All (Object", "Tout remplacer (objet", "Change All (Object", "Change All (Object", "全部更改 (对象"]),
    ("Character Settings", ["Character Settings", "Réglages des caractères", "Character Settings", "Character Settings", "字符设置"]),
    ("Choose a link.", ["Choose a link.", "Choisissez un lien.", "Choose a link.", "Choose a link.", "选择一个链接。"]),
    ("Clipping Path", ["Clipping Path", "Masque", "Clipping Path", "Clipping Path", "剪切路径"]),
    (
        "Collect objects with the Content Collector (B); place them with the Content Placer.",
        [
            "Collect objects with the Content Collector (B); place them with the Content Placer.",
            "Collectez des objets avec l'outil Collecteur de contenu (B) ; placez-les avec l'outil Placeur de contenu.",
            "Collect objects with the Content Collector (B); place them with the Content Placer.",
            "Collect objects with the Content Collector (B); place them with the Content Placer.",
            "使用内容收集器 (B) 收集对象；使用内容放置器放置它们。",
        ],
    ),
    ("Content Fitting", ["Content Fitting", "Ajustement du contenu", "Content Fitting", "Content Fitting", "内容适合"]),
    ("Convert Cell Type", ["Convert Cell Type", "Convertir le type de cellule", "Convert Cell Type", "Convert Cell Type", "转换单元格类型"]),
    ("Copy Link(s", ["Copy Link(s", "Copier lien(s", "Copy Link(s", "Copy Link(s", "复制链接("]),
    (
        "Create Alternate Layout",
        ["Create Alternate Layout", "Créer une variante de mise en page", "Create Alternate Layout", "Create Alternate Layout", "创建替代版面"],
    ),
    ("Crop Amount", ["Crop Amount", "Valeur de recadrage", "Crop Amount", "Crop Amount", "裁剪量"]),
    (
        "Cross-Reference Format",
        ["Cross-Reference Format", "Format de référence croisée", "Cross-Reference Format", "Cross-Reference Format", "交叉引用格式"],
    ),
    ("Delete Workspace", ["Delete Workspace", "Supprimer l'espace de travail", "Delete Workspace", "Delete Workspace", "删除工作区"]),
    ("DesignCraft", ["DesignCraft", "DesignCraft", "DesignCraft", "DesignCraft", "DesignCraft"]),
    ("Display Performance", ["Display Performance", "Performances d'affichage", "Display Performance", "Display Performance", "显示性能"]),
    ("Document Grid", ["Document Grid", "Grille du document", "Document Grid", "Document Grid", "文档网格"]),
    (
        "Document Recovery Data",
        ["Document Recovery Data", "Données de récupération du document", "Document Recovery Data", "Document Recovery Data", "文档恢复数据"],
    ),
    ("EPUB and HTML", ["EPUB and HTML", "EPUB et HTML", "EPUB and HTML", "EPUB and HTML", "EPUB 和 HTML"]),
    ("Export", ["Export", "Exporter", "Export", "Export", "导出"]),
    (
        "Export EPUB (Fixed Layout",
        [
            "Export EPUB (Fixed Layout",
            "Exporter en EPUB (mise en page fixe",
            "Export EPUB (Fixed Layout",
            "Export EPUB (Fixed Layout",
            "导出 EPUB (固定版面",
        ],
    ),
    (
        "Export EPUB (Reflowable",
        ["Export EPUB (Reflowable", "Exporter en EPUB (redistribuable", "Export EPUB (Reflowable", "Export EPUB (Reflowable", "导出 EPUB (可回流"],
    ),
    ("Facing Pages", ["Facing Pages", "Pages en vis-à-vis", "Facing Pages", "Facing Pages", "对页"]),
    ("GREP Styles", ["GREP Styles", "Styles GREP", "GREP Styles", "GREP Styles", "GREP 样式"]),
    (
        "Get help, share your layouts and shape what we build next.",
        [
            "Get help, share your layouts and shape what we build next.",
            "Obtenez de l'aide, partagez vos mises en page et influencez ce que nous construirons ensuite.",
            "Get help, share your layouts and shape what we build next.",
            "Get help, share your layouts and shape what we build next.",
            "获取帮助，分享您的布局，共同塑造我们的未来。",
        ],
    ),
    ("Highlight", ["Highlight", "Surlignage", "Highlight", "Highlight", "高亮显示"]),
    (
        "Hyperlinks & Cross-References",
        [
            "Hyperlinks & Cross-References",
            "Hyperliens et références croisées",
            "Hyperlinks & Cross-References",
            "Hyperlinks & Cross-References",
            "超链接和交叉引用",
        ],
    ),
    ("Hyphens and Dashes", ["Hyphens and Dashes", "Traits d'union et tirets", "Hyphens and Dashes", "Hyphens and Dashes", "连字符和破折号"]),
    ("Interactive", ["Interactive", "Interactif", "Interactive", "Interactive", "交互式"]),
    ("Invert", ["Invert", "Inverser", "Invert", "Invert", "反相"]),
    (
        "Join the ArtCraft community",
        [
            "Join the ArtCraft community",
            "Rejoindre la communauté ArtCraft",
            "Join the ArtCraft community",
            "Join the ArtCraft community",
            "加入 ArtCraft 社区",
        ],
    ),
    ("Keyboard Increments", ["Keyboard Increments", "Incréments au clavier", "Keyboard Increments", "Keyboard Increments", "键盘增量"]),
    ("Liquid guides", ["Liquid guides", "Repères liquides", "Liquid guides", "Liquid guides", "自适应参考线"]),
    ("Markers", ["Markers", "Marqueurs", "Markers", "Markers", "标记"]),
    ("More ArtCraft apps", ["More ArtCraft apps", "Autres applications ArtCraft", "More ArtCraft apps", "More ArtCraft apps", "更多 ArtCraft 应用"]),
    ("Nested Line Styles", ["Nested Line Styles", "Styles de ligne imbriqués", "Nested Line Styles", "Nested Line Styles", "嵌套行样式"]),
    ("Nested Styles", ["Nested Styles", "Styles imbriqués", "Nested Styles", "Nested Styles", "嵌套样式"]),
    (
        "No articles: exports follow page order.",
        [
            "No articles: exports follow page order.",
            "Aucun article : les exports suivent l'ordre des pages.",
            "No articles: exports follow page order.",
            "No articles: exports follow page order.",
            "没有文章：导出遵循页面顺序。",
        ],
    ),
    ("No book open.", ["No book open.", "Aucun livre ouvert.", "No book open.", "No book open.", "没有打开的书籍。"]),
    (
        "No bookmarks. They become the PDF outline.",
        [
            "No bookmarks. They become the PDF outline.",
            "Aucun signet. Ils forment le plan du PDF.",
            "No bookmarks. They become the PDF outline.",
            "No bookmarks. They become the PDF outline.",
            "没有书签。它们将成为 PDF 大纲。",
        ],
    ),
    ("No changes.", ["No changes.", "Aucune modification.", "No changes.", "No changes.", "没有更改。"]),
    (
        "No conditions. Create one, then select text and click it to apply.",
        [
            "No conditions. Create one, then select text and click it to apply.",
            "Aucune condition. Créez-en une, puis sélectionnez du texte et cliquez dessus pour l'appliquer.",
            "No conditions. Create one, then select text and click it to apply.",
            "No conditions. Create one, then select text and click it to apply.",
            "没有条件。创建一个条件，然后选择文本并单击以应用。",
        ],
    ),
    ("No document open", ["No document open", "Aucun document ouvert", "No document open", "No document open", "未打开任何文档"]),
    ("No document.", ["No document.", "Aucun document.", "No document.", "No document.", "没有文档。"]),
    (
        "No hyperlinks. Select text or a frame, type a URL and click New.",
        [
            "No hyperlinks. Select text or a frame, type a URL and click New.",
            "Aucun hyperlien. Sélectionnez du texte ou un bloc, saisissez une URL et cliquez sur Nouveau.",
            "No hyperlinks. Select text or a frame, type a URL and click New.",
            "No hyperlinks. Select text or a frame, type a URL and click New.",
            "没有超链接。选择文本或框架，键入 URL，然后单击新建。",
        ],
    ),
    ("No library open.", ["No library open.", "Aucune bibliothèque ouverte.", "No library open.", "No library open.", "没有打开的库。"]),
    (
        "No notes in this document.",
        [
            "No notes in this document.",
            "Aucune note dans ce document.",
            "No notes in this document.",
            "No notes in this document.",
            "本文档中没有注释。",
        ],
    ),
    ("No placed graphics.", ["No placed graphics.", "Aucun graphique importé.", "No placed graphics.", "No placed graphics.", "没有置入的图形。"]),
    (
        "No scripts. Add one below.",
        [
            "No scripts. Add one below.",
            "Aucun script. Ajoutez-en un ci-dessous.",
            "No scripts. Add one below.",
            "No scripts. Add one below.",
            "没有脚本。在下方添加一个。",
        ],
    ),
    (
        "No text anchors in this document.",
        [
            "No text anchors in this document.",
            "Aucune ancre de texte dans ce document.",
            "No text anchors in this document.",
            "No text anchors in this document.",
            "本文档中没有文本锚点。",
        ],
    ),
    (
        "OK changes all: text and paragraph/character styles.",
        [
            "OK changes all: text and paragraph/character styles.",
            "OK modifie tout : texte et styles de paragraphe/caractère.",
            "OK changes all: text and paragraph/character styles.",
            "OK changes all: text and paragraph/character styles.",
            "确定将更改所有：文本和段落/字符样式。",
        ],
    ),
    ("OVERSET", ["OVERSET", "EN EXCÈS", "OVERSET", "OVERSET", "溢流"]),
    (
        "Open source. No telemetry.",
        [
            "Open source. No telemetry.",
            "Open source. Aucune télémétrie.",
            "Open source. No telemetry.",
            "Open source. No telemetry.",
            "开源。无遥测。",
        ],
    ),
    ("Options", ["Options", "Options", "Options", "Options", "选项"]),
    (
        "Options for Black on RGB and Grayscale Devices",
        [
            "Options for Black on RGB and Grayscale Devices",
            "Options du noir sur les périphériques RVB et en niveaux de gris",
            "Options for Black on RGB and Grayscale Devices",
            "Options for Black on RGB and Grayscale Devices",
            "RGB 和灰度设备上的黑色选项",
        ],
    ),
    ("Other", ["Other", "Autre", "Other", "Other", "其他"]),
    ("Output", ["Output", "Sortie", "Output", "Output", "输出"]),
    ("Page Numbering", ["Page Numbering", "Numérotation des pages", "Page Numbering", "Page Numbering", "页码编排"]),
    (
        "Page layout for print and screen — fast, open and scriptable.",
        [
            "Page layout for print and screen — fast, open and scriptable.",
            "Mise en page pour l'impression et l'écran : rapide, ouverte, scriptable.",
            "Page layout for print and screen — fast, open and scriptable.",
            "Page layout for print and screen — fast, open and scriptable.",
            "用于打印和屏幕的页面布局——快速、开放且可编写脚本。",
        ],
    ),
    ("Page · PPI", ["Page · PPI", "Page · PPP", "Page · PPI", "Page · PPI", "页面 · PPI"]),
    (
        "Part of the ArtCraft suite of open creative tools.",
        [
            "Part of the ArtCraft suite of open creative tools.",
            "Fait partie de la suite ArtCraft d'outils créatifs ouverts.",
            "Part of the ArtCraft suite of open creative tools.",
            "Part of the ArtCraft suite of open creative tools.",
            "ArtCraft 开源创意工具套件的一部分。",
        ],
    ),
    ("Pasteboard Options", ["Pasteboard Options", "Options de la table de montage", "Pasteboard Options", "Pasteboard Options", "粘贴板选项"]),
    ("Paths", ["Paths", "Tracés", "Paths", "Paths", "路径"]),
    (
        "Place the insertion point in a table, or create one.",
        [
            "Place the insertion point in a table, or create one.",
            "Placez le point d'insertion dans un tableau ou créez-en un.",
            "Place the insertion point in a table, or create one.",
            "Place the insertion point in a table, or create one.",
            "将插入点置于表格中，或创建一个表格。",
        ],
    ),
    (
        "Plays in EPUB export; print and PDF show the poster.",
        [
            "Plays in EPUB export; print and PDF show the poster.",
            "Lu dans l'export EPUB ; l'impression et le PDF montrent l'affiche.",
            "Plays in EPUB export; print and PDF show the poster.",
            "Plays in EPUB export; print and PDF show the poster.",
            "在 EPUB 导出中播放；打印和 PDF 显示海报。",
        ],
    ),
    ("Quotation Marks", ["Quotation Marks", "Guillemets", "Quotation Marks", "Quotation Marks", "引号"]),
    ("Recently Used", ["Recently Used", "Récemment utilisés", "Recently Used", "Recently Used", "最近使用"]),
    ("Replace With", ["Replace With", "Remplacer par", "Replace With", "Replace With", "替换为"]),
    (
        "Right-click: stroke, groups",
        [
            "Right-click: stroke, groups",
            "Clic droit : contour, groupes",
            "Right-click: stroke, groups",
            "Right-click: stroke, groups",
            "右键单击：描边、组",
        ],
    ),
    ("Ruler Units", ["Ruler Units", "Unités des règles", "Ruler Units", "Ruler Units", "标尺单位"]),
    ("Origin:", ["Ursprung:", "Origine :", "Origen:", "原点:", "原点:"]),
    ("Spine", ["Bund", "Dos", "Lomo", "ノド", "书脊"]),
    ("Lock Zero Point", ["Nullpunkt fixieren", "Verrouiller le point zéro", "Bloquear punto cero", "ゼロ点をロック", "锁定零点"]),
    ("Unlock Zero Point", ["Nullpunkt lösen", "Déverrouiller le point zéro", "Desbloquear punto cero", "ゼロ点のロックを解除", "解锁零点"]),
    (
        "Saves which bars show and where the panels are.",
        [
            "Saves which bars show and where the panels are.",
            "Enregistre les barres affichées et l'emplacement des panneaux.",
            "Saves which bars show and where the panels are.",
            "Saves which bars show and where the panels are.",
            "保存显示哪些栏以及面板所在的位置。",
        ],
    ),
    (
        "Select a placed video or sound (File › Place a .mp4, .mov, .mp3, .wav …).",
        [
            "Select a placed video or sound (File › Place a .mp4, .mov, .mp3, .wav …).",
            "Sélectionnez une vidéo ou un son importé (Fichier › Importer un .mp4, .mov, .mp3, .wav …).",
            "Select a placed video or sound (File › Place a .mp4, .mov, .mp3, .wav …).",
            "Select a placed video or sound (File › Place a .mp4, .mov, .mp3, .wav …).",
            "选择已置入的视频或声音 (文件 › 置入 .mp4, .mov, .mp3, .wav …)。",
        ],
    ),
    (
        "Select an object or text to color its fill or stroke.",
        [
            "Select an object or text to color its fill or stroke.",
            "Select an object or text to color its fill or stroke.",
            "Select an object or text to color its fill or stroke.",
            "Select an object or text to color its fill or stroke.",
            "选择一个对象或文本以设置其填色或描边颜色。",
        ],
    ),
    (
        "Select an object to give its fill a gradient.",
        [
            "Select an object to give its fill a gradient.",
            "Sélectionnez un objet pour appliquer un dégradé à son fond.",
            "Select an object to give its fill a gradient.",
            "Select an object to give its fill a gradient.",
            "选择一个对象以为其填色应用渐变。",
        ],
    ),
    (
        "Select an object to make it a button.",
        [
            "Select an object to make it a button.",
            "Sélectionnez un objet pour en faire un bouton.",
            "Select an object to make it a button.",
            "Select an object to make it a button.",
            "选择一个对象使其成为按钮。",
        ],
    ),
    (
        "Select two or more objects (or a group) to make a multi-state object.",
        [
            "Select two or more objects (or a group) to make a multi-state object.",
            "Sélectionnez au moins deux objets (ou un groupe) pour créer un objet à états multiples.",
            "Select two or more objects (or a group) to make a multi-state object.",
            "Select two or more objects (or a group) to make a multi-state object.",
            "选择两个或多个对象 (或一个组) 以制作多状态对象。",
        ],
    ),
    ("Show", ["Show", "Afficher", "Show", "Show", "显示"]),
    ("Smart Text Reflow", ["Smart Text Reflow", "Redistribution intelligente du texte", "Smart Text Reflow", "Smart Text Reflow", "智能文本重排"]),
    ("Spelling", ["Spelling", "Orthographe", "Spelling", "Spelling", "拼写"]),
    ("Start a new document", ["Start a new document", "Créer un nouveau document", "Start a new document", "Start a new document", "开始新文档"]),
    ("Status", ["Status", "État", "Status", "Status", "状态"]),
    ("Style Mapping", ["Style Mapping", "Association de styles", "Style Mapping", "Style Mapping", "样式映射"]),
    ("Style Name Conflicts", ["Style Name Conflicts", "Conflits de noms de style", "Style Name Conflicts", "Style Name Conflicts", "样式名称冲突"]),
    ("Symbols", ["Symbols", "Symboles", "Symbols", "Symbols", "符号"]),
    ("System default", ["System default", "Valeur par défaut du système", "System default", "System default", "系统默认"]),
    ("Table Dimensions", ["Table Dimensions", "Dimensions du tableau", "Table Dimensions", "Table Dimensions", "表格尺寸"]),
    (
        "Text Display Options",
        ["Text Display Options", "Options d'affichage du texte", "Text Display Options", "Text Display Options", "文本显示选项"],
    ),
    (
        "The fill isn't a gradient.",
        ["The fill isn't a gradient.", "Le fond n'est pas un dégradé.", "The fill isn't a gradient.", "The fill isn't a gradient.", "填色不是渐变。"],
    ),
    (
        "The library is empty. Select objects and Add Selection.",
        [
            "The library is empty. Select objects and Add Selection.",
            "La bibliothèque est vide. Sélectionnez des objets et utilisez Ajouter la sélection.",
            "The library is empty. Select objects and Add Selection.",
            "The library is empty. Select objects and Add Selection.",
            "库为空。选择对象并添加所选内容。",
        ],
    ),
    (
        "Transitions play in interactive PDF (full-screen mode).",
        [
            "Transitions play in interactive PDF (full-screen mode).",
            "Les transitions sont lues dans le PDF interactif (mode plein écran).",
            "Transitions play in interactive PDF (full-screen mode).",
            "Transitions play in interactive PDF (full-screen mode).",
            "在交互式 PDF (全屏模式) 中播放过渡。",
        ],
    ),
    ("Type & Tables", ["Type & Tables", "Texte et tableaux", "Type & Tables", "Type & Tables", "文字和表格"]),
    ("Type Options", ["Type Options", "Options de texte", "Type Options", "Type Options", "文字选项"]),
    (
        "Type a word with ~ at each allowed break (ex~am~ple); without ~ the word is never hyphenated.",
        [
            "Type a word with ~ at each allowed break (ex~am~ple); without ~ the word is never hyphenated.",
            "Saisissez un mot avec ~ à chaque coupure autorisée (ex~em~ple) ; sans ~, le mot n'est jamais coupé.",
            "Type a word with ~ at each allowed break (ex~am~ple); without ~ the word is never hyphenated.",
            "Type a word with ~ at each allowed break (ex~am~ple); without ~ the word is never hyphenated.",
            "在每个允许的断字处用 ~ 键入一个单词 (例如 ex~am~ple)；如果没有 ~，该单词将永远不会断字。",
        ],
    ),
    (
        "User Dictionary (this document)",
        [
            "User Dictionary (this document)",
            "Dictionnaire utilisateur (ce document)",
            "User Dictionary (this document)",
            "User Dictionary (this document)",
            "用户词典 (本文档)",
        ],
    ),
    ("Utilities", ["Utilities", "Utilitaires", "Utilities", "Utilities", "实用程序"]),
    ("Variable Font", ["Variable Font", "Police variable", "Variable Font", "Variable Font", "可变字体"]),
    (
        "Welcome to DesignCraft",
        ["Welcome to DesignCraft", "Bienvenue dans DesignCraft", "Welcome to DesignCraft", "Welcome to DesignCraft", "欢迎使用 DesignCraft"],
    ),
    ("When Scaling", ["When Scaling", "Lors du redimensionnement", "When Scaling", "When Scaling", "缩放时"]),
    ("[Basic] (working) ▾", ["[Basic] (working) ▾", "[De base] (de travail) ▾", "[Basic] (working) ▾", "[Basic] (working) ▾", "[基本] (工作区) ▾"]),
    ("[Black] Overprint", ["[Black] Overprint", "Surimpression de [Noir]", "[Black] Overprint", "[Black] Overprint", "[黑] 叠印"]),
    ("[No Group]", ["[No Group]", "[Aucun groupe]", "[No Group]", "[No Group]", "[无组]"]),
    ("[None]", ["[None]", "[Aucun]", "[None]", "[None]", "[无]"]),
    (
        "[None] — choose a colour on the ramp.",
        [
            "[None] — choose a colour on the ramp.",
            "[Aucun] : choisissez une couleur sur le spectre.",
            "[None] — choose a colour on the ramp.",
            "[None] — choose a colour on the ramp.",
            "[无] — 在色带上选择一种颜色。",
        ],
    ),
    (
        "discord.gg/artcraft — help, feedback and show-and-tell",
        [
            "discord.gg/artcraft — help, feedback and show-and-tell",
            "discord.gg/artcraft : aide, retours et présentation de vos créations",
            "discord.gg/artcraft — help, feedback and show-and-tell",
            "discord.gg/artcraft — help, feedback and show-and-tell",
            "discord.gg/artcraft — 帮助、反馈和展示",
        ],
    ),
    (
        "⌥-click clears overrides",
        ["⌥-click clears overrides", "⌥-clic efface les remplacements", "⌥-click clears overrides", "⌥-click clears overrides", "⌥-单击清除覆盖"],
    ),
    (
        "Alt-click clears overrides",
        [
            "Alt-Klick entfernt Abweichungen",
            "Alt-clic efface les remplacements",
            "Alt-clic borra las modificaciones",
            "Alt を押しながらクリックするとオーバーライドを消去します",
            "Alt-单击清除覆盖",
        ],
    ),
    (
        "Apply \"{name}\", Clear Overrides",
        [
            "„{name}“ anwenden, Abweichungen löschen",
            "Appliquer « {name} », effacer les remplacements",
            "Aplicar \"{name}\", borrar modificaciones",
            "\"{name}\" を適用、オーバーライドを消去",
            "应用\"{name}\"，清除覆盖",
        ],
    ),
    ("⚠ out of date", ["⚠ out of date", "⚠ obsolète", "⚠ out of date", "⚠ out of date", "⚠ 已过期"]),
    ("General", ["General", "Général", "General", "General", "常规"]),
    (
        "Basic Character Formats",
        ["Basic Character Formats", "Formats de caractère de base", "Basic Character Formats", "Basic Character Formats", "基本字符格式"],
    ),
    ("Indents and Spacing", ["Indents and Spacing", "Retraits et espacement", "Indents and Spacing", "Indents and Spacing", "缩进和间距"]),
    ("Hyphenation", ["Hyphenation", "Césure", "Hyphenation", "Hyphenation", "断字"]),
    ("Justification", ["Blocksatzeinstellungen", "Justification", "Justificación", "両端揃え", "两端对齐"]),
    (
        "Drop Caps and Nested Styles",
        [
            "Drop Caps and Nested Styles",
            "Lettrines et styles imbriqués",
            "Drop Caps and Nested Styles",
            "Drop Caps and Nested Styles",
            "首字下沉和嵌套样式",
        ],
    ),
    ("GREP Style", ["GREP Style", "Style GREP", "GREP Style", "GREP Style", "GREP 样式"]),
    ("Character Color", ["Character Color", "Couleur du caractère", "Character Color", "Character Color", "字符颜色"]),
    (
        "Numbering and Formatting",
        ["Numbering and Formatting", "Numérotation et mise en forme", "Numbering and Formatting", "Numbering and Formatting", "编号和格式"],
    ),
    ("Spacing Options", ["Spacing Options", "Options d'espacement", "Spacing Options", "Spacing Options", "间距选项"]),
    ("First Baseline", ["First Baseline", "Première ligne de base", "First Baseline", "First Baseline", "首行基线"]),
    ("Rule Above", ["Rule Above", "Filet au-dessus", "Rule Above", "Rule Above", "上方横线"]),
    ("Numbering", ["Numbering", "Numérotation", "Numbering", "Numbering", "编号"]),
    (
        "Footnote Reference Number in Text",
        [
            "Footnote Reference Number in Text",
            "Numéro de référence de note de bas de page dans le texte",
            "Footnote Reference Number in Text",
            "Footnote Reference Number in Text",
            "正文中的脚注引用编号",
        ],
    ),
    (
        "Footnote Formatting",
        ["Footnote Formatting", "Mise en forme des notes de bas de page", "Footnote Formatting", "Footnote Formatting", "脚注格式"],
    ),
    (
        "Span Footnotes Across Columns",
        [
            "Span Footnotes Across Columns",
            "Étendre les notes de bas de page sur toutes les colonnes",
            "Span Footnotes Across Columns",
            "Span Footnotes Across Columns",
            "跨栏分布脚注",
        ],
    ),
    ("Rule On", ["Rule On", "Filet activé", "Rule On", "Rule On", "启用横线"]),
    ("Ascent", ["Ascent", "Ascendante", "Ascent", "Ascent", "上升高度"]),
    ("Cap Height", ["Cap Height", "Hauteur de capitale", "Cap Height", "Cap Height", "大写字母高度"]),
    ("Leading", ["Leading", "Interligne", "Leading", "Leading", "行距"]),
    ("x Height", ["x Height", "Hauteur d'x", "x Height", "x Height", "x 字高"]),
    ("Em Box Height", ["Em Box Height", "Em Box Height", "Em Box Height", "Em Box Height", "全角字框高度"]),
    ("Fixed", ["Fixed", "Fixe", "Fixed", "Fixed", "固定"]),
    ("Never (continuous)", ["Never (continuous)", "Jamais (continu)", "Never (continuous)", "Never (continuous)", "从不（连续编号）"]),
    ("Page", ["Page", "Page", "Page", "Page", "页面"]),
    ("Spread", ["Spread", "Planche", "Spread", "Spread", "跨页"]),
    ("Section", ["Section", "Section", "Section", "Section", "章节"]),
    ("Footnote Reference", ["Footnote Reference", "Référence de note de bas de page", "Footnote Reference", "Footnote Reference", "脚注引用"]),
    ("Footnote Text", ["Footnote Text", "Texte de la note de bas de page", "Footnote Text", "Footnote Text", "脚注文本"]),
    ("Both", ["Both", "Les deux", "Both", "Both", "两者"]),
    ("Apply Superscript", ["Apply Superscript", "Appliquer l'exposant", "Apply Superscript", "Apply Superscript", "应用上标"]),
    ("Apply Subscript", ["Apply Subscript", "Appliquer l'indice", "Apply Subscript", "Apply Subscript", "应用下标"]),
    ("Apply Normal", ["Apply Normal", "Appliquer Normal", "Apply Normal", "Apply Normal", "应用正常位置"]),
    ("OpenType Superscript", ["OpenType Superscript", "Exposant OpenType", "OpenType Superscript", "OpenType Superscript", "OpenType 上标"]),
    ("through", ["through", "sur", "through", "through", "直到（包含）"]),
    ("up to", ["up to", "jusqu'à", "up to", "up to", "直到（不包含）"]),
    ("line", ["line", "ligne", "line", "line", "行"]),
    ("lines", ["lines", "lignes", "lines", "lines", "行"]),
    ("sentences", ["sentences", "phrases", "sentences", "sentences", "句子"]),
    ("words", ["words", "mots", "words", "words", "单词"]),
    ("characters", ["characters", "caractères", "characters", "characters", "字符"]),
    ("letters", ["letters", "lettres", "letters", "letters", "字母"]),
    ("digits", ["digits", "chiffres", "digits", "digits", "数字"]),
    ("tab", ["tab", "tabulation", "tab", "tab", "制表符"]),
    ("forcedLineBreak", ["forcedLineBreak", "saut de ligne forcé", "forcedLineBreak", "forcedLineBreak", "强制换行符"]),
    ("emSpace", ["emSpace", "espace cadratin", "emSpace", "emSpace", "全角空格"]),
    ("enSpace", ["enSpace", "espace demi-cadratin", "enSpace", "enSpace", "半角空格"]),
    ("dropcap", ["Initiale", "lettrine", "capitular", "ドロップキャップ", "首字下沉"]),
    ("Drop Caps", ["Initialen", "Lettrines", "Capitulares", "ドロップキャップ", "首字下沉"]),
    ("Lines:", ["Zeilen:", "Lignes :", "Líneas:", "行数：", "行数："]),
    ("Characters:", ["Zeichen:", "Caractères :", "Caracteres:", "文字数：", "字符数："]),
    ("Drop Lines", ["Initialzeilen", "Lignes lettrine", "Líneas capitular", "ドロップ行数", "下沉行数"]),
    ("Drop Chars", ["Initialzeichen", "Car. lettrine", "Car. capitular", "ドロップ文字数", "下沉字符数"]),
    ("Align Left Edge", ["Linke Kante ausrichten", "Aligner le bord gauche", "Alinear borde izquierdo", "左端揃え", "左边缘对齐"]),
    (
        "Scale for Descenders",
        [
            "Für Unterlängen skalieren",
            "Mise à l'échelle pour les jambages",
            "Escalar para trazos descendentes",
            "ディセンダーに合わせて拡大・縮小",
            "为下伸部分缩放",
        ],
    ),
    ("chars", ["chars", "caractères saisis", "chars", "chars", "指定字符"]),
    ("[Automatic]", ["[Automatic]", "[Automatique]", "[Automatic]", "[Automatic]", "[自动]"]),
    ("Tracking:", ["Tracking:", "Approche :", "Tracking:", "Tracking:", "字距调整："]),
    ("Right Indent:", ["Right Indent:", "Retrait à droite :", "Right Indent:", "Right Indent:", "右缩进："]),
    ("First Line Indent:", ["First Line Indent:", "Retrait de première ligne :", "First Line Indent:", "First Line Indent:", "首行缩进："]),
    ("Space Before:", ["Space Before:", "Espace avant :", "Space Before:", "Space Before:", "段前间距："]),
    ("Space After:", ["Space After:", "Espace après :", "Space After:", "Space After:", "段后间距："]),
    ("Words with at Least:", ["Words with at Least:", "Mots d'au moins :", "Words with at Least:", "Words with at Least:", "单词最少字符数："]),
    ("After First:", ["After First:", "Après les premières :", "After First:", "After First:", "连字符前最少字符数："]),
    ("Before Last:", ["Before Last:", "Avant les dernières :", "Before Last:", "Before Last:", "连字符后最少字符数："]),
    ("Hyphen Limit:", ["Hyphen Limit:", "Limite de césure :", "Hyphen Limit:", "Hyphen Limit:", "连字符限制："]),
    ("Word Spacing:", ["Word Spacing:", "Espacement des mots :", "Word Spacing:", "Word Spacing:", "单词间距："]),
    ("Letter Spacing:", ["Letter Spacing:", "Espacement des lettres :", "Letter Spacing:", "Letter Spacing:", "字母间距："]),
    ("Glyph Scaling:", ["Glyph Scaling:", "Échelle des glyphes :", "Glyph Scaling:", "Glyph Scaling:", "字形缩放比例："]),
    ("Insert Kashidas:", ["Insert Kashidas:", "Insérer des kashidas :", "Insert Kashidas:", "Insert Kashidas:", "插入延长线："]),
    (
        "In justified Arabic text",
        [
            "In justified Arabic text",
            "Dans le texte arabe justifié",
            "In justified Arabic text",
            "In justified Arabic text",
            "在两端对齐的阿拉伯语文本中",
        ],
    ),
    ("Korean Line Breaks:", ["Korean Line Breaks:", "Retours à la ligne en coréen :", "Korean Line Breaks:", "Korean Line Breaks:", "韩文换行："]),
    (
        "Between syllables (not only at spaces)",
        [
            "Between syllables (not only at spaces)",
            "Entre les syllabes (pas seulement aux espaces)",
            "Between syllables (not only at spaces)",
            "Between syllables (not only at spaces)",
            "在音节之间（不仅在空格处）",
        ],
    ),
    ("Binding:", ["Binding:", "Reliure :", "Binding:", "Binding:", "装订方向："]),
    ("Ruby:", ["Ruby:", "Ruby :", "Ruby:", "Ruby:", "旁注："]),
    (
        "Set over the selected text; empty removes it.",
        [
            "Set over the selected text; empty removes it.",
            "Composé au-dessus du texte sélectionné ; vide, il est supprimé.",
            "Set over the selected text; empty removes it.",
            "Set over the selected text; empty removes it.",
            "在所选文本上方添加注音；留空可移除。",
        ],
    ),
    ("[Basic Paragraph]", ["[Basic Paragraph]", "[Paragraphe standard]", "[Basic Paragraph]", "[Basic Paragraph]", "[基本段落]"]),
    ("[No Paragraph Style]", ["[No Paragraph Style]", "[Aucun style de paragraphe]", "[No Paragraph Style]", "[No Paragraph Style]", "[无段落样式]"]),
    ("Align left", ["Align left", "Aligner à gauche", "Align left", "Align left", "左对齐"]),
    ("Align center", ["Align center", "Aligner au centre", "Align center", "Align center", "居中对齐"]),
    ("Align right", ["Align right", "Aligner à droite", "Align right", "Align right", "右对齐"]),
    (
        "Justify with last line aligned left",
        [
            "Justify with last line aligned left",
            "Justifier avec dernière ligne alignée à gauche",
            "Justify with last line aligned left",
            "Justify with last line aligned left",
            "两端对齐，末行左对齐",
        ],
    ),
    (
        "Justify with last line aligned center",
        [
            "Justify with last line aligned center",
            "Justifier avec dernière ligne centrée",
            "Justify with last line aligned center",
            "Justify with last line aligned center",
            "两端对齐，末行居中",
        ],
    ),
    (
        "Justify with last line aligned right",
        [
            "Justify with last line aligned right",
            "Justifier avec dernière ligne alignée à droite",
            "Justify with last line aligned right",
            "Justify with last line aligned right",
            "两端对齐，末行右对齐",
        ],
    ),
    ("Justify all lines", ["Justify all lines", "Justifier toutes les lignes", "Justify all lines", "Justify all lines", "所有行两端对齐"]),
    ("Align towards spine", ["Align towards spine", "Aligner vers le dos", "Align towards spine", "Align towards spine", "朝向书脊对齐"]),
    (
        "Align away from spine",
        ["Align away from spine", "Aligner à l'opposé du dos", "Align away from spine", "Align away from spine", "背向书脊对齐"],
    ),
    (
        "Create New Style from Selection",
        [
            "Create New Style from Selection",
            "Créer un style à partir de la sélection",
            "Create New Style from Selection",
            "Create New Style from Selection",
            "从所选内容创建新样式",
        ],
    ),
    ("No text selected", ["No text selected", "Aucun texte sélectionné", "No text selected", "No text selected", "未选择文本"]),
    ("Search", ["Suchen", "Rechercher", "Buscar", "Search", "搜索"]),
    ("Essentials", ["Essentials", "Les indispensables", "Essentials", "Essentials", "基本功能"]),
    ("Advanced", ["Advanced", "Avancé", "Advanced", "Advanced", "高级"]),
    ("Digital Publishing", ["Digital Publishing", "Publication numérique", "Digital Publishing", "Digital Publishing", "数字出版"]),
    ("Interactive for PDF", ["Interactive for PDF", "PDF interactif", "Interactive for PDF", "Interactive for PDF", "PDF 交互"]),
    ("Printing and Proofing", ["Printing and Proofing", "Impression et épreuvage", "Printing and Proofing", "Printing and Proofing", "打印和校样"]),
    ("Typography", ["Typography", "Typographie", "Typography", "Typography", "文字排版"]),
    ("Rulers & Grids", ["Rulers & Grids", "Règles et grilles", "Rulers & Grids", "Rulers & Grids", "标尺和网格"]),
    ("No errors", ["No errors", "Aucune erreur", "No errors", "No errors", "无错误"]),
    ("error", ["error", "erreur", "error", "error", "个错误"]),
    ("errors", ["errors", "erreurs", "errors", "errors", "个错误"]),
    ("Reset", ["Reset", "Réinitialiser", "Reset", "Reset", "重置"]),
    ("Right to Left", ["Right to Left", "De droite à gauche", "Right to Left", "Right to Left", "从右向左"]),
    ("Left to Right", ["Left to Right", "De gauche à droite", "Left to Right", "Left to Right", "从左向右"]),
    ("Portrait", ["Portrait", "Portrait", "Portrait", "Portrait", "纵向"]),
    ("Landscape", ["Landscape", "Paysage", "Landscape", "Landscape", "横向"]),
    (
        "Display All Blacks as Rich Black",
        [
            "Display All Blacks as Rich Black",
            "Afficher tous les noirs en noir intense",
            "Display All Blacks as Rich Black",
            "Display All Blacks as Rich Black",
            "所有黑色显示为浓黑",
        ],
    ),
    (
        "Display All Blacks Accurately",
        [
            "Display All Blacks Accurately",
            "Afficher tous les noirs avec précision",
            "Display All Blacks Accurately",
            "Display All Blacks Accurately",
            "准确显示所有黑色",
        ],
    ),
    (
        "Output All Blacks as Rich Black",
        [
            "Output All Blacks as Rich Black",
            "Sortir tous les noirs en noir intense",
            "Output All Blacks as Rich Black",
            "Output All Blacks as Rich Black",
            "所有黑色输出为浓黑",
        ],
    ),
    (
        "Output All Blacks Accurately",
        [
            "Output All Blacks Accurately",
            "Sortir tous les noirs avec précision",
            "Output All Blacks Accurately",
            "Output All Blacks Accurately",
            "准确输出所有黑色",
        ],
    ),
    ("Top Margin", ["Top Margin", "Marge supérieure", "Top Margin", "Top Margin", "上边距"]),
    ("Top of Page", ["Top of Page", "Haut de la page", "Top of Page", "Top of Page", "页面顶部"]),
    (
        "Paragraph Styles panel",
        ["Paragraph Styles panel", "Panneau Styles de paragraphe", "Paragraph Styles panel", "Paragraph Styles panel", "段落样式面板"],
    ),
    (
        "Character Styles panel",
        ["Character Styles panel", "Panneau Styles de caractère", "Character Styles panel", "Character Styles panel", "字符样式面板"],
    ),
    ("Create new style", ["Create new style", "Créer un style", "Create new style", "Create new style", "创建新样式"]),
    ("Clear overrides", ["Clear overrides", "Effacer les remplacements", "Clear overrides", "Clear overrides", "清除覆盖"]),
    ("Apply", ["Apply", "Appliquer", "Apply", "Apply", "应用"]),
    ("Accept", ["Accept", "Accepter", "Accept", "Accept", "接受"]),
    ("Reject", ["Reject", "Refuser", "Reject", "Reject", "拒绝"]),
    ("Add Selection", ["Add Selection", "Ajouter la sélection", "Add Selection", "Add Selection", "添加所选内容"]),
    ("Align Stroke:", ["Align Stroke:", "Aligner le contour :", "Align Stroke:", "Align Stroke:", "描边对齐："]),
    ("Angle", ["Angle", "Angle", "Angle", "Angle", "角度"]),
    ("Angle:", ["Angle:", "Angle :", "Angle:", "Angle:", "角度："]),
    ("Baseline", ["Baseline", "Ligne de base", "Baseline", "Baseline", "基线"]),
    ("Cap:", ["Cap:", "Extrémité :", "Cap:", "Cap:", "端点："]),
    ("Cell Text", ["Cell Text", "Texte de la cellule", "Cell Text", "Cell Text", "单元格文本"]),
    ("Cell Type", ["Cell Type", "Type de cellule", "Cell Type", "Cell Type", "单元格类型"]),
    ("Composer", ["Composer", "Compositeur", "Composer", "Composer", "排版器"]),
    ("Convert to Text", ["Convert to Text", "Convertir en texte", "Convert to Text", "Convert to Text", "转换为文本"]),
    ("Create New Layer", ["Create New Layer", "Créer un calque", "Create New Layer", "Create New Layer", "创建新图层"]),
    ("Delete DTD", ["Delete DTD", "Supprimer la DTD", "Delete DTD", "Delete DTD", "删除 DTD"]),
    ("Digits", ["Digits", "Chiffres", "Digits", "Digits", "数字"]),
    ("Direction", ["Direction", "Direction", "Direction", "Direction", "方向"]),
    ("Distance", ["Distance", "Distance", "Distance", "Distance", "距离"]),
    ("Distribute ↔", ["Distribute ↔", "Répartir ↔", "Distribute ↔", "Distribute ↔", "水平分布"]),
    ("Distribute ↕", ["Distribute ↕", "Répartir ↕", "Distribute ↕", "Distribute ↕", "垂直分布"]),
    ("Effects: Drop Shadow", ["Effects: Drop Shadow", "Effets : ombre portée", "Effects: Drop Shadow", "Effects: Drop Shadow", "效果：投影"]),
    ("Favorites", ["Favorites", "Favoris", "Favorites", "Favorites", "收藏"]),
    ("First Spread", ["First Spread", "Première planche", "First Spread", "First Spread", "第一个跨页"]),
    ("Gap Color:", ["Gap Color:", "Couleur de l'espace :", "Gap Color:", "Gap Color:", "间隙颜色："]),
    ("Graphic…", ["Graphic…", "Graphique…", "Graphic…", "Graphic…", "图形…"]),
    ("Home", ["Home", "Accueil", "Home", "Home", "主页"]),
    ("Join:", ["Join:", "Sommet :", "Join:", "Join:", "连接："]),
    ("Language", ["Language", "Langue", "Language", "Language", "语言"]),
    ("Last Spread", ["Last Spread", "Dernière planche", "Last Spread", "Last Spread", "最后一个跨页"]),
    ("Load DTD…", ["Load DTD…", "Charger la DTD…", "Load DTD…", "Load DTD…", "载入 DTD…"]),
    ("Location:", ["Location:", "Emplacement :", "Location:", "Location:", "位置："]),
    ("Lock Guides", ["Lock Guides", "Verrouiller les repères", "Lock Guides", "Lock Guides", "锁定参考线"]),
    ("Miter Limit:", ["Miter Limit:", "Limite de pointe :", "Miter Limit:", "Miter Limit:", "斜接限制："]),
    (
        "New Article from Selection",
        [
            "New Article from Selection",
            "Nouvel article à partir de la sélection",
            "New Article from Selection",
            "New Article from Selection",
            "从所选内容新建文章",
        ],
    ),
    ("New Note at Cursor", ["New Note at Cursor", "Nouvelle note au curseur", "New Note at Cursor", "New Note at Cursor", "在光标处新建附注"]),
    ("New Swatch", ["New Swatch", "Nouvelle nuance", "New Swatch", "New Swatch", "新建色板"]),
    ("New condition name", ["New condition name", "Nom de la nouvelle condition", "New condition name", "New condition name", "新条件名称"]),
    ("New group…", ["New group…", "Nouveau groupe…", "New group…", "New group…", "新建组…"]),
    ("New tag", ["New tag", "Nouvelle balise", "New tag", "New tag", "新建标签"]),
    ("Next Spread", ["Next Spread", "Planche suivante", "Next Spread", "Next Spread", "下一个跨页"]),
    ("Note text", ["Note text", "Texte de la note", "Note text", "Note text", "附注文本"]),
    ("Offset", ["Offset", "Décalage", "Offset", "Offset", "偏移"]),
    ("Offsets", ["Offsets", "Décalages", "Offsets", "Offsets", "偏移量"]),
    ("Paragraph alignment", ["Paragraph alignment", "Alignement du paragraphe", "Paragraph alignment", "Paragraph alignment", "段落对齐"]),
    ("Previous Spread", ["Previous Spread", "Planche précédente", "Previous Spread", "Previous Spread", "上一个跨页"]),
    ("Release to Objects", ["Release to Objects", "Libérer en objets", "Release to Objects", "Release to Objects", "释放为对象"]),
    ("Remove", ["Remove", "Retirer", "Remove", "Remove", "移除"]),
    (
        "Rotate 90° Counterclockwise",
        [
            "Rotate 90° Counterclockwise",
            "Rotation de 90° dans le sens antihoraire",
            "Rotate 90° Counterclockwise",
            "Rotate 90° Counterclockwise",
            "逆时针旋转 90°",
        ],
    ),
    ("Rotate 180°", ["180° drehen", "Rotation à 180°", "Girar 180°", "180°回転", "旋转 180°"]),
    ("Rotation Angle", ["Rotation Angle", "Angle de rotation", "Rotation Angle", "Rotation Angle", "旋转角度"]),
    ("Rows", ["Rows", "Lignes", "Rows", "Rows", "行数"]),
    ("Run", ["Run", "Exécuter", "Run", "Run", "运行"]),
    ("Scale X Percentage", ["Scale X Percentage", "Échelle X en pourcentage", "Scale X Percentage", "Scale X Percentage", "水平缩放百分比"]),
    ("Scale Y Percentage", ["Scale Y Percentage", "Échelle Y en pourcentage", "Scale Y Percentage", "Scale Y Percentage", "垂直缩放百分比"]),
    ("Search commands", ["Befehle suchen", "Rechercher des commandes", "Buscar comandos", "Search commands", "搜索命令"]),
    (
        "No matching commands",
        ["Keine passenden Befehle", "Aucune commande correspondante", "Ningún comando coincide", "一致するコマンドはありません", "没有匹配的命令"],
    ),
    ("Search fonts", ["Search fonts", "Rechercher des polices", "Search fonts", "Search fonts", "搜索字体"]),
    (
        "Search styles and commands…",
        [
            "Search styles and commands…",
            "Rechercher des styles et des commandes…",
            "Search styles and commands…",
            "Search styles and commands…",
            "搜索样式和命令…",
        ],
    ),
    (
        "Search: character or U+code",
        [
            "Search: character or U+code",
            "Rechercher : caractère ou code U+",
            "Search: character or U+code",
            "Search: character or U+code",
            "搜索字符或 U+ 编码",
        ],
    ),
    ("Share", ["Share", "Partager", "Share", "Share", "分享"]),
    ("Shear X Angle", ["Shear X Angle", "Angle de déformation X", "Shear X Angle", "Shear X Angle", "水平倾斜角度"]),
    ("Show Baseline Grid", ["Show Baseline Grid", "Afficher la grille de ligne de base", "Show Baseline Grid", "Show Baseline Grid", "显示基线网格"]),
    ("Show Document Grid", ["Show Document Grid", "Afficher la grille du document", "Show Document Grid", "Show Document Grid", "显示文档网格"]),
    ("Show Guides", ["Show Guides", "Afficher les repères", "Show Guides", "Show Guides", "显示参考线"]),
    ("Stop Color:", ["Stop Color:", "Couleur d'arrêt :", "Stop Color:", "Stop Color:", "停止点颜色："]),
    ("Style", ["Style", "Style", "Style", "Style", "样式"]),
    ("Styles panel", ["Styles panel", "Panneau Styles", "Styles panel", "Styles panel", "样式面板"]),
    ("Text", ["Text", "Texte", "Text", "Text", "文本"]),
    (
        "The structure is valid.",
        ["The structure is valid.", "La structure est valide.", "The structure is valid.", "The structure is valid.", "结构有效。"],
    ),
    ("Toggle double column", ["Toggle double column", "Basculer en double colonne", "Toggle double column", "Toggle double column", "切换双列布局"]),
    ("Tracking", ["Tracking", "Approche", "Tracking", "Tracking", "字距调整"]),
    ("Untag Selection", ["Untag Selection", "Retirer la balise de la sélection", "Untag Selection", "Untag Selection", "移除所选内容的标签"]),
    ("Validate", ["Validate", "Valider", "Validate", "Validate", "验证"]),
    ("Weight", ["Weight", "Épaisseur", "Weight", "Weight", "粗细"]),
    ("Subtract", ["Subtract", "Soustraire", "Subtract", "Subtract", "减去"]),
    ("Intersect", ["Intersect", "Intersection", "Intersect", "Intersect", "交集"]),
    ("Exclude Overlap", ["Exclude Overlap", "Exclure le chevauchement", "Exclude Overlap", "Exclude Overlap", "排除重叠"]),
    ("Minus Back", ["Minus Back", "Soustraire l'arrière", "Minus Back", "Minus Back", "减去后方对象"]),
    ("Align left edges", ["Align left edges", "Aligner les bords gauches", "Align left edges", "Align left edges", "左边缘对齐"]),
    (
        "Align horizontal centers",
        ["Align horizontal centers", "Aligner les centres horizontaux", "Align horizontal centers", "Align horizontal centers", "水平居中对齐"],
    ),
    ("Align right edges", ["Align right edges", "Aligner les bords droits", "Align right edges", "Align right edges", "右边缘对齐"]),
    ("Align top edges", ["Align top edges", "Aligner les bords supérieurs", "Align top edges", "Align top edges", "顶边缘对齐"]),
    (
        "Align vertical centers",
        ["Align vertical centers", "Aligner les centres verticaux", "Align vertical centers", "Align vertical centers", "垂直居中对齐"],
    ),
    ("Align bottom edges", ["Align bottom edges", "Aligner les bords inférieurs", "Align bottom edges", "Align bottom edges", "底边缘对齐"]),
    ("Align to Selection", ["Align to Selection", "Aligner sur la sélection", "Align to Selection", "Align to Selection", "对齐到所选对象"]),
    ("Align to Key Object", ["Align to Key Object", "Aligner sur l'objet clé", "Align to Key Object", "Align to Key Object", "对齐到关键对象"]),
    ("Align to Margins", ["Align to Margins", "Aligner sur les marges", "Align to Margins", "Align to Margins", "对齐到边距"]),
    ("Align to Page", ["Align to Page", "Aligner sur la page", "Align to Page", "Align to Page", "对齐到页面"]),
    ("Align to Spread", ["Align to Spread", "Aligner sur la planche", "Align to Spread", "Align to Spread", "对齐到跨页"]),
    ("No Text Wrap", ["No Text Wrap", "Sans habillage", "No Text Wrap", "No Text Wrap", "无文本绕排"]),
    (
        "Wrap Around Bounding Box",
        ["Wrap Around Bounding Box", "Habiller le cadre de sélection", "Wrap Around Bounding Box", "Wrap Around Bounding Box", "绕排定界框"],
    ),
    (
        "Wrap Around Object Shape",
        ["Wrap Around Object Shape", "Habiller la forme de l'objet", "Wrap Around Object Shape", "Wrap Around Object Shape", "绕排对象形状"],
    ),
    ("Jump Object", ["Jump Object", "Sauter l'objet", "Jump Object", "Jump Object", "跳过对象"]),
    ("Jump to Next Column", ["Jump to Next Column", "Sauter à la colonne suivante", "Jump to Next Column", "Jump to Next Column", "跳至下一栏"]),
    ("Bulleted List", ["Bulleted List", "Liste à puces", "Bulleted List", "Bulleted List", "项目符号列表"]),
    ("Numbered List", ["Numbered List", "Liste numérotée", "Numbered List", "Numbered List", "编号列表"]),
    ("UPPERCASE", ["UPPERCASE", "MAJUSCULES", "UPPERCASE", "UPPERCASE", "大写"]),
    ("Small Caps", ["Small Caps", "Petites capitales", "Small Caps", "Small Caps", "小型大写字母"]),
    ("Normal", ["Normal", "Normal", "Normal", "Normal", "正常"]),
    ("Butt", ["Butt", "Aboutée", "Butt", "Butt", "平头"]),
    ("Round", ["Round", "Arrondie", "Round", "Round", "圆形"]),
    ("Projecting", ["Projecting", "Projetée", "Projecting", "Projecting", "突出"]),
    ("Miter", ["Miter", "En pointe", "Miter", "Miter", "斜接"]),
    ("Bevel", ["Bevel", "Biseau", "Bevel", "Bevel", "斜角"]),
    ("Center", ["Center", "Centre", "Center", "Center", "居中"]),
    ("Start/End:", ["Start/End:", "Début/Fin :", "Start/End:", "Start/End:", "起点/终点："]),
    ("Left", ["Left", "Gauche", "Left", "Left", "左"]),
    ("Right", ["Right", "Droite", "Right", "Right", "右"]),
    ("First", ["First", "Premier", "First", "First", "首行"]),
    ("Last", ["Last", "Dernier", "Last", "Last", "末行"]),
    ("Before", ["Before", "Avant", "Before", "Before", "段前"]),
    ("After", ["After", "Après", "After", "After", "段后"]),
    ("Shading", ["Shading", "Tramage", "Shading", "Shading", "底纹"]),
    ("Border", ["Border", "Bordure", "Border", "Border", "边框"]),
    ("Overprint Fill", ["Overprint Fill", "Surimpression du fond", "Overprint Fill", "Overprint Fill", "叠印填色"]),
    ("Overprint Stroke", ["Overprint Stroke", "Surimpression du contour", "Overprint Stroke", "Overprint Stroke", "叠印描边"]),
    ("Overprint Gap", ["Overprint Gap", "Surimpression de l'espace", "Overprint Gap", "Overprint Gap", "叠印间隙"]),
    ("Nonprinting", ["Nonprinting", "Non imprimable", "Nonprinting", "Nonprinting", "非打印"]),
    ("At Least", ["At Least", "Au moins", "At Least", "At Least", "至少"]),
    ("Exactly", ["Exactly", "Exactement", "Exactly", "Exactly", "固定"]),
    ("Justify", ["Justify", "Justifier", "Justify", "Justify", "两端对齐"]),
    ("Underline Options", ["Underline Options", "Options de soulignement", "Underline Options", "Underline Options", "下划线选项"]),
    ("Strikethrough Options", ["Strikethrough Options", "Options de barré", "Strikethrough Options", "Strikethrough Options", "删除线选项"]),
    (
        "Character Style Options",
        ["Character Style Options", "Options de style de caractère", "Character Style Options", "Character Style Options", "字符样式选项"],
    ),
    (
        "Advanced Character Formats",
        ["Advanced Character Formats", "Formats de caractère avancés", "Advanced Character Formats", "Advanced Character Formats", "高级字符格式"],
    ),
    ("OpenType Features", ["OpenType Features", "Fonctions OpenType", "OpenType Features", "OpenType Features", "OpenType 功能"]),
    ("Style Settings:", ["Style Settings:", "Paramètres du style :", "Style Settings:", "Style Settings:", "样式设置："]),
    ("Kerning:", ["Kerning:", "Crénage :", "Kerning:", "Kerning:", "字偶间距："]),
    ("Case:", ["Case:", "Casse :", "Case:", "Case:", "大小写："]),
    (
        "OpenType All Small Caps",
        [
            "OpenType All Small Caps",
            "Tout en petites capitales OpenType",
            "OpenType All Small Caps",
            "OpenType All Small Caps",
            "OpenType 全部小型大写字母",
        ],
    ),
    ("Subscript", ["Subscript", "Indice", "Subscript", "Subscript", "下标"]),
    ("OpenType Subscript", ["OpenType Subscript", "Indice OpenType", "OpenType Subscript", "OpenType Subscript", "OpenType 下标"]),
    ("OpenType Numerator", ["OpenType Numerator", "Numérateur OpenType", "OpenType Numerator", "OpenType Numerator", "OpenType 分子"]),
    ("OpenType Denominator", ["OpenType Denominator", "Dénominateur OpenType", "OpenType Denominator", "OpenType Denominator", "OpenType 分母"]),
    ("Ligatures", ["Ligatures", "Ligatures", "Ligatures", "Ligatures", "连字"]),
    ("No Break", ["No Break", "Sans retour automatique", "No Break", "No Break", "不换行"]),
    ("Horizontal Scale:", ["Horizontal Scale:", "Échelle horizontale :", "Horizontal Scale:", "Horizontal Scale:", "水平缩放："]),
    ("Vertical Scale:", ["Vertical Scale:", "Échelle verticale :", "Vertical Scale:", "Vertical Scale:", "垂直缩放："]),
    ("Baseline Shift:", ["Baseline Shift:", "Décalage vertical :", "Baseline Shift:", "Baseline Shift:", "基线偏移："]),
    ("Skew:", ["Skew:", "Inclinaison :", "Skew:", "Skew:", "倾斜："]),
    ("Language:", ["Language:", "Langue :", "Language:", "Language:", "语言："]),
    ("Digits:", ["Ziffern:", "Chiffres :", "Dígitos:", "数字：", "数字："]),
    ("Figure Style:", ["Figure Style:", "Style de chiffres :", "Figure Style:", "Figure Style:", "数字样式："]),
    ("Underline On", ["Underline On", "Souligné activé", "Underline On", "Underline On", "启用下划线"]),
    ("Strikethrough On", ["Strikethrough On", "Barré activé", "Strikethrough On", "Strikethrough On", "启用删除线"]),
    ("Edit \"{name}\"…", ["„{name}“ bearbeiten…", "Modifier « {name} »…", "Editar \"{name}\"…", "\"{name}\" を編集…", "编辑\"{name}\"…"]),
    (
        "Discretionary Ligatures",
        ["Discretionary Ligatures", "Ligatures conditionnelles", "Discretionary Ligatures", "Discretionary Ligatures", "自由连字"],
    ),
    ("Fractions", ["Fractions", "Fractions", "Fractions", "Fractions", "分数"]),
    ("Ordinal", ["Ordinal", "Ordinaux", "Ordinal", "Ordinal", "序数"]),
    ("Swash", ["Swash", "Lettres italiques ornées", "Swash", "Swash", "花体"]),
    ("Titling Alternates", ["Titling Alternates", "Variantes de titrage", "Titling Alternates", "Titling Alternates", "标题替代字形"]),
    (
        "Contextual Alternates",
        ["Contextual Alternates", "Variantes contextuelles", "Contextual Alternates", "Contextual Alternates", "上下文替代字形"],
    ),
    ("Slashed Zero", ["Slashed Zero", "Zéro barré", "Slashed Zero", "Slashed Zero", "斜线零"]),
    ("Tabular Lining", ["Tabular Lining", "Chiffres alignés tabulaires", "Tabular Lining", "Tabular Lining", "等宽齐线数字"]),
    (
        "Proportional Oldstyle",
        ["Proportional Oldstyle", "Chiffres elzéviriens proportionnels", "Proportional Oldstyle", "Proportional Oldstyle", "比例旧式数字"],
    ),
    ("Proportional Lining", ["Proportional Lining", "Chiffres alignés proportionnels", "Proportional Lining", "Proportional Lining", "比例齐线数字"]),
    ("Tabular Oldstyle", ["Tabular Oldstyle", "Chiffres elzéviriens tabulaires", "Tabular Oldstyle", "Tabular Oldstyle", "等宽旧式数字"]),
    (
        "Default Figure Style",
        ["Default Figure Style", "Style de chiffres par défaut", "Default Figure Style", "Default Figure Style", "默认数字样式"],
    ),
    ("Not a button", ["Not a button", "Pas un bouton", "Not a button", "Not a button", "非按钮"]),
    ("Go To Next Page", ["Go To Next Page", "Atteindre la page suivante", "Go To Next Page", "Go To Next Page", "转到下一页"]),
    ("Go To Previous Page", ["Go To Previous Page", "Atteindre la page précédente", "Go To Previous Page", "Go To Previous Page", "转到上一页"]),
    ("Go To First Page", ["Go To First Page", "Atteindre la première page", "Go To First Page", "Go To First Page", "转到第一页"]),
    ("Go To Last Page", ["Go To Last Page", "Atteindre la dernière page", "Go To Last Page", "Go To Last Page", "转到最后一页"]),
    ("Go To Page", ["Go To Page", "Atteindre la page", "Go To Page", "Go To Page", "转到页面"]),
    ("Go To URL", ["Go To URL", "Atteindre l'URL", "Go To URL", "Go To URL", "转到网址"]),
    ("Not a form field", ["Not a form field", "Pas un champ de formulaire", "Not a form field", "Not a form field", "非表单域"]),
    ("Text Field", ["Text Field", "Champ de texte", "Text Field", "Text Field", "文本域"]),
    ("Check Box", ["Check Box", "Case à cocher", "Check Box", "Check Box", "复选框"]),
    ("Radio Button", ["Radio Button", "Bouton radio", "Radio Button", "Radio Button", "单选按钮"]),
    ("Combo Box", ["Combo Box", "Liste déroulante", "Combo Box", "Combo Box", "组合框"]),
    ("List Box", ["List Box", "Zone de liste", "List Box", "List Box", "列表框"]),
    ("Signature", ["Signature", "Signature", "Signature", "Signature", "签名"]),
    ("Resize width", ["Resize width", "Redimensionner la largeur", "Resize width", "Resize width", "调整宽度"]),
    ("Resize height", ["Resize height", "Redimensionner la hauteur", "Resize height", "Resize height", "调整高度"]),
    ("Pin top", ["Pin top", "Épingler en haut", "Pin top", "Pin top", "固定顶部"]),
    ("Pin bottom", ["Pin bottom", "Épingler en bas", "Pin bottom", "Pin bottom", "固定底部"]),
    ("Pin left", ["Pin left", "Épingler à gauche", "Pin left", "Pin left", "固定左侧"]),
    ("Pin right", ["Pin right", "Épingler à droite", "Pin right", "Pin right", "固定右侧"]),
    ("Inward", ["Inward", "Vers l'intérieur", "Inward", "Inward", "向内"]),
    ("Metrics", ["Metrics", "Métrique", "Metrics", "Metrics", "度量"]),
    ("Optical", ["Optical", "Optique", "Optical", "Optical", "视觉"]),
    (
        "Optical Margin Alignment",
        ["Optischer Randausgleich", "Marges optiques", "Alineación de márgenes ópticos", "オプティカルマージン揃え", "视觉边距对齐"],
    ),
    ("Applies to fill", ["Applies to fill", "S'applique au fond", "Applies to fill", "Applies to fill", "应用于填色"]),
    ("Applies to text", ["Applies to text", "S'applique au texte", "Applies to text", "Applies to text", "应用于文本"]),
    ("Gray", ["Gray", "Gris", "Gray", "Gray", "灰度"]),
    ("Linear", ["Linear", "Linéaire", "Linear", "Linear", "线性"]),
    ("Radial", ["Radial", "Radial", "Radial", "Radial", "径向"]),
    ("Arabic", ["Arabic", "Arabe", "Arabic", "Arabic", "阿拉伯语"]),
    ("Kanji", ["Kanji", "Kanji", "Kanji", "漢数字", "汉字数字"]),
    ("Beveled Rectangle", ["Beveled Rectangle", "Rectangle biseauté", "Beveled Rectangle", "Beveled Rectangle", "斜角矩形"]),
    ("Chinese", ["Chinese", "Chinois", "Chinese", "Chinese", "中文"]),
    (
        "Constrain proportions for width and height",
        [
            "Constrain proportions for width and height",
            "Conserver les proportions de la largeur et de la hauteur",
            "Constrain proportions for width and height",
            "Constrain proportions for width and height",
            "约束宽高比例",
        ],
    ),
    ("Corner", ["Corner", "Angles", "Corner", "Corner", "角"]),
    ("Custom", ["Custom", "Personnalisé", "Custom", "Custom", "自定义"]),
    ("Czech", ["Czech", "Tchèque", "Czech", "Czech", "捷克语"]),
    ("Danish", ["Danish", "Danois", "Danish", "Danish", "丹麦语"]),
    ("Dashed", ["Dashed", "Tirets", "Dashed", "Dashed", "虚线"]),
    ("Dotted", ["Dotted", "Pointillé", "Dotted", "Dotted", "点线"]),
    (
        "Dutch: 2005 Reform",
        ["Dutch: 2005 Reform", "Néerlandais : réforme de 2005", "Dutch: 2005 Reform", "Dutch: 2005 Reform", "荷兰语：2005 年拼写改革"],
    ),
    ("Embedded", ["Embedded", "Incorporé", "Embedded", "Embedded", "已嵌入"]),
    ("English: Canadian", ["English: Canadian", "Anglais : Canada", "English: Canadian", "English: Canadian", "英语：加拿大"]),
    ("English: UK", ["English: UK", "Anglais : Royaume-Uni", "English: UK", "English: UK", "英语：英国"]),
    ("English: USA", ["English: USA", "Anglais : États-Unis", "English: USA", "English: USA", "英语：美国"]),
    ("Farsi", ["Farsi", "Persan", "Farsi", "Farsi", "波斯语"]),
    ("Finnish", ["Finnish", "Finnois", "Finnish", "Finnish", "芬兰语"]),
    (
        "Fit Frame to Content",
        ["Fit Frame to Content", "Ajuster le bloc au contenu", "Fit Frame to Content", "Fit Frame to Content", "使框架适合内容"],
    ),
    ("French", ["French", "Français", "French", "French", "法语"]),
    ("French: Canadian", ["French: Canadian", "Français : Canada", "French: Canadian", "French: Canadian", "法语：加拿大"]),
    (
        "German: 2006 Reform",
        ["German: 2006 Reform", "Allemand : réforme de 2006", "German: 2006 Reform", "German: 2006 Reform", "德语：2006 年拼写改革"],
    ),
    (
        "German: Swiss 2006 Reform",
        [
            "German: Swiss 2006 Reform",
            "Allemand : réforme suisse 2006",
            "German: Swiss 2006 Reform",
            "German: Swiss 2006 Reform",
            "德语：瑞士 2006 年拼写改革",
        ],
    ),
    ("Greek", ["Greek", "Grec", "Greek", "Greek", "希腊语"]),
    ("Hebrew", ["Hebrew", "Hébreu", "Hebrew", "Hebrew", "希伯来语"]),
    ("Hindi", ["Hindi", "Hindi", "Hindi", "Hindi", "印地语"]),
    ("Hungarian", ["Hungarian", "Hongrois", "Hungarian", "Hungarian", "匈牙利语"]),
    (
        "Inverse Rounded Rectangle",
        ["Inverse Rounded Rectangle", "Rectangle arrondi inversé", "Inverse Rounded Rectangle", "Inverse Rounded Rectangle", "内凹圆角矩形"],
    ),
    ("Italian", ["Italian", "Italien", "Italian", "Italian", "意大利语"]),
    ("Japanese", ["Japanese", "Japonais", "Japanese", "Japanese", "日语"]),
    ("Korean", ["Korean", "Coréen", "Korean", "Korean", "韩语"]),
    (
        "Make all settings the same",
        [
            "Make all settings the same",
            "Rendre tous les réglages identiques",
            "Make all settings the same",
            "Make all settings the same",
            "统一所有设置",
        ],
    ),
    ("Native", ["Native", "Natif", "Native", "Native", "本地数字"]),
    ("Norwegian: Bokmål", ["Norwegian: Bokmål", "Norvégien : bokmål", "Norwegian: Bokmål", "Norwegian: Bokmål", "挪威语：书面语"]),
    ("Orthogonal Line", ["Orthogonal Line", "Trait orthogonal", "Orthogonal Line", "Orthogonal Line", "正交线"]),
    ("Polish", ["Polish", "Polonais", "Polish", "Polish", "波兰语"]),
    ("Portuguese", ["Portuguese", "Portugais", "Portuguese", "Portuguese", "葡萄牙语"]),
    ("Portuguese: Brazilian", ["Portuguese: Brazilian", "Portugais : Brésil", "Portuguese: Brazilian", "Portuguese: Brazilian", "葡萄牙语：巴西"]),
    ("Rounded Rectangle", ["Rounded Rectangle", "Rectangle arrondi", "Rounded Rectangle", "Rounded Rectangle", "圆角矩形"]),
    ("Russian", ["Russian", "Russe", "Russian", "Russian", "俄语"]),
    ("Solid", ["Solid", "Continu", "Solid", "Solid", "实线"]),
    ("Spanish", ["Spanish", "Espagnol", "Spanish", "Spanish", "西班牙语"]),
    ("Story Editor", ["Story Editor", "Mode éditeur", "Story Editor", "Story Editor", "文章编辑器"]),
    ("Swedish", ["Swedish", "Suédois", "Swedish", "Swedish", "瑞典语"]),
    ("Thick - Thick", ["Thick - Thick", "Épais - épais", "Thick - Thick", "Thick - Thick", "粗线－粗线"]),
    ("Thick - Thin", ["Thick - Thin", "Épais - fin", "Thick - Thin", "Thick - Thin", "粗线－细线"]),
    ("Thin - Thick", ["Thin - Thick", "Fin - épais", "Thin - Thick", "Thin - Thick", "细线－粗线"]),
    ("Thin - Thin", ["Thin - Thin", "Fin - fin", "Thin - Thin", "Thin - Thin", "细线－细线"]),
    ("Thin - Thick - Thin", ["Thin - Thick - Thin", "Fin - épais - fin", "Thin - Thick - Thin", "Thin - Thick - Thin", "细线－粗线－细线"]),
    ("Thick - Thin - Thick", ["Thick - Thin - Thick", "Épais - fin - épais", "Thick - Thin - Thick", "Thick - Thin - Thick", "粗线－细线－粗线"]),
    ("Wavy", ["Wavy", "Ondulé", "Wavy", "Wavy", "波浪线"]),
    ("Straight Hash", ["Straight Hash", "Hachures droites", "Straight Hash", "Straight Hash", "直斜线"]),
    ("Stripes", ["Stripes", "Rayures", "Stripes", "Stripes", "条纹"]),
    ("Triangle", ["Triangle", "Triangle", "Triangle", "Triangle", "三角形"]),
    ("Turkish", ["Turkish", "Turc", "Turkish", "Turkish", "土耳其语"]),
    ("Ukrainian", ["Ukrainian", "Ukrainien", "Ukrainian", "Ukrainian", "乌克兰语"]),
    ("Cell Style", ["Cell Style", "Style de cellule", "Cell Style", "Cell Style", "单元格样式"]),
    ("Table Style", ["Table Style", "Style de tableau", "Table Style", "Table Style", "表样式"]),
    ("Col ←", ["Col ←", "Col ←", "Col ←", "Col ←", "左侧插入列"]),
    ("Col →", ["Col →", "Col →", "Col →", "Col →", "右侧插入列"]),
    ("Row ↑", ["Row ↑", "Ligne ↑", "Row ↑", "Row ↑", "上方插入行"]),
    ("Row ↓", ["Row ↓", "Ligne ↓", "Row ↓", "Row ↓", "下方插入行"]),
    ("Hide Others", ["Hide Others", "Masquer les autres", "Hide Others", "Hide Others", "隐藏其他图层"]),
    ("Lock Others", ["Lock Others", "Verrouiller les autres", "Lock Others", "Lock Others", "锁定其他图层"]),
    ("Show All Layers", ["Show All Layers", "Afficher tous les calques", "Show All Layers", "Show All Layers", "显示所有图层"]),
    ("Unlock", ["Unlock", "Déverrouiller", "Unlock", "Unlock", "解锁"]),
    ("Unlock All Layers", ["Unlock All Layers", "Déverrouiller tous les calques", "Unlock All Layers", "Unlock All Layers", "解锁所有图层"]),
    ("Added", ["Added", "Ajouté", "Added", "Added", "已添加"]),
    ("Deleted", ["Deleted", "Supprimé", "Deleted", "Deleted", "已删除"]),
    ("Guide-based", ["Guide-based", "Basé sur les repères", "Guide-based", "Guide-based", "基于参考线"]),
    ("Object-Based", ["Object-Based", "Basé sur les objets", "Object-Based", "Object-Based", "基于对象"]),
    ("Guide-Based", ["Guide-Based", "Basé sur les repères", "Guide-Based", "Guide-Based", "基于参考线"]),
    ("Page:", ["Seite:", "Page :", "Página:", "ページ:", "页面："]),
    ("Content:", ["Inhalt:", "Contenu :", "Contenido:", "コンテンツ:", "内容："]),
    ("Object Constraints:", ["Objektbeschränkungen:", "Contraintes d’objet :", "Restricciones de objeto:", "オブジェクトの制約:", "对象约束："]),
    (
        "Resize with Page:",
        ["Mit Seite skalieren:", "Redimensionner avec la page :", "Cambiar tamaño con la página:", "ページと共にサイズ変更:", "随页面调整大小："],
    ),
    ("Pin:", ["Fixieren:", "Épingler :", "Fijar:", "固定:", "固定："]),
    ("Resize Page", ["Seitengröße ändern", "Redimensionner la page", "Cambiar tamaño de página", "ページのサイズを変更", "调整页面大小"]),
    (
        "Liquid Page Rule:",
        ["Regel für flüssige Seiten:", "Règle de page liquide :", "Regla de página líquida:", "リキッドページルール:", "自适应页面规则："],
    ),
    (
        "Show Parent Page Overlay",
        [
            "Überlagerung der übergeordneten Seite anzeigen",
            "Afficher la superposition de la page parent",
            "Mostrar superposición de página principal",
            "親ページオーバーレイを表示",
            "显示父页面叠加",
        ],
    ),
    (
        "Controlled by Parent",
        ["Durch übergeordnete Seite gesteuert", "Contrôlé par le parent", "Controlado por principal", "親ページで制御", "由父页面控制"],
    ),
    ("US Business Card", ["US-Visitenkarte", "Carte de visite US", "Tarjeta de visita EE. UU.", "US 名刺", "美国名片"]),
    (
        "Object is pinned relative to the page edge. Click to release.",
        [
            "Das Objekt ist relativ zum Seitenrand fixiert. Zum Lösen klicken.",
            "L’objet est épinglé par rapport au bord de la page. Cliquez pour le libérer.",
            "El objeto está fijado respecto al borde de la página. Haga clic para soltarlo.",
            "オブジェクトはページの端を基準に固定されています。クリックすると解除します。",
            "对象已相对于页面边缘固定。单击可释放。",
        ],
    ),
    (
        "Click to pin the object relative to the page edge.",
        [
            "Klicken, um das Objekt relativ zum Seitenrand zu fixieren.",
            "Cliquez pour épingler l’objet par rapport au bord de la page.",
            "Haga clic para fijar el objeto respecto al borde de la página.",
            "クリックすると、オブジェクトをページの端を基準に固定します。",
            "单击可将对象相对于页面边缘固定。",
        ],
    ),
    (
        "The object changes width as the page changes width. Click to lock the object width.",
        [
            "Die Objektbreite ändert sich mit der Seitenbreite. Zum Sperren der Breite klicken.",
            "La largeur de l’objet suit celle de la page. Cliquez pour verrouiller la largeur.",
            "El ancho del objeto cambia con el de la página. Haga clic para bloquear el ancho.",
            "オブジェクトの幅はページの幅に合わせて変わります。クリックすると幅をロックします。",
            "对象宽度随页面宽度变化。单击可锁定对象宽度。",
        ],
    ),
    (
        "The object's width is locked. Click to let the object change width as the page changes width.",
        [
            "Die Objektbreite ist gesperrt. Klicken, damit sie sich mit der Seitenbreite ändert.",
            "La largeur de l’objet est verrouillée. Cliquez pour qu’elle suive celle de la page.",
            "El ancho del objeto está bloqueado. Haga clic para que cambie con el de la página.",
            "オブジェクトの幅はロックされています。クリックすると、ページの幅に合わせて変わります。",
            "对象宽度已锁定。单击可让其随页面宽度变化。",
        ],
    ),
    (
        "The object changes height as the page changes height. Click to lock the object height.",
        [
            "Die Objekthöhe ändert sich mit der Seitenhöhe. Zum Sperren der Höhe klicken.",
            "La hauteur de l’objet suit celle de la page. Cliquez pour verrouiller la hauteur.",
            "El alto del objeto cambia con el de la página. Haga clic para bloquear el alto.",
            "オブジェクトの高さはページの高さに合わせて変わります。クリックすると高さをロックします。",
            "对象高度随页面高度变化。单击可锁定对象高度。",
        ],
    ),
    (
        "The object's height is locked. Click to let the object change height as the page changes height.",
        [
            "Die Objekthöhe ist gesperrt. Klicken, damit sie sich mit der Seitenhöhe ändert.",
            "La hauteur de l’objet est verrouillée. Cliquez pour qu’elle suive celle de la page.",
            "El alto del objeto está bloqueado. Haga clic para que cambie con el de la página.",
            "オブジェクトの高さはロックされています。クリックすると、ページの高さに合わせて変わります。",
            "对象高度已锁定。单击可让其随页面高度变化。",
        ],
    ),
    ("Loop", ["Loop", "Boucle", "Loop", "Loop", "循环播放"]),
    ("Object-based", ["Object-based", "Basé sur les objets", "Object-based", "Object-based", "基于对象"]),
    ("Off", ["Off", "Désactivé", "Off", "Off", "关闭"]),
    ("Play on Page Load", ["Play on Page Load", "Lire au chargement de la page", "Play on Page Load", "Play on Page Load", "页面载入时播放"]),
    ("Re-center", ["Re-center", "Recentrer", "Re-center", "Re-center", "重新居中"]),
    ("Show Controls", ["Show Controls", "Afficher les commandes", "Show Controls", "Show Controls", "显示控件"]),
    ("Signature Field", ["Signature Field", "Champ de signature", "Signature Field", "Signature Field", "签名域"]),
    (
        "Select text to apply a condition",
        [
            "Select text to apply a condition",
            "Sélectionnez du texte pour appliquer une condition",
            "Select text to apply a condition",
            "Select text to apply a condition",
            "选择文本以应用条件",
        ],
    ),
    ("Blinds", ["Blinds", "Stores", "Blinds", "Blinds", "百叶窗"]),
    ("Box", ["Box", "Boîte", "Box", "Box", "方框"]),
    ("Comb", ["Comb", "Peigne", "Comb", "Comb", "梳状"]),
    ("Cover", ["Cover", "Recouvrir", "Cover", "Cover", "覆盖"]),
    ("Dissolve", ["Dissolve", "Dissolution", "Dissolve", "Dissolve", "溶解"]),
    ("Fade", ["Fade", "Fondu", "Fade", "Fade", "淡入淡出"]),
    ("Push", ["Push", "Pousser", "Push", "Push", "推入"]),
    ("Split", ["Split", "Fractionner", "Split", "Split", "分割"]),
    ("Uncover", ["Uncover", "Découvrir", "Uncover", "Uncover", "揭开"]),
    ("Wipe", ["Wipe", "Balayage", "Wipe", "Wipe", "擦除"]),
    ("Simple", ["Simple", "Simple", "Simple", "Simple", "简单"]),
    ("Simple - Wide", ["Simple - Wide", "Simple - large", "Simple - Wide", "Simple - Wide", "简单－宽"]),
    ("Triangle - Wide", ["Triangle - Wide", "Triangle - large", "Triangle - Wide", "Triangle - Wide", "三角形－宽"]),
    ("Barbed", ["Barbed", "Barbelée", "Barbed", "Barbed", "倒钩"]),
    ("Curved", ["Curved", "Courbe", "Curved", "Curved", "曲线"]),
    ("Circle", ["Circle", "Cercle", "Circle", "Circle", "圆形"]),
    ("Circle - Solid", ["Circle - Solid", "Cercle - plein", "Circle - Solid", "Circle - Solid", "实心圆"]),
    ("Square", ["Square", "Carré", "Square", "Square", "正方形"]),
    ("Square - Solid", ["Square - Solid", "Carré - plein", "Square - Solid", "Square - Solid", "实心正方形"]),
    ("Bar", ["Bar", "Barre", "Bar", "Bar", "短线"]),
    ("Fit Text", ["Fit Text", "Ajuster le texte", "Fit Text", "Fit Text", "适合文本"]),
    ("Preview (W)", ["Preview (W)", "Aperçu (W)", "Preview (W)", "Preview (W)", "预览 (W)"]),
    ("Normal (W)", ["Normal (W)", "Normal (W)", "Normal (W)", "Normal (W)", "正常 (W)"]),
    ("objects", ["objects", "objets", "objects", "objects", "个对象"]),
    ("pages", ["pages", "pages", "pages", "pages", "页"]),
    ("stories", ["stories", "articles", "stories", "stories", "篇文章"]),
    ("items", ["items", "éléments", "items", "items", "个项目"]),
    ("warnings", ["warnings", "avertissements", "warnings", "warnings", "个警告"]),
    ("Render", ["Render", "Rendu", "Render", "Render", "渲染"]),
    ("Set", ["Set", "Jeu", "Set", "Set", "样式集"]),
    ("unused", ["unused", "inutilisé", "unused", "unused", "未使用"]),
    ("⚠ Missing", ["⚠ Missing", "⚠ Manquant", "⚠ Missing", "⚠ Missing", "⚠ 缺失"]),
    ("▲ Modified", ["▲ Modified", "▲ Modifié", "▲ Modified", "▲ Modified", "▲ 已修改"]),
    ("(Text Color)", ["(Text Color)", "(Couleur du texte)", "(Text Color)", "(Text Color)", "（文本颜色）"]),
    (
        "{count} glyphs — click to insert at the text cursor",
        [
            "{count} glyphs — click to insert at the text cursor",
            "{count} glyphes : cliquez pour insérer à l'emplacement du curseur",
            "{count} glyphs — click to insert at the text cursor",
            "{count} glyphs — click to insert at the text cursor",
            "{count} 个字形 — 单击插入到文本光标处",
        ],
    ),
    (
        "{pages} Pages in {spreads} Spreads",
        [
            "{pages} Pages in {spreads} Spreads",
            "{pages} pages sur {spreads} planches",
            "{pages} Pages in {spreads} Spreads",
            "{pages} Pages in {spreads} Spreads",
            "共 {pages} 页，{spreads} 个跨页",
        ],
    ),
    (" (auto)", [" (auto)", " (auto)", " (auto)", " (auto)", "（自动）"]),
    (
        "Absolute Numbering (instead of Section Numbering)",
        [
            "Absolute Numbering (instead of Section Numbering)",
            "Numérotation absolue (au lieu de la numérotation par section)",
            "Absolute Numbering (instead of Section Numbering)",
            "Absolute Numbering (instead of Section Numbering)",
            "绝对页码（而非章节页码）",
        ],
    ),
    (
        "Add and remove pages as the primary text frame's story grows and shrinks",
        [
            "Add and remove pages as the primary text frame's story grows and shrinks",
            "Ajouter et supprimer des pages à mesure que l'article du bloc de texte principal s'allonge ou se raccourcit",
            "Add and remove pages as the primary text frame's story grows and shrinks",
            "Add and remove pages as the primary text frame's story grows and shrinks",
            "随主文本框架内容增减自动添加或删除页面",
        ],
    ),
    (
        "Added Text (highlighted)",
        ["Added Text (highlighted)", "Texte ajouté (surligné)", "Added Text (highlighted)", "Added Text (highlighted)", "新增文本（高亮）"],
    ),
    (
        "Adjust Layout (objects follow the new page size)",
        [
            "Adjust Layout (objects follow the new page size)",
            "Ajuster la mise en page (les objets suivent le nouveau format de page)",
            "Adjust Layout (objects follow the new page size)",
            "Adjust Layout (objects follow the new page size)",
            "调整版面（对象随页面尺寸调整）",
        ],
    ),
    ("Auto-Fit", ["Auto-Fit", "Ajustement automatique", "Auto-Fit", "Auto-Fit", "自动适合"]),
    ("Case sensitive", ["Case sensitive", "Respecter la casse", "Case sensitive", "Case sensitive", "区分大小写"]),
    (
        "Custom Tracking/Kerning",
        [
            "Custom Tracking/Kerning",
            "Approche/crénage personnalisés",
            "Custom Tracking/Kerning",
            "Custom Tracking/Kerning",
            "自定义字距调整/字距微调",
        ],
    ),
    (
        "Dimensions Include Stroke Weight",
        [
            "Dimensions Include Stroke Weight",
            "Les dimensions incluent l'épaisseur du contour",
            "Dimensions Include Stroke Weight",
            "Dimensions Include Stroke Weight",
            "尺寸包括描边粗细",
        ],
    ),
    ("Enable Autocorrect", ["Enable Autocorrect", "Activer la correction automatique", "Enable Autocorrect", "Enable Autocorrect", "启用自动更正"]),
    (
        "Enable Dynamic Spelling (underline misspelled words)",
        [
            "Enable Dynamic Spelling (underline misspelled words)",
            "Activer l'orthographe dynamique (souligner les mots mal orthographiés)",
            "Enable Dynamic Spelling (underline misspelled words)",
            "Enable Dynamic Spelling (underline misspelled words)",
            "启用动态拼写检查（在拼写错误下加线）",
        ],
    ),
    ("Grids in Back", ["Grids in Back", "Grilles en arrière-plan", "Grids in Back", "Grids in Back", "网格置于后方"]),
    ("H&J Violations", ["H&J Violations", "Infractions de C&J", "H&J Violations", "H&J Violations", "断字与对齐违规"]),
    ("Include Bleed", ["Include Bleed", "Inclure le fond perdu", "Include Bleed", "Include Bleed", "包含出血"]),
    (
        "Include Stroke Weight",
        ["Include Stroke Weight", "Inclure l'épaisseur du contour", "Include Stroke Weight", "Include Stroke Weight", "包含描边粗细"],
    ),
    ("Join our Discord", ["Join our Discord", "Rejoindre notre Discord", "Join our Discord", "Join our Discord", "加入我们的 Discord 社区"]),
    ("Keep Violations", ["Keep Violations", "Infractions d'enchaînement", "Keep Violations", "Keep Violations", "保持选项违规"]),
    (
        "Overprint [Black] Swatch at 100%",
        [
            "Overprint [Black] Swatch at 100%",
            "Surimpression de la nuance [Noir] à 100 %",
            "Overprint [Black] Swatch at 100%",
            "Overprint [Black] Swatch at 100%",
            "100% 黑色色板叠印",
        ],
    ),
    ("Printer's Marks", ["Printer's Marks", "Repères d'impression", "Printer's Marks", "Printer's Marks", "打印标记"]),
    (
        "Remove Styles and Formatting from Text and Tables",
        [
            "Remove Styles and Formatting from Text and Tables",
            "Supprimer les styles et la mise en forme du texte et des tableaux",
            "Remove Styles and Formatting from Text and Tables",
            "Remove Styles and Formatting from Text and Tables",
            "从文本和表格中删除样式和格式",
        ],
    ),
    ("Ruby", ["Ruby", "Ruby", "Ruby", "Ruby", "旁注"]),
    (
        "Show Note Anchors in Layout View",
        [
            "Show Note Anchors in Layout View",
            "Afficher les ancres de note dans l'affichage Mise en page",
            "Show Note Anchors in Layout View",
            "Show Note Anchors in Layout View",
            "在版面视图显示附注锚点",
        ],
    ),
    ("Spreads", ["Spreads", "Planches", "Spreads", "Spreads", "跨页"]),
    ("Substituted Fonts", ["Substituted Fonts", "Polices substituées", "Substituted Fonts", "Substituted Fonts", "替换字体"]),
    (
        "Transformations are Totals",
        [
            "Transformations are Totals",
            "Les transformations sont des totaux",
            "Transformations are Totals",
            "Transformations are Totals",
            "变换为总计",
        ],
    ),
    (
        "Use Black Point Compensation",
        [
            "Use Black Point Compensation",
            "Utiliser la compensation du point noir",
            "Use Black Point Compensation",
            "Use Black Point Compensation",
            "使用黑场补偿",
        ],
    ),
    (
        "Use Typographer's Quotes",
        [
            "Use Typographer's Quotes",
            "Utiliser les guillemets typographiques",
            "Use Typographer's Quotes",
            "Use Typographer's Quotes",
            "使用排版引号",
        ],
    ),
    ("Whole word", ["Whole word", "Mot entier", "Whole word", "Whole word", "全字匹配"]),
    ("Interface", ["Interface", "Interface", "Interface", "Interface", "界面"]),
    ("Advanced Type", ["Advanced Type", "Texte avancé", "Advanced Type", "Advanced Type", "高级文字"]),
    ("Composition", ["Composition", "Composition", "Composition", "Composition", "排版"]),
    (
        "Show Font Names in English",
        [
            "Schriftnamen auf Englisch anzeigen",
            "Afficher les noms de police en anglais",
            "Mostrar nombres de fuentes en inglés",
            "フォント名を英語で表示",
            "以英文显示字体名称",
        ],
    ),
    ("Show CJK Features", ["CJK-Funktionen anzeigen", "Afficher les fonctions CJK", "Mostrar funciones CJK", "CJK 機能を表示", "显示中日韩功能"]),
    ("Missing Glyphs", ["Fehlende Glyphen", "Glyphes manquants", "Glifos que faltan", "欠落グリフ", "缺失字形"]),
    (
        "Draw Missing Glyphs from Fallback Fonts",
        [
            "Fehlende Glyphen aus Ersatzschriften zeichnen",
            "Dessiner les glyphes manquants avec des polices de substitution",
            "Dibujar los glifos que faltan con fuentes alternativas",
            "欠落グリフを代替フォントで表示",
            "用后备字体绘制缺失字形",
        ],
    ),
    ("Units & Increments", ["Units & Increments", "Unités et incréments", "Units & Increments", "Units & Increments", "单位和增量"]),
    ("Grids", ["Grids", "Grilles", "Grids", "Grids", "网格"]),
    ("Guides & Pasteboard", ["Guides & Pasteboard", "Repères et table de montage", "Guides & Pasteboard", "Guides & Pasteboard", "参考线和粘贴板"]),
    ("Dictionary", ["Dictionary", "Dictionnaire", "Dictionary", "Dictionary", "词典"]),
    ("Autocorrect", ["Autocorrect", "Correction automatique", "Autocorrect", "Autocorrect", "自动更正"]),
    ("Story Editor Display", ["Story Editor Display", "Affichage du mode éditeur", "Story Editor Display", "Story Editor Display", "文章编辑器显示"]),
    ("File Handling", ["File Handling", "Gestion des fichiers", "File Handling", "File Handling", "文件处理"]),
    (
        "Formatting affects container (J)",
        [
            "Formatting affects container (J)",
            "La mise en forme agit sur le conteneur (J)",
            "Formatting affects container (J)",
            "Formatting affects container (J)",
            "格式应用于容器 (J)",
        ],
    ),
    (
        "Formatting affects text (J)",
        [
            "Formatting affects text (J)",
            "La mise en forme agit sur le texte (J)",
            "Formatting affects text (J)",
            "Formatting affects text (J)",
            "格式应用于文字 (J)",
        ],
    ),
    ("Apply None", ["Apply None", "Appliquer Aucun", "Apply None", "Apply None", "应用无色"]),
    ("Height Only", ["Height Only", "Hauteur uniquement", "Height Only", "Height Only", "仅高度"]),
    ("Width Only", ["Width Only", "Largeur uniquement", "Width Only", "Width Only", "仅宽度"]),
    ("Height and Width", ["Height and Width", "Hauteur et largeur", "Height and Width", "Height and Width", "高度和宽度"]),
    ("Height only", ["Height only", "Hauteur uniquement", "Height only", "Height only", "仅高度"]),
    ("Width only", ["Width only", "Largeur uniquement", "Width only", "Width only", "仅宽度"]),
    ("Height and width", ["Height and width", "Hauteur et largeur", "Height and width", "Height and width", "高度和宽度"]),
    ("Version", ["Version", "Version", "Version", "Version", "版本"]),
    (
        "{count} characters don't fit",
        [
            "{count} characters don't fit",
            "{count} caractères ne tiennent pas",
            "{count} characters don't fit",
            "{count} characters don't fit",
            "有 {count} 个字符溢出",
        ],
    ),
    ("document", ["document", "document", "document", "document", "文档"]),
    ("story", ["story", "article", "story", "story", "文章"]),
    ("selection", ["selection", "sélection", "selection", "selection", "选区"]),
    ("top", ["top", "haut", "top", "top", "顶部"]),
    ("center", ["center", "centre", "center", "center", "居中"]),
    ("bottom", ["bottom", "bas", "bottom", "bottom", "底部"]),
    ("justify", ["justify", "justifié", "justify", "justify", "两端对齐"]),
    ("text", ["text", "texte", "text", "text", "文字"]),
    ("graphic", ["graphic", "graphique", "graphic", "graphic", "图形"]),
    ("unassigned", ["unassigned", "non attribué", "unassigned", "unassigned", "未指定"]),
    ("Perceptual", ["Perceptual", "Perception", "Perceptual", "Perceptual", "可感知"]),
    ("Relative Colorimetric", ["Relative Colorimetric", "Colorimétrie relative", "Relative Colorimetric", "Relative Colorimetric", "相对比色"]),
    ("Saturation", ["Saturation", "Saturation", "Saturation", "Saturation", "饱和度"]),
    ("Absolute Colorimetric", ["Absolute Colorimetric", "Colorimétrie absolue", "Absolute Colorimetric", "Absolute Colorimetric", "绝对比色"]),
    ("No conflicts", ["No conflicts", "Aucun conflit", "No conflicts", "No conflicts", "没有冲突"]),
    ("Page (1–{count}):", ["Page (1–{count}):", "Page (1–{count}) :", "Page (1–{count}):", "Page (1–{count}):", "页码 (1–{count})："]),
    (
        "Fonts in Document: {count}    Missing: {missing}",
        [
            "Fonts in Document: {count}    Missing: {missing}",
            "Polices du document : {count}    Manquantes : {missing}",
            "Fonts in Document: {count}    Missing: {missing}",
            "Fonts in Document: {count}    Missing: {missing}",
            "文档中的字体：{count}    缺失：{missing}",
        ],
    ),
    ("No data source", ["Keine Datenquelle", "Aucune source de données", "No hay fuente de datos", "データソースがありません", "没有数据源"]),
    (
        "Select Data Source…",
        ["Datenquelle auswählen …", "Choisir une source de données…", "Seleccionar fuente de datos…", "データソースを選択…", "选择数据源…"],
    ),
    ("Data Merge", ["Datenzusammenführung", "Fusion des données", "Combinación de datos", "データ結合", "数据合并"]),
    ("Preview", ["Vorschau", "Aperçu", "Previsualización", "プレビュー", "预览"]),
    ("Previous", ["Zurück", "Précédent", "Anterior", "前へ", "上一条"]),
    ("Next", ["Weiter", "Suivant", "Siguiente", "次へ", "下一条"]),
    ("Record", ["Datensatz", "Enregistrement", "Registro", "レコード", "记录"]),
    ("Merge options", ["Optionen für die Zusammenführung", "Options de fusion", "Opciones de combinación", "結合オプション", "合并选项"]),
    ("All records", ["Alle Datensätze", "Tous les enregistrements", "Todos los registros", "すべてのレコード", "全部记录"]),
    ("One record", ["Ein Datensatz", "Un enregistrement", "Un registro", "1件のレコード", "一条记录"]),
    ("Range", ["Bereich", "Plage", "Intervalo", "範囲", "范围"]),
    ("Records per page", ["Datensätze pro Seite", "Enregistrements par page", "Registros por página", "ページあたりのレコード", "每页记录数"]),
    ("Single record", ["Einzelner Datensatz", "Un seul enregistrement", "Un solo registro", "単一レコード", "单条记录"]),
    ("Multiple records", ["Mehrere Datensätze", "Plusieurs enregistrements", "Varios registros", "複数レコード", "多条记录"]),
    ("Rows first", ["Zeilen zuerst", "Lignes d'abord", "Filas primero", "行を優先", "先行后列"]),
    ("Columns first", ["Spalten zuerst", "Colonnes d'abord", "Columnas primero", "列を優先", "先列后行"]),
    ("Column spacing", ["Spaltenabstand", "Espacement des colonnes", "Espacio entre columnas", "列の間隔", "列间距"]),
    ("Row spacing", ["Zeilenabstand", "Espacement des lignes", "Espacio entre filas", "行の間隔", "行间距"]),
    (
        "Fit proportionally",
        ["Proportional einpassen", "Ajuster proportionnellement", "Encajar proporcionalmente", "縦横比を保持して合わせる", "按比例适合"],
    ),
    (
        "Fill proportionally",
        ["Proportional füllen", "Remplir proportionnellement", "Llenar proporcionalmente", "縦横比を保持して塗りつぶす", "按比例填充"],
    ),
    (
        "Fit content to frame",
        ["Inhalt an Rahmen anpassen", "Ajuster le contenu au bloc", "Ajustar el contenido al marco", "内容をフレームに合わせる", "内容适合框架"],
    ),
    ("Center in frame", ["Im Rahmen zentrieren", "Centrer dans le bloc", "Centrar en el marco", "フレーム内で中央", "在框架中居中"]),
    ("Link images", ["Bilder verknüpfen", "Lier les images", "Vincular imágenes", "画像をリンク", "链接图像"]),
    ("Limit", ["Obergrenze", "Limite", "Límite", "上限", "上限"]),
    ("Bind to frame", ["An Rahmen binden", "Lier au bloc", "Vincular al marco", "フレームにバインド", "绑定到框架"]),
    ("Insert field", ["Feld einfügen", "Insérer le champ", "Insertar campo", "フィールドを挿入", "插入字段"]),
    (
        "Pass csv, rows, or bytes from the control channel.",
        [
            "csv, rows oder bytes über den Steuerkanal übergeben.",
            "Transmettez csv, rows ou bytes par le canal de contrôle.",
            "Pase csv, rows o bytes por el canal de control.",
            "制御チャネルから csv、rows または bytes を渡します。",
            "请通过控制通道传入 csv、rows 或 bytes。",
        ],
    ),
    // Paragraph Rules.
    ("Paragraph Rules…", ["Absatzlinien …", "Filets de paragraphe…", "Filetes de párrafo…", "段落境界線…", "段落线…"]),
    ("Paragraph Rules", ["Absatzlinien", "Filets de paragraphe", "Filetes de párrafo", "段落境界線", "段落线"]),
    ("Justification…", ["Blocksatzeinstellungen …", "Justification…", "Justificación…", "両端揃え…", "两端对齐…"]),
    ("Rule Below", ["Linie unterhalb", "Filet au-dessous", "Filete después", "後境界線", "下方横线"]),
    ("Tint:", ["Farbton:", "Teinte :", "Matiz:", "濃淡:", "色调："]),
    ("Apply To:", ["Anwenden auf:", "Appliquer à :", "Aplicar a:", "適用先:", "应用于："]),
    ("Frame", ["Rahmen", "Bloc", "Marco", "フレーム", "框架"]),
    ("Slug", ["Infobereich", "Ligne-bloc", "Indicaciones", "印刷可能領域", "辅助信息区"]),
    ("Presentation", ["Präsentation", "Présentation", "Presentación", "プレゼンテーション", "演示文稿"]),
    ("Extras", ["Extras", "Extras", "Extras", "エクストラ", "附加"]),
    ("Column", ["Spalte", "Colonne", "Columna", "段", "栏"]),
    // File › New › Document
    ("Recent", ["Zuletzt verwendet", "Récents", "Recientes", "最近使用", "最近"]),
    ("Saved", ["Gespeichert", "Enregistrés", "Guardados", "保存済み", "已保存"]),
    ("[Default]", ["[Standard]", "[Par défaut]", "[Predeterminado]", "[初期設定]", "[默认]"]),
    ("Your Recent Items", ["Zuletzt verwendete Elemente", "Éléments récents", "Elementos recientes", "最近使用した項目", "最近使用的项目"]),
    (
        "Saved Presets",
        ["Gespeicherte Vorgaben", "Paramètres prédéfinis enregistrés", "Ajustes preestablecidos guardados", "保存済みプリセット", "已保存的预设"],
    ),
    (
        "Blank Document Presets",
        [
            "Vorgaben für leere Dokumente",
            "Paramètres prédéfinis de document vierge",
            "Ajustes preestablecidos de documento en blanco",
            "空のドキュメントプリセット",
            "空白文档预设",
        ],
    ),
    ("Delete Preset", ["Vorgabe löschen", "Supprimer le paramètre prédéfini", "Eliminar ajuste preestablecido", "プリセットを削除", "删除预设"]),
    (
        "Preset Details",
        ["Vorgabedetails", "Détails du paramètre prédéfini", "Detalles del ajuste preestablecido", "プリセットの詳細", "预设详细信息"],
    ),
    ("Document Name", ["Dokumentname", "Nom du document", "Nombre del documento", "ドキュメント名", "文档名称"]),
    (
        "Save Document Preset",
        [
            "Dokumentvorgabe speichern",
            "Enregistrer le paramètre prédéfini de document",
            "Guardar ajuste preestablecido de documento",
            "ドキュメントプリセットを保存",
            "存储文档预设",
        ],
    ),
    (
        "Save Document Preset As:",
        [
            "Dokumentvorgabe speichern unter:",
            "Enregistrer le paramètre prédéfini de document sous :",
            "Guardar ajuste preestablecido de documento como:",
            "ドキュメントプリセットの保存名:",
            "存储文档预设为：",
        ],
    ),
    ("Preset Name", ["Vorgabename", "Nom du paramètre prédéfini", "Nombre del ajuste preestablecido", "プリセット名", "预设名称"]),
    ("Save Preset", ["Vorgabe speichern", "Enregistrer le paramètre prédéfini", "Guardar ajuste preestablecido", "プリセットを保存", "存储预设"]),
    ("Start #", ["Startseitennr.", "N° de début", "N.º inicial", "開始ページ番号", "起始页码"]),
    ("Column Gutter", ["Spaltenabstand", "Gouttière", "Medianil", "列間隔", "栏间距"]),
    // Layout › Numbering & Section Options
    ("Start Section", ["Abschnittsanfang", "Début de section", "Iniciar sección", "セクション開始", "开始新章节"]),
    (
        "Automatic Page Numbering",
        [
            "Automatische Seitennummerierung",
            "Numérotation automatique des pages",
            "Numeración de páginas automática",
            "自動ページ番号",
            "自动编排页码",
        ],
    ),
    (
        "Start Page Numbering at:",
        ["Seitennummerierung beginnen bei:", "Commencer la numérotation à :", "Iniciar numeración de páginas en:", "開始ページ番号:", "起始页码："],
    ),
    ("Section Prefix:", ["Abschnittspräfix:", "Préfixe de section :", "Prefijo de sección:", "セクションプレフィックス:", "章节前缀："]),
    ("Section Marker:", ["Abschnittsmarke:", "Marqueur de section :", "Marcador de sección:", "セクションマーカー:", "章节标志符："]),
    (
        "Include Prefix when Numbering Pages",
        [
            "Präfix in Seitennummerierung einschließen",
            "Inclure le préfixe lors de la numérotation des pages",
            "Incluir prefijo al numerar páginas",
            "ページ番号にプレフィックスを含める",
            "编排页码时包含前缀",
        ],
    ),
    (
        "Document Chapter Numbering",
        [
            "Kapitelnummerierung des Dokuments",
            "Numérotation des chapitres du document",
            "Numeración de capítulos del documento",
            "ドキュメントの章番号",
            "文档章节编号",
        ],
    ),
    (
        "Automatic Chapter Numbering",
        [
            "Automatische Kapitelnummerierung",
            "Numérotation automatique des chapitres",
            "Numeración de capítulos automática",
            "自動章番号",
            "自动为章节编号",
        ],
    ),
    (
        "Start Chapter Numbering at:",
        [
            "Kapitelnummerierung beginnen bei:",
            "Commencer la numérotation des chapitres à :",
            "Iniciar numeración de capítulos en:",
            "開始章番号:",
            "起始章节编号：",
        ],
    ),
    (
        "Same as Previous Document in the Book",
        [
            "Wie vorheriges Dokument im Buch",
            "Identique au document précédent du livre",
            "Igual que el documento anterior del libro",
            "ブック内の前のドキュメントと同じ",
            "与书籍中的上一文档相同",
        ],
    ),
    ("Book Name:", ["Buchname:", "Nom du livre :", "Nombre del libro:", "ブック名:", "书籍名称："]),
    ("N/A", ["–", "S.O.", "N/D", "なし", "不适用"]),
    // Paragraph Style Options: Paragraph Border, Paragraph Shading, Keep Options, Span Columns, Bullets and Numbering.
    ("Paragraph Border", ["Absatzrahmen", "Contour de paragraphe", "Borde de párrafo", "段落囲み罫", "段落边框"]),
    ("Paragraph Shading", ["Absatzschattierung", "Ombrage de paragraphe", "Sombreado de párrafo", "段落の背景色", "段落底纹"]),
    ("Keep Options", ["Umbruchoptionen", "Options d'enchaînement", "Opciones de separación", "段落分離禁止オプション", "保持选项"]),
    ("Span Columns", ["Spalten überspannen", "Étendre sur les colonnes", "Abarcar columnas", "段抜きと段分割", "跨栏"]),
    ("Keep with Next:", ["Nicht trennen von nächsten:", "Lier aux suivantes:", "Conservar con siguientes:", "次の段落と分離禁止:", "与下一段保持："]),
    ("Keep Lines Together", ["Zeilen nicht trennen", "Lignes solidaires", "Conservar líneas juntas", "行を分離しない", "保持各行同页"]),
    (
        "All Lines in Paragraph",
        ["Alle Zeilen im Absatz", "Toutes les lignes du paragraphe", "Todas las líneas del párrafo", "段落のすべての行", "段落中所有行"],
    ),
    (
        "At Start/End of Paragraph",
        ["Am Anfang/Ende des Absatzes", "Au début/à la fin du paragraphe", "Al inicio/final del párrafo", "段落の始めと終わり", "在段落开头/结尾"],
    ),
    ("End:", ["Ende:", "Fin:", "Final:", "終了位置:", "结束："]),
    ("Start Paragraph:", ["Absatzbeginn:", "Début de paragraphe:", "Inicio de párrafo:", "段落の開始位置:", "段落开始："]),
    ("Anywhere", ["Überall", "N'importe où", "En cualquier lugar", "任意の位置", "任意位置"]),
    ("In Next Column", ["In nächster Spalte", "Dans la colonne suivante", "En la siguiente columna", "次の段", "于下一栏"]),
    ("In Next Frame", ["In nächstem Rahmen", "Dans le bloc suivant", "En el siguiente marco", "次のフレーム", "于下一框架"]),
    ("On Next Page", ["Auf nächster Seite", "Sur la page suivante", "En la página siguiente", "次のページ", "于下一页"]),
    (
        "On Next Odd Page",
        ["Auf nächster ungerader Seite", "Sur la page impaire suivante", "En la siguiente página impar", "次の奇数ページ", "于下一奇数页"],
    ),
    (
        "On Next Even Page",
        ["Auf nächster gerader Seite", "Sur la page paire suivante", "En la siguiente página par", "次の偶数ページ", "于下一偶数页"],
    ),
    ("Paragraph Layout:", ["Absatzlayout:", "Disposition du paragraphe:", "Diseño de párrafo:", "段落レイアウト:", "段落版面："]),
    ("Single Column", ["Eine Spalte", "Colonne simple", "Una columna", "単一段", "单栏"]),
    ("Split Column", ["Spalte unterteilen", "Diviser la colonne", "Dividir columna", "段分割", "拆分栏"]),
    ("Columns:", ["Spalten:", "Colonnes :", "Columnas:", "段:", "栏数："]),
    ("All", ["Alle", "Toutes", "Todas", "すべて", "全部"]),
    ("Inside Gutter:", ["Innerer Spaltenabstand:", "Gouttière intérieure:", "Medianil interior:", "内側の間隔:", "内栏间距："]),
    ("Outside Gutter:", ["Äußerer Spaltenabstand:", "Gouttière extérieure:", "Medianil exterior:", "外側の間隔:", "外栏间距："]),
    ("List Type:", ["Listentyp:", "Type de liste:", "Tipo de lista:", "リストタイプ:", "列表类型："]),
    ("Bullets", ["Aufzählungszeichen", "Puces", "Viñetas", "箇条書き記号", "项目符号"]),
    ("Numbers", ["Nummerierung", "Numéros", "Números", "自動番号", "编号"]),
    ("Bullet Character:", ["Aufzählungszeichen:", "Caractère de puce:", "Carácter de viñeta:", "箇条書き記号:", "项目符号字符："]),
    ("Text After:", ["Text danach:", "Texte après:", "Texto después:", "後続テキスト:", "后续文本："]),
    ("Gap Tint:", ["Lückenfarbton:", "Teinte de l'espace:", "Matiz del hueco:", "すき間の濃淡:", "间隙色调："]),
    (
        "Corner Size and Shape",
        ["Eckengröße und -form", "Taille et forme des angles", "Tamaño y forma de esquinas", "角のサイズとシェイプ", "角大小和形状"],
    ),
    ("Top Left:", ["Oben links:", "En haut à gauche:", "Superior izquierda:", "左上:", "左上："]),
    ("Top Right:", ["Oben rechts:", "En haut à droite:", "Superior derecha:", "右上:", "右上："]),
    ("Bottom Right:", ["Unten rechts:", "En bas à droite:", "Inferior derecha:", "右下:", "右下："]),
    ("Bottom Left:", ["Unten links:", "En bas à gauche:", "Inferior izquierda:", "左下:", "左下："]),
    ("Rounded", ["Abgerundet", "Arrondi", "Redondeado", "角丸", "圆角"]),
    ("Inverse Rounded", ["Umgekehrt abgerundet", "Arrondi inversé", "Redondeado inverso", "逆角丸", "反向圆角"]),
    ("Inset", ["Eingezogen", "En retrait", "Hundido", "内側に切り欠き", "内凹"]),
    ("Fancy", ["Verziert", "Fantaisie", "Decorativo", "装飾", "花式"]),
    ("Top Edge:", ["Obere Kante:", "Bord supérieur:", "Borde superior:", "上端:", "上边缘："]),
    ("Bottom Edge:", ["Untere Kante:", "Bord inférieur:", "Borde inferior:", "下端:", "下边缘："]),
    ("Em Box Top", ["Geviert oben", "Haut du cadratin", "Parte superior del cuadratín", "仮想ボディの上", "全角框顶部"]),
    ("Descent", ["Unterlänge", "Jambage inférieur", "Descendente", "ディセント", "下伸部"]),
    ("Em Box Bottom", ["Geviert unten", "Bas du cadratin", "Parte inferior del cuadratín", "仮想ボディの下", "全角框底部"]),
    (
        "Display Border if Paragraph Splits Across Frames/Columns",
        [
            "Rahmen anzeigen, wenn der Absatz auf Rahmen/Spalten verteilt ist",
            "Afficher le contour si le paragraphe est réparti sur plusieurs blocs/colonnes",
            "Mostrar borde si el párrafo se divide entre marcos/columnas",
            "段落がフレームや段をまたぐときに囲み罫を表示",
            "段落跨框架/栏拆分时显示边框",
        ],
    ),
    (
        "Merge Consecutive Borders and Shading",
        [
            "Aufeinanderfolgende Rahmen und Schattierungen zusammenführen",
            "Fusionner les contours et trames consécutifs",
            "Combinar bordes y sombreados consecutivos",
            "連続する囲み罫と背景色を結合",
            "合并连续的边框和底纹",
        ],
    ),
    ("Clip to Frame", ["Auf Rahmen beschneiden", "Découper selon le bloc", "Recortar al marco", "フレームでクリップ", "剪切到框架"]),
    (
        "Do not Print or Export",
        ["Nicht drucken oder exportieren", "Ne pas imprimer ni exporter", "No imprimir ni exportar", "印刷・書き出ししない", "不打印或导出"],
    ),
    ("Space Before Span:", ["Abstand vor Überspannung:", "Espace avant l'étendue:", "Espacio antes de abarcar:", "段抜き前のアキ:", "跨栏前间距："]),
    (
        "Space After Span:",
        ["Abstand nach Überspannung:", "Espace après l'étendue:", "Espacio después de abarcar:", "段抜き後のアキ:", "跨栏后间距："],
    ),
    ("Space Before Split:", ["Abstand vor Teilung:", "Espace avant la division:", "Espacio antes de dividir:", "段分割前のアキ:", "拆分前间距："]),
    ("Space After Split:", ["Abstand nach Teilung:", "Espace après la division:", "Espacio después de dividir:", "段分割後のアキ:", "拆分后间距："]),
    ("Level:", ["Ebene:", "Niveau:", "Nivel:", "レベル:", "级别："]),
    ("Glyphs…", ["Glyphen…", "Glyphes…", "Glifos…", "字形…", "字形…"]),
    ("(Paragraph Font)", ["(Absatzschrift)", "(Police du paragraphe)", "(Fuente del párrafo)", "(段落のフォント)", "(段落字体)"]),
    (
        "Restart Numbers at This Level After:",
        [
            "Nummerierung auf dieser Ebene neu beginnen nach:",
            "Recommencer la numérotation à ce niveau après:",
            "Reiniciar números en este nivel después de:",
            "このレベルの番号を振り直すきっかけ:",
            "在此级别后重新编号：",
        ],
    ),
    (
        "Any Previous Level",
        ["Einer beliebigen höheren Ebene", "Tout niveau précédent", "Cualquier nivel anterior", "任意の上位レベル", "任何上一级别"],
    ),
    ("Tab Position:", ["Tabulatorposition:", "Position de la tabulation:", "Posición de tabulación:", "タブ位置:", "制表符位置："]),
    (
        "Paragraph Borders and Shading…",
        [
            "Absatzrahmen und -schattierung…",
            "Contours et trames de paragraphe…",
            "Bordes y sombreado de párrafo…",
            "段落囲み罫と段落背景色…",
            "段落边框和底纹…",
        ],
    ),
    (
        "Paragraph Borders and Shading",
        [
            "Absatzrahmen und -schattierung",
            "Contours et trames de paragraphe",
            "Bordes y sombreado de párrafo",
            "段落囲み罫と段落背景色",
            "段落边框和底纹",
        ],
    ),
    ("Span Columns…", ["Spalten überspannen…", "Étendre sur les colonnes…", "Abarcar columnas…", "段抜きと段分割…", "跨栏…"]),
    (
        "Bullets and Numbering…",
        ["Aufzählungszeichen und Nummerierung…", "Puces et numérotation…", "Viñetas y numeración…", "箇条書き記号と番号付け…", "项目符号和编号…"],
    ),
    ("List:", ["Liste:", "Liste:", "Lista:", "リスト:", "列表："]),
    ("Mode:", ["Modus:", "Mode:", "Modo:", "モード:", "模式："]),
    (
        "Continue from Previous Number",
        [
            "Ab vorheriger Zahl fortfahren",
            "Continuer à partir du numéro précédent",
            "Continuar desde el número anterior",
            "前の番号から継続",
            "从上一编号继续",
        ],
    ),
    ("Start At", ["Beginnen bei", "Commencer à", "Empezar en", "開始番号", "起始编号"]),
    // Cell strokes.
    ("Strokes and Fills…", ["Konturen und Flächen …", "Contours et fonds…", "Trazos y rellenos…", "線と塗り…", "描边和填色…"]),
    ("Cell Stroke", ["Zellkontur", "Contour de cellule", "Trazo de celda", "セルの線", "单元格描边"]),
    ("Cell Fill", ["Zellfläche", "Fond de cellule", "Relleno de celda", "セルの塗り", "单元格填色"]),
    ("Cell edges", ["Zellkanten", "Bords de cellule", "Bordes de celda", "セルの境界線", "单元格边缘"]),
    (
        "Click a line to include or exclude it. Double-click selects all outer or all inner lines; triple-click selects or clears all.",
        [
            "Klicken Sie auf eine Linie, um sie ein- oder auszuschließen. Doppelklick wählt alle äußeren oder alle inneren Linien; Dreifachklick wählt alle aus oder hebt die Auswahl auf.",
            "Cliquez sur une ligne pour l'inclure ou l'exclure. Un double-clic sélectionne toutes les lignes extérieures ou intérieures ; un triple-clic sélectionne ou désélectionne tout.",
            "Haga clic en una línea para incluirla o excluirla. Doble clic selecciona todas las líneas exteriores o interiores; triple clic selecciona o borra todas.",
            "線をクリックすると、含めるか除外するかを切り替えます。ダブルクリックで外側または内側の線をすべて選択し、トリプルクリックですべてを選択または解除します。",
            "单击线条可将其包含或排除。双击选择所有外侧或所有内侧线条；三击选择或清除全部。",
        ],
    ),
    ("Swatch Options…", ["Farbfeldoptionen …", "Options de nuance…", "Opciones de muestra…", "スウォッチオプション…", "色板选项…"]),
    ("Swatch Options", ["Farbfeldoptionen", "Options de nuance", "Opciones de muestra", "スウォッチオプション", "色板选项"]),
    (
        "Color Group Options…",
        ["Farbgruppenoptionen …", "Options du groupe de couleurs…", "Opciones de grupo de colores…", "カラーグループオプション…", "颜色组选项…"],
    ),
    ("Layer Options", ["Ebenenoptionen", "Options de calque", "Opciones de capa", "レイヤーオプション", "图层选项"]),
    (
        "Layer Options for \"{name}\"…",
        [
            "Ebenenoptionen für „{name}“ …",
            "Options du calque « {name} »…",
            "Opciones de capa para «{name}»…",
            "「{name}」のレイヤーオプション…",
            "“{name}”的图层选项…",
        ],
    ),
    ("Swatch Name:", ["Farbfeldname:", "Nom de la nuance :", "Nombre de muestra:", "スウォッチ名:", "色板名称:"]),
    (
        "Name with Color Value",
        ["Name mit Farbwert", "Nommer d'après la valeur chromatique", "Nombre con valor de color", "カラー値を名前にする", "以颜色值命名"],
    ),
    ("Color Type:", ["Farbtyp:", "Type de couleur :", "Tipo de color:", "カラータイプ:", "颜色类型:"]),
    ("Process", ["Prozessfarbe", "Quadrichromie", "Cuatricromía", "プロセス", "印刷色"]),
    ("Spot", ["Volltonfarbe", "Ton direct", "Tinta plana", "特色", "专色"]),
    ("Color Mode:", ["Farbmodus:", "Mode colorimétrique :", "Modo de color:", "カラーモード:", "颜色模式:"]),
    ("Base Color:", ["Grundfarbe:", "Couleur de base :", "Color base:", "ベースカラー:", "基准颜色:"]),
    (
        "Edit the gradient's stops in the Gradient panel.",
        [
            "Die Verlaufsregler bearbeiten Sie im Verlaufsbedienfeld.",
            "Modifiez les arrêts du dégradé dans le panneau Dégradé.",
            "Edite las paradas del degradado en el panel Degradado.",
            "グラデーションの分岐点はグラデーションパネルで編集します。",
            "在“渐变”面板中编辑渐变的色标。",
        ],
    ),
    (
        "This swatch can't be edited.",
        [
            "Dieses Farbfeld kann nicht bearbeitet werden.",
            "Cette nuance ne peut pas être modifiée.",
            "Esta muestra no se puede editar.",
            "このスウォッチは編集できません。",
            "此色板无法编辑。",
        ],
    ),
    ("Light Blue", ["Hellblau", "Bleu clair", "Azul claro", "ライトブルー", "浅蓝色"]),
    ("Red", ["Rot", "Rouge", "Rojo", "レッド", "红色"]),
    ("Green", ["Grün", "Vert", "Verde", "グリーン", "绿色"]),
    ("Blue", ["Blau", "Bleu", "Azul", "ブルー", "蓝色"]),
    ("Yellow", ["Gelb", "Jaune", "Amarillo", "イエロー", "黄色"]),
    ("Magenta", ["Magenta", "Magenta", "Magenta", "マゼンタ", "洋红色"]),
    ("Cyan", ["Cyan", "Cyan", "Cian", "シアン", "青色"]),
    ("Black", ["Schwarz", "Noir", "Negro", "ブラック", "黑色"]),
    ("Orange", ["Orange", "Orange", "Naranja", "オレンジ", "橙色"]),
    ("Dark Green", ["Dunkelgrün", "Vert foncé", "Verde oscuro", "ダークグリーン", "深绿色"]),
    ("Teal", ["Blaugrün", "Bleu canard", "Verde azulado", "ティール", "蓝绿色"]),
    ("Tan", ["Hellbraun", "Fauve", "Tostado", "タン", "棕褐色"]),
    ("Brown", ["Braun", "Marron", "Marrón", "ブラウン", "褐色"]),
    ("Violet", ["Violett", "Violet", "Violeta", "バイオレット", "紫罗兰色"]),
    ("Gold", ["Gold", "Or", "Dorado", "ゴールド", "金色"]),
    ("Show Layer", ["Ebene einblenden", "Afficher le calque", "Mostrar capa", "レイヤーを表示", "显示图层"]),
    ("Lock Layer", ["Ebene fixieren", "Verrouiller le calque", "Bloquear capa", "レイヤーをロック", "锁定图层"]),
    ("Print Layer", ["Ebene drucken", "Imprimer le calque", "Imprimir capa", "レイヤーをプリント", "打印图层"]),
    (
        "Suppress Text Wrap When Layer is Hidden",
        [
            "Textumfluss bei ausgeblendeter Ebene unterdrücken",
            "Supprimer l'habillage quand le calque est masqué",
            "Suprimir ceñir texto cuando la capa está oculta",
            "非表示レイヤーのテキストの回り込みを無視",
            "图层隐藏时禁止文本绕排",
        ],
    ),
    // Document Setup
    ("Page Size:", ["Seitenformat:", "Format de page :", "Tamaño de página:", "ページサイズ:", "页面大小："]),
    (
        "Adjust page elements to document changes",
        [
            "Seitenelemente an Dokumentänderungen anpassen",
            "Adapter les éléments de page aux modifications du document",
            "Ajustar los elementos de página a los cambios del documento",
            "ページ要素をドキュメントの変更に合わせて調整",
            "根据文档更改调整页面元素",
        ],
    ),
    (
        "Apply the changes; objects follow the new page size and margins",
        [
            "Änderungen anwenden; Objekte folgen dem neuen Seitenformat und den Rändern",
            "Appliquer les modifications ; les objets suivent le nouveau format et les marges",
            "Aplicar los cambios; los objetos siguen el nuevo tamaño de página y los márgenes",
            "変更を適用し、オブジェクトを新しいページサイズとマージンに合わせます",
            "应用更改；对象跟随新的页面大小和边距",
        ],
    ),
    ("Bleed:", ["Anschnitt:", "Fond perdu :", "Sangrado:", "裁ち落とし:", "出血："]),
    ("Slug:", ["Infobereich:", "Ligne-bloc :", "Indicaciones:", "印刷可能領域:", "辅助信息区："]),
    // Font menu
    ("Filters:", ["Filter:", "Filtres :", "Filtros:", "フィルター:", "过滤器："]),
    ("All Classes", ["Alle Klassen", "Toutes les classes", "Todas las clases", "すべての分類", "所有分类"]),
    ("Serif", ["Serifenschrift", "Serif", "Con serifa", "セリフ", "衬线"]),
    ("Slab Serif", ["Egyptienne", "Slab serif", "Serifa cuadrada", "スラブセリフ", "粗衬线"]),
    ("Sans Serif", ["Serifenlos", "Sans serif", "Sin serifa", "サンセリフ", "无衬线"]),
    ("Script", ["Schreibschrift", "Script", "Manuscrita", "スクリプト", "手写体"]),
    ("Monospaced", ["Dicktengleich", "Chasse fixe", "Monoespaciada", "等幅", "等宽"]),
    ("Decorative", ["Dekorativ", "Décorative", "Decorativa", "装飾", "装饰"]),
    ("Symbol", ["Symbol", "Symbole", "Símbolo", "記号", "符号"]),
    (
        "Show Recently Added",
        [
            "Zuletzt hinzugefügte anzeigen",
            "Afficher les polices ajoutées récemment",
            "Mostrar añadidas recientemente",
            "最近追加したフォントを表示",
            "显示最近添加的字体",
        ],
    ),
    (
        "Small Sample Text Size",
        ["Kleine Beispieltextgröße", "Petite taille de l'exemple", "Tamaño de muestra pequeño", "サンプルテキスト（小）", "小号示例文本"],
    ),
    (
        "Medium Sample Text Size",
        ["Mittlere Beispieltextgröße", "Taille moyenne de l'exemple", "Tamaño de muestra mediano", "サンプルテキスト（中）", "中号示例文本"],
    ),
    (
        "Large Sample Text Size",
        ["Große Beispieltextgröße", "Grande taille de l'exemple", "Tamaño de muestra grande", "サンプルテキスト（大）", "大号示例文本"],
    ),
    ("Selected Text", ["Ausgewählter Text", "Texte sélectionné", "Texto seleccionado", "選択したテキスト", "所选文本"]),
    ("Sample", ["Beispiel", "Exemple", "Muestra", "サンプル", "示例"]),
    ("Similar to {family}", ["Ähnlich wie {family}", "Semblables à {family}", "Similares a {family}", "{family} に類似", "与 {family} 相似"]),
    (
        "No fonts match",
        ["Keine passenden Schriften", "Aucune police ne correspond", "Ninguna fuente coincide", "一致するフォントはありません", "没有匹配的字体"],
    ),
    (
        "Show Similar Fonts",
        ["Ähnliche Schriften anzeigen", "Afficher les polices semblables", "Mostrar fuentes similares", "類似フォントを表示", "显示相似字体"],
    ),
    ("Loading fonts…", ["Schriften werden geladen…", "Chargement des polices…", "Cargando fuentes…", "フォントを読み込み中…", "正在加载字体…"]),
    ("Show Styles", ["Schnitte einblenden", "Afficher les styles", "Mostrar estilos", "スタイルを表示", "显示样式"]),
    ("Hide Styles", ["Schnitte ausblenden", "Masquer les styles", "Ocultar estilos", "スタイルを隠す", "隐藏样式"]),
    ("TrueType font", ["TrueType-Schrift", "Police TrueType", "Fuente TrueType", "TrueType フォント", "TrueType 字体"]),
    ("OpenType font", ["OpenType-Schrift", "Police OpenType", "Fuente OpenType", "OpenType フォント", "OpenType 字体"]),
    ("Variable font", ["Variable Schrift", "Police variable", "Fuente variable", "バリアブルフォント", "可变字体"]),
    ("Color font", ["Farbschrift", "Police couleur", "Fuente de color", "カラーフォント", "彩色字体"]),
    // Table of Contents.
    (
        "Sort Entries in Alphabetical Order",
        [
            "Einträge alphabetisch sortieren",
            "Trier les entrées par ordre alphabétique",
            "Ordenar entradas alfabéticamente",
            "項目をアルファベット順に並べ替え",
            "按字母顺序排列条目",
        ],
    ),
];

/// Interface direction; independent of document binding and paragraph direction.
pub fn is_rtl(lang: &str) -> bool {
    lang == "ar"
}

/// A Japanese, Chinese or Korean interface language (`zh-tw` included): CJK features are shown by
/// default (see [`crate::cjk_features`]).
pub fn is_cjk(lang: &str) -> bool {
    matches!(lang.split('-').next(), Some("ja" | "zh" | "ko"))
}

fn column(lang: &str) -> Option<usize> {
    match lang {
        "de" => Some(0),
        "fr" => Some(1),
        "es" => Some(2),
        "ja" => Some(3),
        "zh" => Some(4),
        _ => None,
    }
}

/// `s` in `lang` (English, or the string itself, when there's no translation).
pub fn tr<'a>(lang: &str, s: &'a str) -> &'a str {
    static GERMAN: OnceLock<HashMap<&'static str, &'static str>> = OnceLock::new();
    static JAPANESE: OnceLock<HashMap<&'static str, &'static str>> = OnceLock::new();
    static TRANSLATIONS: OnceLock<HashMap<&'static str, [&'static str; 5]>> = OnceLock::new();
    static ARABIC: OnceLock<HashMap<&'static str, &'static str>> = OnceLock::new();
    static UKRAINIAN: OnceLock<HashMap<&'static str, &'static str>> = OnceLock::new();
    static PORTUGUESE_BR: OnceLock<HashMap<&'static str, &'static str>> = OnceLock::new();
    static ITALIAN: OnceLock<HashMap<&'static str, &'static str>> = OnceLock::new();
    static POLISH: OnceLock<HashMap<&'static str, &'static str>> = OnceLock::new();
    static RUSSIAN: OnceLock<HashMap<&'static str, &'static str>> = OnceLock::new();
    static CZECH: OnceLock<HashMap<&'static str, &'static str>> = OnceLock::new();
    static FRENCH: OnceLock<HashMap<&'static str, &'static str>> = OnceLock::new();
    static GEORGIAN: OnceLock<HashMap<&'static str, &'static str>> = OnceLock::new();
    if lang == "ar" {
        return ARABIC.get_or_init(|| ar::TABLE.iter().copied().collect()).get(s).copied().unwrap_or(s);
    }
    // The German and Japanese tables cover the whole interface; the shared table's German and Japanese
    // columns are the fallback for keys added there after them.
    if lang == "de"
        && let Some(text) = GERMAN.get_or_init(|| de::TABLE.iter().copied().collect()).get(s).copied()
    {
        return text;
    }
    if lang == "ja"
        && let Some(text) = JAPANESE.get_or_init(|| ja::TABLE.iter().copied().collect()).get(s).copied()
    {
        return text;
    }
    // `fr::TABLE` holds the strings the shared table has no row for.
    if lang == "fr"
        && let Some(text) = FRENCH.get_or_init(|| fr::TABLE.iter().copied().collect()).get(s).copied()
    {
        return text;
    }
    if lang == "pt-br" {
        return PORTUGUESE_BR.get_or_init(|| pt_br::TABLE.iter().copied().collect()).get(s).copied().unwrap_or(s);
    }
    if lang == "it" {
        return ITALIAN.get_or_init(|| it::TABLE.iter().copied().collect()).get(s).copied().unwrap_or(s);
    }
    if lang == "pl" {
        return POLISH.get_or_init(|| pl::TABLE.iter().copied().collect()).get(s).copied().unwrap_or(s);
    }
    if lang == "ka" {
        return GEORGIAN.get_or_init(|| ka::TABLE.iter().copied().collect()).get(s).copied().unwrap_or(s);
    }
    if lang == "uk" {
        return UKRAINIAN.get_or_init(|| uk::TABLE.iter().copied().collect()).get(s).copied().unwrap_or(s);
    }
    if lang == "ru" {
        return RUSSIAN.get_or_init(|| ru::TABLE.iter().copied().collect()).get(s).copied().unwrap_or(s);
    }
    if lang == "cs" {
        return CZECH.get_or_init(|| cs::TABLE.iter().copied().collect()).get(s).copied().unwrap_or(s);
    }
    let Some(c) = column(lang) else { return s };
    TRANSLATIONS.get_or_init(|| TABLE.iter().copied().collect()).get(s).and_then(|row| row.get(c)).copied().unwrap_or(s)
}

/// Context-sensitive captions in the shared table's languages (columns as in [`TABLE`]).
const CONTEXT: &[(&str, &str, [&str; 5])] = &[
    // A count of columns or rows, unlike the numbering field's "Number:".
    ("Number:", "count", ["Anzahl:", "Nombre :", "Número:", "数:", "数量："]),
];

/// Context-sensitive UI captions; unsupported contexts keep the shared translation.
pub fn tr_context<'a>(lang: &str, s: &'a str, context: &str) -> &'a str {
    let contexts = match lang {
        "uk" => uk::CONTEXT,
        "ru" => ru::CONTEXT,
        "cs" => cs::CONTEXT,
        "pl" => pl::CONTEXT,
        "ja" => ja::CONTEXT,
        "ar" => ar::CONTEXT,
        _ => &[],
    };
    if let Some((_, _, text)) = contexts.iter().find(|(key, scope, _)| *key == s && *scope == context) {
        return text;
    }
    if let Some(c) = column(lang)
        && let Some(text) = CONTEXT.iter().find(|(key, scope, _)| *key == s && *scope == context).and_then(|(_, _, row)| row.get(c))
    {
        return text;
    }
    tr(lang, s)
}

#[cfg(test)]
pub(crate) fn ukrainian_catalog() -> Vec<&'static str> {
    uk::TABLE.iter().map(|(_, text)| *text).chain(uk::CONTEXT.iter().map(|(_, _, text)| *text)).collect()
}

#[cfg(test)]
pub(crate) fn russian_catalog() -> Vec<&'static str> {
    ru::TABLE.iter().map(|(_, text)| *text).chain(ru::CONTEXT.iter().map(|(_, _, text)| *text)).collect()
}

/// Ukrainian, Russian, Polish and Georgian put the category before the value in count captions
/// ("сторінок: 5", "страниц: 5", "Strony: 5", "გვერდი: 5"): every number stays grammatical in the
/// languages with several plural forms, and Georgian nouns stay singular after numerals. Other
/// languages keep the existing value-first caption.
pub fn category_first(lang: &str) -> bool {
    matches!(lang, "uk" | "ru" | "pl" | "ka")
}

/// Caption for a counted category, e.g. `count_label("ru", "pages", 5)` is "страниц: 5". Czech
/// picks the plural form for the count (1, 2–4, other).
pub fn count_label(lang: &str, noun: &str, count: usize) -> String {
    if category_first(lang) {
        return format!("{}: {count}", tr(lang, noun));
    }
    if lang == "cs"
        && let Some((_, [one, few, other])) = cs::PLURALS.iter().find(|(key, _)| *key == noun)
    {
        let form = match count {
            1 => one,
            2..=4 => few,
            _ => other,
        };
        return format!("{count} {form}");
    }
    format!("{count} {}", tr(lang, noun))
}

/// Localize reserved built-in style names only; user-defined names are document data.
pub fn style_name<'a>(lang: &str, name: &'a str) -> &'a str {
    match name {
        designcraft_doc::NO_PARA_STYLE | designcraft_doc::BASIC_PARAGRAPH | designcraft_doc::NO_CHAR_STYLE => tr(lang, name),
        _ => name,
    }
}

/// Built-in workspace captions; custom workspace names remain unchanged.
pub fn workspace_name<'a>(lang: &str, name: &'a str) -> &'a str {
    match name {
        "Essentials"
        | "Essentials Classic"
        | "Advanced"
        | "Book"
        | "Digital Publishing"
        | "Interactive for PDF"
        | "Printing and Proofing"
        | "Typography" => tr(lang, name),
        _ => name,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn cached_lookup_preserves_every_translation_across_language_switches() {
        for (key, translations) in TABLE {
            for (lang, expected) in ["de", "fr", "es", "ja", "zh"].into_iter().zip(translations) {
                // `de::TABLE` and `ja::TABLE` translate the whole interface and win over the shared columns.
                if lang != "de" && lang != "ja" {
                    assert_eq!(tr(lang, key), *expected, "{lang}: {key}");
                }
            }
            assert_eq!(tr("", key), *key);
        }
        for (key, expected) in de::TABLE {
            assert_eq!(tr("de", key), *expected, "de: {key}");
        }
        for (key, expected) in ar::TABLE {
            assert_eq!(tr("ar", key), *expected, "ar: {key}");
        }
        for (key, expected) in pt_br::TABLE {
            assert_eq!(tr("pt-br", key), *expected, "pt-br: {key}");
        }
        for (key, expected) in it::TABLE {
            assert_eq!(tr("it", key), *expected, "it: {key}");
        }
        for (key, expected) in uk::TABLE {
            assert_eq!(tr("uk", key), *expected, "uk: {key}");
        }
        for (key, expected) in ru::TABLE {
            assert_eq!(tr("ru", key), *expected, "ru: {key}");
        }
        for (key, expected) in cs::TABLE {
            assert_eq!(tr("cs", key), *expected, "cs: {key}");
        }
        for (key, expected) in fr::TABLE {
            assert_eq!(tr("fr", key), *expected, "fr: {key}");
        }
        for (key, expected) in pl::TABLE {
            assert_eq!(tr("pl", key), *expected, "pl: {key}");
        }
        for (key, expected) in ka::TABLE {
            assert_eq!(tr("ka", key), *expected, "ka: {key}");
        }
        let unknown = String::from("A user-defined untranslated label");
        for lang in ["pl", "cs", "uk", "ru", "ar", "pt-br", "it", "ka", "zh", "ja", "de", "fr", "es", "", "unknown"] {
            assert!(std::ptr::eq(tr(lang, &unknown), unknown.as_str()));
        }
    }

    #[test]
    fn translates_known_strings_and_keeps_the_rest() {
        assert_eq!(tr("de", "File"), "Datei");
        assert_eq!(tr("ja", "Swatches"), "スウォッチ");
        assert_eq!(tr("fr", "Something new"), "Something new");
        assert_eq!(tr("", "File"), "File");
        assert_eq!(tr("ar", "File"), "ملف");
        assert_eq!(tr("ar", "Unknown label"), "Unknown label");
        assert_eq!(tr("pt-br", "File"), "Arquivo");
        assert_eq!(tr("pt-br", "New Document…"), "Novo documento…");
        assert_eq!(tr("pt-br", "Unknown label"), "Unknown label");
        assert_eq!(tr("it", "Edit"), "Modifica");
        assert_eq!(tr("it", "New Document…"), "Nuovo documento…");
        assert_eq!(tr("it", "Unknown label"), "Unknown label");
        assert!(is_rtl("ar"));
        for (i, (en, translation)) in ar::TABLE.iter().enumerate() {
            assert!(ar::TABLE[..i].iter().all(|(key, _)| key != en), "duplicate {en}");
            assert!(!translation.is_empty(), "{en}");
        }
        for (i, (en, translation)) in pt_br::TABLE.iter().enumerate() {
            assert!(pt_br::TABLE[..i].iter().all(|(key, _)| key != en), "duplicate {en}");
            assert!(!translation.is_empty(), "{en}");
        }
        for (i, (en, translation)) in it::TABLE.iter().enumerate() {
            assert!(it::TABLE[..i].iter().all(|(key, _)| key != en), "duplicate {en}");
            assert!(!translation.is_empty(), "{en}");
        }
        // Italian entries are for keys the shared or Arabic table knows. A new English string
        // falls back to English until it is translated, so it doesn't fail here.
        for (en, _) in it::TABLE {
            assert!(TABLE.iter().any(|(key, _)| key == en) || ar::TABLE.iter().any(|(key, _)| key == en), "it: unknown key {en}");
        }
        // Every row is unique and complete.
        for (i, (en, t)) in TABLE.iter().enumerate() {
            assert!(TABLE[..i].iter().all(|(e, _)| e != en), "duplicate {en}");
            assert!(t.iter().all(|x| !x.is_empty()), "{en}");
        }
    }

    #[test]
    fn a_column_count_and_a_list_number_read_differently() {
        for (lang, count, numeral) in [
            ("de", "Anzahl:", "Zahl:"),
            ("ja", "数:", "番号:"),
            ("uk", "Кількість:", "Номер:"),
            ("ar", "العدد:", "الرقم:"),
            ("fr", "Nombre :", "Numéro:"),
            ("zh", "数量：", "编号："),
        ] {
            assert_eq!((tr_context(lang, "Number:", "count"), tr(lang, "Number:")), (count, numeral), "{lang}");
        }
        assert_eq!(tr_context("en", "Number:", "count"), "Number:");
        assert_eq!(tr("de", "Gutter:"), "Spaltenabstand:");
        // The Pages panel menu.
        for key in [
            "Insert Pages…",
            "Move Pages…",
            "New Parent…",
            "Override All Parent Page Items",
            "Remove All Local Overrides",
            "Detach All Objects from Parent",
            "Create Alternate Layout…",
            "Allow Selected Spread to Shuffle",
        ] {
            assert_ne!(tr("pt-br", key), key);
        }
        assert_ne!(tr("ar", "Apply Parent to Pages"), "Apply Parent to Pages");
    }

    #[test]
    fn french_catalog_has_no_duplicate_or_stale_keys_and_keeps_placeholders() {
        let catalog: HashMap<_, _> = fr::TABLE.iter().copied().collect();
        assert_eq!(catalog.len(), fr::TABLE.len(), "duplicate French keys");
        let shared: std::collections::HashSet<_> = TABLE.iter().map(|(key, _)| *key).collect();
        // `fr::TABLE` is looked up first: a key there would hide the shared table's French column.
        let both: Vec<_> = catalog.keys().filter(|k| shared.contains(*k)).collect();
        assert!(both.is_empty(), "French keys also in the shared table: {both:?}");
        let mut keys = std::collections::HashSet::new();
        for table in [ar::TABLE, de::TABLE, it::TABLE, ja::TABLE, pt_br::TABLE, uk::TABLE, ru::TABLE, cs::TABLE] {
            keys.extend(table.iter().map(|(key, _)| *key));
        }
        let stale: Vec<_> = catalog.keys().filter(|k| !keys.contains(*k)).collect();
        assert!(stale.is_empty(), "French entries for unknown keys: {stale:?}");
        let placeholders = |s: &str| {
            let mut names = s.split('{').skip(1).filter_map(|part| part.split_once('}').map(|(name, _)| name.to_owned())).collect::<Vec<_>>();
            names.sort();
            names
        };
        let shared_french = TABLE.iter().filter_map(|(key, row)| row.get(1).map(|text| (*key, *text)));
        for (key, translation) in fr::TABLE.iter().copied().chain(shared_french) {
            assert!(!translation.trim().is_empty(), "empty {key}");
            assert_eq!(key.starts_with(' '), translation.starts_with(' '), "leading space: {key}");
            assert_eq!(key.ends_with(' '), translation.ends_with(' '), "trailing space: {key}");
            assert_eq!(placeholders(key), placeholders(translation), "placeholders: {key}");
        }
        assert_eq!(tr("fr", "Group"), "Associer");
    }

    #[test]
    fn ukrainian_catalog_covers_existing_keys_and_preserves_placeholders() {
        let catalog: std::collections::HashMap<_, _> = uk::TABLE.iter().copied().collect();
        assert_eq!(catalog.len(), uk::TABLE.len(), "duplicate Ukrainian keys");
        let mut keys = std::collections::HashSet::new();
        keys.extend(TABLE.iter().map(|(key, _)| *key));
        keys.extend(ar::TABLE.iter().map(|(key, _)| *key));
        keys.extend(pt_br::TABLE.iter().map(|(key, _)| *key));
        // A new English string falls back to English until it is translated, so only stale
        // entries (keys no catalog knows any more) fail.
        let stale: Vec<_> = catalog.keys().filter(|k| !keys.contains(*k)).collect();
        assert!(stale.is_empty(), "Ukrainian entries for unknown keys: {stale:?}");
        let placeholders =
            |s: &str| s.split('{').skip(1).filter_map(|part| part.split_once('}').map(|(name, _)| name.to_owned())).collect::<Vec<_>>();
        for (key, translation) in uk::TABLE {
            assert!(!translation.trim().is_empty(), "empty {key}");
            let mut source = placeholders(key);
            let mut translated = placeholders(translation);
            source.sort();
            translated.sort();
            assert_eq!(source, translated, "placeholders: {key}");
        }
        assert_eq!(tr_context("uk", "Columns", "table"), "Стовпці");
        assert_eq!(tr("uk", "Columns"), "Колонки");
        assert_eq!(tr_context("uk", "Group", "selection"), "Група");
        // Step and Repeat's grid columns are not a text frame's.
        assert_eq!(tr_context("uk", "Columns:", "grid"), "Стовпці:");
        assert_eq!(tr_context("ja", "Columns:", "grid"), "列:");
        assert_eq!(tr("ja", "Columns:"), "段:");
        assert_eq!(tr("uk", "Group"), "Згрупувати");
        assert_eq!(tr_context("", "Columns", "table"), "Columns");
        assert_eq!(tr_context("ja", "Span Columns", "paragraphLayout"), "段抜き");
        assert_eq!(tr("ja", "Span Columns"), "段抜きと段分割");
        assert_eq!(tr_context("uk", "Custom caption", "custom"), "Custom caption");
        assert_eq!(tr("uk", "through"), "включно");
        assert_eq!(tr("uk", "up to"), "не включно");
        assert!(!is_rtl("uk"));
        assert_eq!(tr("uk", "Type"), "Текст");
        assert_eq!(tr("uk", "Spread"), "Розворот");
        assert_eq!(tr("uk", "Story"), "Текстовий матеріал");
        assert_eq!(tr("uk", "Footer Rows"), "Рядки нижнього колонтитула");
        assert_eq!(style_name("uk", "[Basic Paragraph]"), "[Основний абзац]");
        assert_eq!(style_name("uk", "My layout style"), "My layout style");
        assert_eq!(workspace_name("uk", "Essentials"), "Основне");
        assert_eq!(workspace_name("uk", "My workspace"), "My workspace");
    }

    #[test]
    fn georgian_catalog_preserves_placeholders_and_counts() {
        let catalog: HashMap<_, _> = ka::TABLE.iter().copied().collect();
        assert_eq!(catalog.len(), ka::TABLE.len(), "duplicate Georgian keys");
        let placeholders = |s: &str| {
            s.split('{').skip(1).filter_map(|part| part.split_once('}').map(|(name, _)| name.to_owned())).collect::<std::collections::BTreeSet<_>>()
        };
        for (key, translation) in ka::TABLE {
            assert!(!translation.trim().is_empty(), "empty {key}");
            assert_eq!(placeholders(key), placeholders(translation), "placeholders: {key}");
            assert_eq!(key.ends_with('…'), translation.ends_with('…'), "ellipsis: {key}");
            // Georgian has no capitals in running text: Mtavruli never appears in the interface.
            assert!(!translation.chars().any(|c| ('\u{1C90}'..='\u{1CBF}').contains(&c)), "Mtavruli: {key}");
        }
        assert_eq!(tr("ka", "File"), "ფაილი");
        assert_eq!(tr("ka", "Save As…"), "შენახვა როგორც…");
        assert_eq!(tr("ka", "Unknown label"), "Unknown label");
        assert!(!is_rtl("ka"));
        for n in [1, 2, 5, 21] {
            assert_eq!(count_label("ka", "pages", n), format!("გვერდი: {n}"));
        }
    }

    #[test]
    fn ukrainian_counts_use_category_captions_for_every_number() {
        for n in [0, 1, 2, 4, 5, 11, 21, 22, 25] {
            assert_eq!(count_label("uk", "pages", n), format!("сторінок: {n}"));
            assert_eq!(count_label("uk", "objects", n), format!("об’єктів: {n}"));
            assert_eq!(count_label("uk", "errors", n), format!("помилок: {n}"));
            let pages = tr("uk", "{pages} Pages in {spreads} Spreads").replace("{pages}", &n.to_string()).replace("{spreads}", &n.to_string());
            assert_eq!(pages, format!("Сторінок: {n}; розворотів: {n}"));
        }
        assert_eq!(count_label("", "objects", 2), "2 objects");
    }

    #[test]
    fn russian_catalog_covers_existing_keys_and_preserves_placeholders() {
        let catalog: std::collections::HashMap<_, _> = ru::TABLE.iter().copied().collect();
        assert_eq!(catalog.len(), ru::TABLE.len(), "duplicate Russian keys");
        let mut keys = std::collections::HashSet::new();
        keys.extend(TABLE.iter().map(|(key, _)| *key));
        keys.extend(ar::TABLE.iter().map(|(key, _)| *key));
        keys.extend(pt_br::TABLE.iter().map(|(key, _)| *key));
        keys.extend(it::TABLE.iter().map(|(key, _)| *key));
        keys.extend(ja::TABLE.iter().map(|(key, _)| *key));
        keys.extend(uk::TABLE.iter().map(|(key, _)| *key));
        // A new English string falls back to English until it is translated, so only stale
        // entries (keys no catalog knows any more) fail.
        let stale: Vec<_> = catalog.keys().filter(|k| !keys.contains(*k)).collect();
        assert!(stale.is_empty(), "Russian entries for unknown keys: {stale:?}");
        let placeholders =
            |s: &str| s.split('{').skip(1).filter_map(|part| part.split_once('}').map(|(name, _)| name.to_owned())).collect::<Vec<_>>();
        for (key, translation) in ru::TABLE {
            assert!(!translation.trim().is_empty(), "empty {key}");
            assert_eq!(key.starts_with(' '), translation.starts_with(' '), "leading space: {key}");
            assert_eq!(key.ends_with(' '), translation.ends_with(' '), "trailing space: {key}");
            assert!(!translation.contains(['ґ', 'є', 'і', 'ї', 'Ґ', 'Є', 'І', 'Ї']), "Ukrainian letter in {key}");
            let mut source = placeholders(key);
            let mut translated = placeholders(translation);
            source.sort();
            translated.sort();
            assert_eq!(source, translated, "placeholders: {key}");
        }
    }

    #[test]
    fn russian_is_selectable_ltr_and_resolves_contexts_styles_and_menu_paths() {
        assert!(LANGUAGES.contains(&("ru", "Русский")));
        assert!(!is_rtl("ru"));
        assert_eq!(tr("ru", "File"), "Файл");
        assert_eq!(tr("ru", "Type"), "Текст");
        assert_eq!(tr("ru", "Spread"), "Разворот");
        assert_eq!(tr("ru", "Story"), "Материал");
        assert_eq!(tr("ru", "Unknown label"), "Unknown label");
        assert_eq!(tr_context("ru", "Columns", "table"), "Столбцы");
        assert_eq!(tr("ru", "Columns"), "Колонки");
        assert_eq!(tr_context("ru", "Group", "selection"), "Группа");
        assert_eq!(tr("ru", "Group"), "Сгруппировать");
        assert_eq!(tr_context("ru", "Custom caption", "custom"), "Custom caption");
        assert_eq!(tr("ru", "through"), "включительно");
        assert_eq!(tr("ru", "up to"), "не включая");
        assert_eq!(tr("ru", "Edit/Spelling"), "Редактирование/Орфография");
        assert_eq!(tr("ru", "Type/Insert Special Character/Quotation Marks"), "Текст/Вставить специальный символ/Кавычки");
        assert_eq!(style_name("ru", "[Basic Paragraph]"), "[Основной абзац]");
        assert_eq!(style_name("ru", "My layout style"), "My layout style");
        assert_eq!(workspace_name("ru", "Essentials"), "Основное");
        assert_eq!(workspace_name("ru", "My workspace"), "My workspace");
        // Fixed standard names stay identical.
        assert_eq!(tr("ru", "PDF/X-4"), "PDF/X-4");
    }

    #[test]
    fn russian_counts_use_category_captions_for_every_number() {
        assert!(category_first("ru") && category_first("uk") && !category_first("de") && !category_first(""));
        for n in [0, 1, 2, 4, 5, 11, 12, 21, 22, 25, 101, 111] {
            assert_eq!(count_label("ru", "pages", n), format!("страниц: {n}"));
            assert_eq!(count_label("ru", "objects", n), format!("объектов: {n}"));
            assert_eq!(count_label("ru", "errors", n), format!("ошибок: {n}"));
            let pages = tr("ru", "{pages} Pages in {spreads} Spreads").replace("{pages}", &n.to_string()).replace("{spreads}", &n.to_string());
            assert_eq!(pages, format!("Страниц: {n}; разворотов: {n}"));
        }
    }

    #[test]
    fn polish_catalog_covers_existing_keys_and_preserves_placeholders() {
        let catalog: HashMap<_, _> = pl::TABLE.iter().copied().collect();
        assert_eq!(catalog.len(), pl::TABLE.len(), "duplicate Polish keys");
        let mut keys = std::collections::HashSet::new();
        keys.extend(TABLE.iter().map(|(key, _)| *key));
        for table in [ar::TABLE, pt_br::TABLE, ja::TABLE, it::TABLE, uk::TABLE, de::TABLE, fr::TABLE, ru::TABLE, cs::TABLE] {
            keys.extend(table.iter().map(|(key, _)| *key));
        }
        // A new English string falls back to English until it is translated; only stale entries fail.
        let stale: Vec<_> = catalog.keys().filter(|k| !keys.contains(*k)).collect();
        assert!(stale.is_empty(), "Polish entries for unknown keys: {stale:?}");
        let placeholders =
            |s: &str| s.split('{').skip(1).filter_map(|part| part.split_once('}').map(|(name, _)| name.to_owned())).collect::<Vec<_>>();
        for (key, translation) in pl::TABLE {
            assert!(!translation.trim().is_empty(), "empty {key}");
            let mut source = placeholders(key);
            let mut translated = placeholders(translation);
            source.sort();
            translated.sort();
            assert_eq!(source, translated, "placeholders: {key}");
            assert_eq!(key.ends_with('…'), translation.ends_with('…'), "ellipsis: {key}");
        }
        assert!(LANGUAGES.contains(&("pl", "Polski")));
        assert!(!is_rtl("pl"));
        assert_eq!(tr("pl", "File"), "Plik");
        assert_eq!(tr("pl", "New Document…"), "Nowy dokument…");
        assert_eq!(tr("pl", "Spread"), "Rozkładówka");
        assert_eq!(tr("pl", "Unknown label"), "Unknown label");
        assert_eq!(style_name("pl", "[Basic Paragraph]"), "[Podstawowy akapit]");
        assert_eq!(workspace_name("pl", "Essentials"), "Podstawowe");
        // A table's columns and grid columns aren't a text frame's; a selection's group isn't the action.
        assert_eq!(tr("pl", "Columns"), "Łamy");
        assert_eq!(tr_context("pl", "Columns", "table"), "Kolumny");
        assert_eq!(tr_context("pl", "Columns:", "grid"), "Łamy:");
        assert_eq!(tr("pl", "Group"), "Grupuj");
        assert_eq!(tr_context("pl", "Group", "selection"), "Grupa");
    }

    #[test]
    fn polish_counts_use_category_captions_for_every_number() {
        for n in [0, 1, 2, 5, 12, 22, 25] {
            assert_eq!(count_label("pl", "pages", n), format!("Strony: {n}"));
            assert_eq!(count_label("pl", "objects", n), format!("Obiekty: {n}"));
            assert_eq!(count_label("pl", "errors", n), format!("Błędy: {n}"));
        }
        assert_eq!(tr("pl", "{pages} Pages in {spreads} Spreads"), "Strony: {pages}, rozkładówki: {spreads}");
    }

    #[test]
    fn czech_catalog_has_no_stale_keys_and_keeps_placeholders_and_markers() {
        let catalog: HashMap<_, _> = cs::TABLE.iter().copied().collect();
        assert_eq!(catalog.len(), cs::TABLE.len(), "duplicate Czech keys");
        let mut keys = std::collections::HashSet::new();
        keys.extend(TABLE.iter().map(|(key, _)| *key));
        for table in [ar::TABLE, it::TABLE, ja::TABLE, pt_br::TABLE, uk::TABLE] {
            keys.extend(table.iter().map(|(key, _)| *key));
        }
        // Command labels and menu names reach `tr` from the engine and the UI command table.
        for spec in designcraft_engine::command_specs() {
            keys.insert(spec.label);
            keys.extend(spec.menu.iter().copied());
        }
        keys.extend(crate::menus::UI_COMMANDS.iter().map(|(_, label, _, _)| *label));
        // Tool names reach `tr` from the Tools panel.
        keys.extend(designcraft_tools::TOOL_GROUPS.iter().flat_map(|group| group.iter()).map(|tool| tool.label));
        // So do the About window's tab names, app descriptions and the credits' column and sort labels.
        keys.extend(crate::about::ABOUT_TABS);
        keys.extend(crate::about::SIBLINGS.iter().map(|(_, _, what)| *what));
        keys.extend(crate::credits::NameMode::ALL.iter().map(|mode| mode.label()));
        keys.extend(crate::credits::SortKey::ALL.iter().flat_map(|key| [key.label().0, key.label().1]));
        // UI labels passed to `tr` that no other catalog has yet.
        keys.extend([
            "(any)",
            "(unchanged)",
            "[No Language]",
            "Cell Number:",
            "Change fill to:",
            "Chinese: Simplified",
            "Chinese: Traditional",
            "Don't Save",
            "Email Address:",
            "Email:",
            "Find fill:",
            "Group with",
            "H:",
            "Message:",
            "Organization:",
            "Phone:",
            "W:",
            "Resize panel window",
            "Resize panels",
            "Subject:",
            "Text:",
            "Unsaved Changes",
            "“{}” has changes that are not saved. Save them before closing?",
            "% of all commits",
            "{count} conflict(s): {names}",
            "{count} match(es)",
            "{count} replacement(s) made",
            "{contributors} contributors · {commits} commits",
            "{label}: {name} (double-click: Color Picker)",
            "All",
            "Align To",
            "Auto Rename",
            "Character Style",
            "Company",
            "DesignCraft page",
            "Equal fixed heights for the selected rows; cell text may become overset.",
            "Found",
            "Grab bag",
            "Key Object",
            "layer",
            "layers",
            "Lines +/−",
            "New Cell Style",
            "New Table Style",
            "No contributor data was built into this copy.",
            "No matches",
            "No model credits were built into this copy.",
            "Object Style",
            "Paragraph Style",
            "Press keys…",
            "Range:",
            "Redefine Document Style",
            "Report an issue",
            "Reverse the order",
            "Story {story} ← story {parent}",
            "Story Editor — {count} words",
            "Text Anchor",
            "Use Document Style Definition",
            // Status-bar messages.
            "Alternate layout",
            "Couldn't write recovery data: {error}",
            "Export a PDF, IDML or package to share — no cloud account needed.",
            "Import cancelled: the originating document has closed",
            "Invalid panel layout; restored the default dock",
            "PDF import cancelled: the originating document has closed",
            "Packaged {count} files into {dir}",
            "Relinked {count}",
            "Sent {count} page(s) to {printer}",
            "the default printer",
            "{name}: import cancelled while a dialog is open; choose the file again",
            "{name}: {count} step(s) done",
        ]);
        // A new English string falls back to English until it is translated, so only stale
        // entries (keys nothing passes to `tr` any more) fail.
        let stale: Vec<_> = catalog.keys().filter(|k| !keys.contains(*k)).collect();
        assert!(stale.is_empty(), "Czech entries for unknown keys: {stale:?}");
        let placeholders =
            |s: &str| s.split('{').skip(1).filter_map(|part| part.split_once('}').map(|(name, _)| name.to_owned())).collect::<Vec<_>>();
        for (key, translation) in cs::TABLE {
            assert!(!translation.trim().is_empty(), "empty {key}");
            let mut source = placeholders(key);
            let mut translated = placeholders(translation);
            source.sort();
            translated.sort();
            assert_eq!(source, translated, "placeholders: {key}");
            // Dialog ellipses, label colons and padded button captions stay as in English.
            assert_eq!(key.ends_with('…'), translation.ends_with('…'), "ellipsis: {key}");
            assert_eq!(key.ends_with(':'), translation.ends_with(':'), "colon: {key}");
            assert_eq!(key.starts_with(' '), translation.starts_with(' '), "leading space: {key}");
            assert_eq!(key.ends_with(' '), translation.ends_with(' '), "trailing space: {key}");
        }
        assert!(!is_rtl("cs"));
        assert_eq!(tr("cs", "File"), "Soubor");
        assert_eq!(tr("cs", "New Document…"), "Nový dokument…");
        assert_eq!(tr("cs", "Spread"), "Dvoustrana");
        assert_eq!(tr("cs", "Bleed"), "Spadávka");
        assert_eq!(tr("cs", "Leading"), "Proklad");
        assert_eq!(tr("cs", "Unknown label"), "Unknown label");
        assert_eq!(tr_context("cs", "Group", "selection"), "Skupina");
        assert_eq!(tr_context("cs", "Name", "contributors"), "Jméno");
        assert_eq!(tr_context("cs", "Name", "unknown"), "Název");
        assert_eq!(tr("cs", "Group"), "Seskupit");
        assert_eq!(tr_context("cs", "Columns", "table"), tr("cs", "Columns"));
        assert_eq!(style_name("cs", "[Basic Paragraph]"), "[Základní odstavec]");
        assert_eq!(style_name("cs", "My layout style"), "My layout style");
        assert_eq!(workspace_name("cs", "Essentials"), "Základní");
        assert_eq!(workspace_name("cs", "My workspace"), "My workspace");
    }

    #[test]
    fn czech_counts_use_the_plural_form_for_the_number() {
        for (n, form) in [(0, "chyb"), (1, "chyba"), (2, "chyby"), (4, "chyby"), (5, "chyb"), (11, "chyb"), (22, "chyb")] {
            assert_eq!(count_label("cs", "errors", n), format!("{n} {form}"));
        }
        // The status bar passes the singular noun for one error.
        assert_eq!(count_label("cs", "error", 1), "1 chyba");
        assert_eq!(count_label("cs", "pages", 1), "1 stránka");
        assert_eq!(count_label("cs", "pages", 3), "3 stránky");
        assert_eq!(count_label("cs", "pages", 5), "5 stránek");
        assert_eq!(count_label("cs", "stories", 2), "2 články");
        assert_eq!(count_label("cs", "items", 1), "1 položka");
        assert_eq!(count_label("cs", "objects", 7), "7 objektů");
        assert_eq!(count_label("cs", "warnings", 3), "3 varování");
        assert_eq!(count_label("cs", "layer", 1), "1 vrstva");
        assert_eq!(count_label("cs", "layers", 3), "3 vrstvy");
        assert_eq!(count_label("cs", "layers", 8), "8 vrstev");
        // A noun without plural forms keeps the plain translation.
        assert_eq!(count_label("cs", "a new noun", 3), "3 a new noun");
        for (noun, forms) in cs::PLURALS {
            assert!(forms.iter().all(|form| !form.is_empty()), "{noun}");
            assert!(forms.contains(&tr("cs", noun)), "{noun}: the catalog row is one of the plural forms");
        }
    }

    #[test]
    fn czech_translates_every_tool_name() {
        for tool in designcraft_tools::TOOL_GROUPS.iter().flat_map(|group| group.iter()) {
            assert_ne!(tr("cs", tool.label), tool.label, "{}", tool.id);
            assert_eq!(tr("", tool.label), tool.label);
        }
    }

    #[test]
    fn japanese_vertical_type_commands_are_translated() {
        for (en, ja) in [
            ("Story Direction", "組み方向"),
            ("Horizontal", "横書き"),
            ("Vertical", "縦書き"),
            ("Tate-Chu-Yoko", "縦中横"),
            ("Ruby…", "ルビ…"),
            ("Kenten", "圏点"),
            ("Warichu", "割り注"),
        ] {
            assert_eq!(tr("ja", en), ja);
        }
    }

    #[test]
    fn pdf_export_dialog_strings_are_translated() {
        // Translated labels in every supported language.
        assert_ne!(tr("zh", "Crop Marks"), "Crop Marks");
        assert_ne!(tr("de", "Tagged PDF"), "Tagged PDF");
        assert_ne!(tr("ar", "Include document bleed"), "Include document bleed");
        assert_ne!(tr("pt-br", "Compress images"), "Compress images");
        // English returns the key unchanged.
        assert_eq!(tr("", "Export PDF"), "Export PDF");
        // An unknown string still falls through unchanged.
        assert_eq!(tr("de", "Low Quality Print"), "Low Quality Print");
        // Fixed standard names stay identical in every language.
        assert_eq!(tr("ja", "PDF/X-4"), "PDF/X-4");
    }

    #[test]
    fn style_row_menu_strings_are_translated_in_every_language() {
        for (code, _) in LANGUAGES.iter().filter(|(c, _)| !c.is_empty()) {
            for key in ["Redefine Style", "Alt-click clears overrides", "Apply \"{name}\", Clear Overrides"] {
                assert_ne!(tr(code, key), key, "{code}: {key}");
            }
        }
    }
}
